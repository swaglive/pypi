
===========================
Apptimize Python Server SDK
===========================

Description
===========

The Apptimize Python Server SDK is designed to be used on server-side applications.

Integrating Apptimize in your Python service will allow you to optimize your customers' digital experience.

For more information, please visit https://apptimize.com


Documentation
=============

Documentation can be found at https://apptimize.com/docs/
