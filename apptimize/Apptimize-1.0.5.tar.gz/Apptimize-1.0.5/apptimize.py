# Copyright (c) Apptimize, Inc. | https://sdk.apptimize.com/license
# coding: utf-8

from datetime import datetime as python_lib_datetime_Datetime
from datetime import timezone as python_lib_datetime_Timezone
import math as python_lib_Math
import math as Math
from os import path as python_lib_os_Path
import inspect as python_lib_Inspect
import os as python_lib_Os
import atexit as apptimize_native_python_AtExit
from requests import Session as apptimize_native_python_Session
from requests_futures.sessions import FuturesSession as apptimize_native_python_FuturesSession
import requests as apptimize_native_python_Requests
import re as python_lib_Re
import builtins as python_lib_Builtins
import functools as python_lib_Functools
import json as python_lib_Json
import random as python_lib_Random
import time as python_lib_Time
import timeit as python_lib_Timeit
from io import StringIO as python_lib_io_StringIO
from threading import RLock as python_lib_threading_RLock
from threading import Thread as python_lib_threading_Thread
import urllib.parse as python_lib_urllib_Parse


class _hx_AnonObject:
    def __init__(self, fields):
        self.__dict__ = fields


_hx_classes = {}


class Enum:
    _hx_class_name = "Enum"
    __slots__ = ("tag", "index", "params")
    _hx_fields = ["tag", "index", "params"]
    _hx_methods = ["__str__"]

    def __init__(self,tag,index,params):
        self.tag = tag
        self.index = index
        self.params = params

    def __str__(self):
        if (self.params is None):
            return self.tag
        else:
            _this = self.params
            return (((HxOverrides.stringOrNull(self.tag) + "(") + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in _this]))) + ")")

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.tag = None
        _hx_o.index = None
        _hx_o.params = None
Enum._hx_class = Enum
_hx_classes["Enum"] = Enum


class Apptimize:
    _hx_class_name = "Apptimize"
    __slots__ = ()
    _hx_statics = ["kABTEventSourceApptimize", "kABTValueEventKey", "_isInitialized", "_getApptimizeAnonUserId", "setAppVersion", "setAppName", "setOnParticipationCallback", "setOnMetadataUpdatedCallback", "setup", "updateApptimizeMetadataOnce", "flushTracking", "getApptimizeSDKVersion", "getApptimizeSDKPlatform", "_initialize", "_getAlterations", "_getVariants", "_getCodeBlockMethod", "runCodeBlock", "isFeatureFlagEnabled", "getString", "getBool", "getInt", "getDouble", "getStringArray", "getBoolArray", "getIntArray", "getDoubleArray", "getStringDictionary", "getBoolDictionary", "getIntDictionary", "getDoubleDictionary", "_getValue", "getVariantInfo", "_getVariantInfoForAlteration", "_getVariantInfoForDynamicVariable", "_getVariantInfoForExperiment", "track", "trackValue"]

    @staticmethod
    def _getApptimizeAnonUserId():
        anonUserId = apptimize_support_persistence_ABTPersistence.loadString(apptimize_support_persistence_ABTPersistence.kAnonymousGuidKey)
        if (((anonUserId is None) or ((anonUserId == ""))) or (not apptimize_api_ABTUserGuid.isValidGuid(anonUserId))):
            anonUserId = apptimize_api_ABTUserGuid.generateUserGuid()
            apptimize_support_persistence_ABTPersistence.saveString(apptimize_support_persistence_ABTPersistence.kAnonymousGuidKey,anonUserId)
        return anonUserId

    @staticmethod
    def setAppVersion(version):
        apptimize_support_properties_ABTApplicationProperties.sharedInstance().setProperty("app_version",version)

    @staticmethod
    def setAppName(name):
        apptimize_support_properties_ABTApplicationProperties.sharedInstance().setProperty("app_name",name)

    @staticmethod
    def setOnParticipationCallback(callback):
        apptimize_events_ABTEventManager.setOnParticipationCallback(callback)

    @staticmethod
    def setOnMetadataUpdatedCallback(callback):
        apptimize_events_ABTEventManager.setOnMetadataUpdatedCallback(callback)

    @staticmethod
    def setup(appKey,configAttributes = None):
        if ((appKey is None) or ((appKey == ""))):
            apptimize_ABTLogger.c("Unable to initialize Apptimize due to missing app key.")
            return
        elif ((apptimize_ABTDataStore.getAppKey() is not None) and ((apptimize_ABTDataStore.getAppKey() == appKey))):
            apptimize_ABTLogger.w((("Apptimize is already initialized with app key: \"" + ("null" if appKey is None else appKey)) + "\"."))
            return
        if ((apptimize_ABTDataStore.getAppKey() is not None) and ((apptimize_ABTDataStore.getAppKey() != appKey))):
            apptimize_ABTDataStore.clear()
        apptimize_ABTLogger.v(("Set Anonymous User ID: " + HxOverrides.stringOrNull(Apptimize._getApptimizeAnonUserId())))
        if (configAttributes is not None):
            apptimize_support_properties_ABTConfigProperties.sharedInstance().setProperties(apptimize_util_ABTUtilDictionary.nativeObjectToStringMap(configAttributes))
            if apptimize_support_properties_ABTConfigProperties.sharedInstance().isPropertyAvailable(apptimize_support_properties_ABTConfigProperties.LOG_LEVEL):
                logLevel = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.LOG_LEVEL)
                apptimize_ABTLogger.setLogLevel(apptimize_ABTLogger.logLevelFromString(logLevel))
        apptimize_ABTLogger.i(((("Apptimize " + HxOverrides.stringOrNull(Apptimize.getApptimizeSDKPlatform())) + ". SDK Version: ") + HxOverrides.stringOrNull(Apptimize.getApptimizeSDKVersion())))
        Apptimize._initialize(appKey)

    @staticmethod
    def updateApptimizeMetadataOnce():
        apptimize_ABTDataStore.checkForUpdatedMetaData(True)

    @staticmethod
    def flushTracking():
        if Apptimize._isInitialized:
            apptimize_ABTDataStore.sharedInstance().flushTracking()
        else:
            apptimize_ABTLogger.w("Tracking can only be flushed after setup().")

    @staticmethod
    def getApptimizeSDKVersion():
        return "1.0.5"

    @staticmethod
    def getApptimizeSDKPlatform():
        return "Python"

    @staticmethod
    def _initialize(appKey):
        apptimize_ABTLogger.i((("Initializing Apptimize with app key \"" + ("null" if appKey is None else appKey)) + "\"."))
        apptimize_ABTDataStore.sharedInstance().loadMetaData(appKey)
        Apptimize._isInitialized = True
        apptimize_support_initialize_ABTPlatformInitialize.initialize()

    @staticmethod
    def _getAlterations(userID,customAttributes = None):
        if (userID is None):
            apptimize_ABTLogger.c(((("The parameter " + "userID") + " is required for ") + "Apptimize._getAlterations"))
        if ((customAttributes is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getAlterations"))
        apptimize_ABTDataStore._checkForUpdatedMetadataIfNecessary()
        alterations = []
        if Apptimize._isInitialized:
            env = apptimize_filter_ABTFilterEnvironment(userID,Apptimize._getApptimizeAnonUserId(),customAttributes)
            metadata = apptimize_ABTDataStore.sharedInstance().getMetaData()
            if (metadata is not None):
                alterations = metadata.selectAlterationsIntoArray(env)
        return alterations

    @staticmethod
    def _getVariants(userID,customAttributes = None):
        apptimize_ABTDataStore._checkForUpdatedMetadataIfNecessary()
        alterations = Apptimize._getAlterations(userID,customAttributes)
        variants = haxe_ds_IntMap()
        _g = 0
        while (_g < len(alterations)):
            alteration = (alterations[_g] if _g >= 0 and _g < len(alterations) else None)
            _g = (_g + 1)
            variant = alteration.getVariant()
            if ((Type.getClass(variant) != apptimize_models_ABTHotfixVariant) and (not (variant.getVariantID() in variants.h))):
                variants.set(variant.getVariantID(),variant)
        return Lambda.array(variants)

    @staticmethod
    def _getCodeBlockMethod(codeBlockVariableName,userID,customAttributes = None):
        if ((userID is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getCodeBlockMethod"))
        if ((customAttributes is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getCodeBlockMethod"))
        apptimize_ABTDataStore._checkForUpdatedMetadataIfNecessary()
        cbVarName = codeBlockVariableName
        if ((cbVarName is None) or ((cbVarName == ""))):
            apptimize_ABTLogger.w("Attempting to runCodeBlock() without specifying a code block name! Returning baseline original variant.")
        else:
            env = apptimize_filter_ABTFilterEnvironment(userID,Apptimize._getApptimizeAnonUserId(),customAttributes)
            _g = 0
            _g1 = Apptimize._getAlterations(userID,customAttributes)
            while (_g < len(_g1)):
                alteration = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if ((alteration is not None) and ((Type.getClass(alteration) == apptimize_models_ABTBlockAlteration))):
                    block = alteration
                    variant = block.getVariant()
                    if (variant.getCodeBlockName() != cbVarName):
                        continue
                    apptimize_ABTDataStore.sharedInstance().incrementVariantRunCount(env,block.getVariant())
                    return block.methodName
            apptimize_ABTLogger.w((("Not participating in any code block experiments with name \"" + ("null" if codeBlockVariableName is None else codeBlockVariableName)) + "\". Returning baseline original variant."))
        return "baseline"

    @staticmethod
    def runCodeBlock(codeBlockVariableName,callback,userID,customAttributes = None):
        methodName = Apptimize._getCodeBlockMethod(codeBlockVariableName,userID,customAttributes)
        callbackMap = apptimize_util_ABTUtilDictionary.nativeObjectToStringMap(callback)
        if ((methodName is None) or ((methodName == ""))):
            apptimize_ABTLogger.w("No code block found, skipping callback.")
            return
        elif ((callback is None) or ((callbackMap.h.get(methodName,None) is None))):
            method = Reflect.getProperty(callback,methodName)
            if (method is not None):
                Reflect.callMethod(callback,method,[])
            else:
                apptimize_ABTLogger.w(("Supplied callbacks do not include method: " + ("null" if methodName is None else methodName)))
        else:
            func = callbackMap.h.get(methodName,None)
            if (not Reflect.isFunction(func)):
                apptimize_ABTLogger.e("runCodeBlock() called with callback that isn't a function.")
                return
            func()

    @staticmethod
    def isFeatureFlagEnabled(name,userID,customAttributes = None):
        return Apptimize.getBool(name,False,userID,customAttributes)

    @staticmethod
    def getString(name,defaultValue,userID,customAttributes = None):
        stringValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.String,None,customAttributes)
        if (stringValue is None):
            return defaultValue
        return stringValue

    @staticmethod
    def getBool(name,defaultValue,userID,customAttributes = None):
        boolValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Boolean,None,customAttributes)
        if (boolValue is None):
            return defaultValue
        return boolValue

    @staticmethod
    def getInt(name,defaultValue,userID,customAttributes = None):
        intValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Integer,None,customAttributes)
        if (intValue is None):
            return defaultValue
        return intValue

    @staticmethod
    def getDouble(name,defaultValue,userID,customAttributes = None):
        floatValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Double,None,customAttributes)
        if (floatValue is None):
            return defaultValue
        return floatValue

    @staticmethod
    def getStringArray(name,defaultValue,userID,customAttributes = None):
        stringArrayValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Array,apptimize_ABTApptimizeVariableType.String,customAttributes)
        if (stringArrayValue is None):
            return defaultValue
        return stringArrayValue

    @staticmethod
    def getBoolArray(name,defaultValue,userID,customAttributes = None):
        boolArrayValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Array,apptimize_ABTApptimizeVariableType.Boolean,customAttributes)
        if (boolArrayValue is None):
            return defaultValue
        return boolArrayValue

    @staticmethod
    def getIntArray(name,defaultValue,userID,customAttributes = None):
        intArrayValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Array,apptimize_ABTApptimizeVariableType.Integer,customAttributes)
        if (intArrayValue is None):
            return defaultValue
        return intArrayValue

    @staticmethod
    def getDoubleArray(name,defaultValue,userID,customAttributes = None):
        doubleArrayValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Array,apptimize_ABTApptimizeVariableType.Double,customAttributes)
        if (doubleArrayValue is None):
            return defaultValue
        return doubleArrayValue

    @staticmethod
    def getStringDictionary(name,defaultValue,userID,customAttributes = None):
        stringDictionaryValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Dictionary,apptimize_ABTApptimizeVariableType.String,customAttributes)
        if (stringDictionaryValue is None):
            return defaultValue
        return stringDictionaryValue

    @staticmethod
    def getBoolDictionary(name,defaultValue,userID,customAttributes = None):
        boolDictionaryValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Dictionary,apptimize_ABTApptimizeVariableType.Boolean,customAttributes)
        if (boolDictionaryValue is None):
            return defaultValue
        return boolDictionaryValue

    @staticmethod
    def getIntDictionary(name,defaultValue,userID,customAttributes = None):
        intDictionaryValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Dictionary,apptimize_ABTApptimizeVariableType.Integer,customAttributes)
        if (intDictionaryValue is None):
            return defaultValue
        return intDictionaryValue

    @staticmethod
    def getDoubleDictionary(name,defaultValue,userID,customAttributes = None):
        doubleDictionaryValue = Apptimize._getValue(name,userID,apptimize_ABTApptimizeVariableType.Dictionary,apptimize_ABTApptimizeVariableType.Double,customAttributes)
        if (doubleDictionaryValue is None):
            return defaultValue
        return doubleDictionaryValue

    @staticmethod
    def _getValue(name,userID,_hx_type,nestedType,customAttributes = None):
        if ((userID is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getValue"))
        if ((customAttributes is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getValue"))
        return apptimize_ABTApptimizeVariable.getValue(name,userID,Apptimize._getApptimizeAnonUserId(),_hx_type,nestedType,customAttributes)

    @staticmethod
    def getVariantInfo(userID,customAttributes = None):
        if ((userID is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize.getVariantInfo"))
        if ((customAttributes is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize.getVariantInfo"))
        variantInfos = list()
        _g = 0
        _g1 = Apptimize._getVariants(userID,customAttributes)
        while (_g < len(_g1)):
            variant = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            x = VariantInfo.initWithVariant(variant)
            variantInfos.append(x)
        return variantInfos

    @staticmethod
    def _getVariantInfoForAlteration(name,userID,customAttributes = None):
        _g = 0
        _g1 = Apptimize._getAlterations(userID,customAttributes)
        while (_g < len(_g1)):
            alteration = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if (alteration.getKey() == name):
                return VariantInfo.initWithVariant(alteration.getVariant())
        return None

    @staticmethod
    def _getVariantInfoForDynamicVariable(name,userID,customAttributes = None):
        return Apptimize._getVariantInfoForAlteration(name,userID,customAttributes)

    @staticmethod
    def _getVariantInfoForExperiment(name,userID,customAttributes = None):
        if ((userID is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getVariantInfoForExperiment"))
        if ((customAttributes is None) and False):
            apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize._getVariantInfoForExperiment"))
        _g = 0
        _g1 = Apptimize._getVariants(userID,customAttributes)
        while (_g < len(_g1)):
            variant = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if (variant.getExperimentName() == name):
                return VariantInfo.initWithVariant(variant)
        return None

    @staticmethod
    def track(eventName,userID,customAttributes = None):
        if Apptimize._isInitialized:
            if ((userID is None) and False):
                apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize.track"))
            if ((customAttributes is None) and False):
                apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize.track"))
            env = apptimize_filter_ABTFilterEnvironment(userID,Apptimize._getApptimizeAnonUserId(),customAttributes)
            apptimize_ABTDataStore.sharedInstance().generateEvent(eventName,Apptimize.kABTEventSourceApptimize,None,env)
        else:
            apptimize_ABTLogger.w("Events can only be tracked after setup() has been called.")

    @staticmethod
    def trackValue(eventName,value,userID,customAttributes = None):
        if Apptimize._isInitialized:
            if ((userID is None) and False):
                apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize.trackValue"))
            if ((customAttributes is None) and False):
                apptimize_ABTLogger.c(((("The parameter " + HxOverrides.stringOrNull(None)) + " is required for ") + "Apptimize.trackValue"))
            if ((not Std._hx_is(value,Float)) and (not Std._hx_is(value,Int))):
                apptimize_ABTLogger.w("trackValue() called with a non-float value. Event not logged.")
                return
            env = apptimize_filter_ABTFilterEnvironment(userID,Apptimize._getApptimizeAnonUserId(),customAttributes)
            tmp = apptimize_ABTDataStore.sharedInstance()
            tmp1 = Apptimize.kABTEventSourceApptimize
            _g = haxe_ds_StringMap()
            _g.h[Apptimize.kABTValueEventKey] = value
            tmp.generateEvent(eventName,tmp1,_g,env)
        else:
            apptimize_ABTLogger.w("Events can only be tracked after setup() has been called.")
Apptimize._hx_class = Apptimize
_hx_classes["Apptimize"] = Apptimize


class Class:
    _hx_class_name = "Class"
Class._hx_class = Class
_hx_classes["Class"] = Class


class Date:
    _hx_class_name = "Date"
    __slots__ = ("date",)
    _hx_fields = ["date"]
    _hx_methods = ["toString"]
    _hx_statics = ["EPOCH_UTC", "now", "fromTime", "UTC", "datetimeTimestamp", "fromString"]

    def __init__(self,year,month,day,hour,_hx_min,sec):
        if (year < python_lib_datetime_Datetime.min.year):
            year = python_lib_datetime_Datetime.min.year
        if (day == 0):
            day = 1
        self.date = python_lib_datetime_Datetime(year,(month + 1),day,hour,_hx_min,sec,0)

    def toString(self):
        m = ((self.date.month - 1) + 1)
        d = self.date.day
        h = self.date.hour
        mi = self.date.minute
        s = self.date.second
        return ((((((((((Std.string(self.date.year) + "-") + HxOverrides.stringOrNull(((("0" + Std.string(m)) if ((m < 10)) else ("" + Std.string(m)))))) + "-") + HxOverrides.stringOrNull(((("0" + Std.string(d)) if ((d < 10)) else ("" + Std.string(d)))))) + " ") + HxOverrides.stringOrNull(((("0" + Std.string(h)) if ((h < 10)) else ("" + Std.string(h)))))) + ":") + HxOverrides.stringOrNull(((("0" + Std.string(mi)) if ((mi < 10)) else ("" + Std.string(mi)))))) + ":") + HxOverrides.stringOrNull(((("0" + Std.string(s)) if ((s < 10)) else ("" + Std.string(s))))))

    @staticmethod
    def now():
        d = Date(1970,0,1,0,0,0)
        d.date = python_lib_datetime_Datetime.now()
        return d

    @staticmethod
    def fromTime(t):
        d = Date(1970,0,1,0,0,0)
        d.date = python_lib_datetime_Datetime.fromtimestamp((t / 1000.0))
        return d

    @staticmethod
    def UTC(year,month,day,hour,_hx_min,sec):
        dt = python_lib_datetime_Datetime(year,(month + 1),day,hour,_hx_min,sec,0,python_lib_datetime_Timezone.utc)
        return Date.datetimeTimestamp(dt,Date.EPOCH_UTC)

    @staticmethod
    def datetimeTimestamp(dt,epoch):
        return ((dt - epoch).total_seconds() * 1000)

    @staticmethod
    def fromString(s):
        _g = len(s)
        _g1 = _g
        if (_g1 == 8):
            k = s.split(":")
            d = Date(0,0,0,Std.parseInt((k[0] if 0 < len(k) else None)),Std.parseInt((k[1] if 1 < len(k) else None)),Std.parseInt((k[2] if 2 < len(k) else None)))
            return d
        elif (_g1 == 10):
            k1 = s.split("-")
            return Date(Std.parseInt((k1[0] if 0 < len(k1) else None)),(Std.parseInt((k1[1] if 1 < len(k1) else None)) - 1),Std.parseInt((k1[2] if 2 < len(k1) else None)),0,0,0)
        elif (_g1 == 19):
            k2 = s.split(" ")
            _this = (k2[0] if 0 < len(k2) else None)
            y = _this.split("-")
            _this1 = (k2[1] if 1 < len(k2) else None)
            t = _this1.split(":")
            return Date(Std.parseInt((y[0] if 0 < len(y) else None)),(Std.parseInt((y[1] if 1 < len(y) else None)) - 1),Std.parseInt((y[2] if 2 < len(y) else None)),Std.parseInt((t[0] if 0 < len(t) else None)),Std.parseInt((t[1] if 1 < len(t) else None)),Std.parseInt((t[2] if 2 < len(t) else None)))
        else:
            raise _HxException(("Invalid date format : " + ("null" if s is None else s)))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.date = None
Date._hx_class = Date
_hx_classes["Date"] = Date


class EReg:
    _hx_class_name = "EReg"
    __slots__ = ("pattern", "matchObj", "_hx_global")
    _hx_fields = ["pattern", "matchObj", "global"]

    def __init__(self,r,opt):
        self.matchObj = None
        self._hx_global = False
        options = 0
        _g1 = 0
        _g = len(opt)
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            c = (-1 if ((i >= len(opt))) else ord(opt[i]))
            if (c == 109):
                options = (options | python_lib_Re.M)
            if (c == 105):
                options = (options | python_lib_Re.I)
            if (c == 115):
                options = (options | python_lib_Re.S)
            if (c == 117):
                options = (options | python_lib_Re.U)
            if (c == 103):
                self._hx_global = True
        self.pattern = python_lib_Re.compile(r,options)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.pattern = None
        _hx_o.matchObj = None
        _hx_o._hx_global = None
EReg._hx_class = EReg
_hx_classes["EReg"] = EReg


class EnumValue:
    _hx_class_name = "EnumValue"
EnumValue._hx_class = EnumValue
_hx_classes["EnumValue"] = EnumValue


class Lambda:
    _hx_class_name = "Lambda"
    __slots__ = ()
    _hx_statics = ["array"]

    @staticmethod
    def array(it):
        a = list()
        i = HxOverrides.iterator(it)
        while i.hasNext():
            i1 = i.next()
            a.append(i1)
        return a
Lambda._hx_class = Lambda
_hx_classes["Lambda"] = Lambda


class List:
    _hx_class_name = "List"
    __slots__ = ("h", "q", "length")
    _hx_fields = ["h", "q", "length"]
    _hx_methods = ["add", "iterator"]

    def __init__(self):
        self.q = None
        self.h = None
        self.length = 0

    def add(self,item):
        x = _List_ListNode(item,None)
        if (self.h is None):
            self.h = x
        else:
            self.q.next = x
        self.q = x
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.length
        _hx_local_0.length = (_hx_local_1 + 1)
        _hx_local_1

    def iterator(self):
        return _List_ListIterator(self.h)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
        _hx_o.q = None
        _hx_o.length = None
List._hx_class = List
_hx_classes["List"] = List


class _List_ListNode:
    _hx_class_name = "_List.ListNode"
    __slots__ = ("item", "next")
    _hx_fields = ["item", "next"]

    def __init__(self,item,next):
        self.item = item
        self.next = next

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.item = None
        _hx_o.next = None
_List_ListNode._hx_class = _List_ListNode
_hx_classes["_List.ListNode"] = _List_ListNode


class _List_ListIterator:
    _hx_class_name = "_List.ListIterator"
    __slots__ = ("head",)
    _hx_fields = ["head"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,head):
        self.head = head

    def hasNext(self):
        return (self.head is not None)

    def next(self):
        val = self.head.item
        self.head = self.head.next
        return val

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.head = None
_List_ListIterator._hx_class = _List_ListIterator
_hx_classes["_List.ListIterator"] = _List_ListIterator


class _Math_Math_Impl_:
    _hx_class_name = "_Math.Math_Impl_"
    __slots__ = ()
    _hx_statics = ["random"]

    @staticmethod
    def random():
        return python_lib_Random.random()
_Math_Math_Impl_._hx_class = _Math_Math_Impl_
_hx_classes["_Math.Math_Impl_"] = _Math_Math_Impl_


class Reflect:
    _hx_class_name = "Reflect"
    __slots__ = ()
    _hx_statics = ["field", "getProperty", "callMethod", "isFunction"]

    @staticmethod
    def field(o,field):
        return python_Boot.field(o,field)

    @staticmethod
    def getProperty(o,field):
        if (o is None):
            return None
        if (field in python_Boot.keywords):
            field = ("_hx_" + field)
        elif ((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95))):
            field = ("_hx_" + field)
        else:
            field = field
        tmp = Reflect.field(o,("get_" + ("null" if field is None else field)))
        if ((tmp is not None) and callable(tmp)):
            return tmp()
        else:
            return Reflect.field(o,field)

    @staticmethod
    def callMethod(o,func,args):
        if callable(func):
            return func(*args)
        else:
            return None

    @staticmethod
    def isFunction(f):
        if (not ((python_lib_Inspect.isfunction(f) or python_lib_Inspect.ismethod(f)))):
            return hasattr(f,"func_code")
        else:
            return True
Reflect._hx_class = Reflect
_hx_classes["Reflect"] = Reflect


class Std:
    _hx_class_name = "Std"
    __slots__ = ()
    _hx_statics = ["is", "string", "parseInt", "shortenPossibleNumber", "parseFloat"]

    @staticmethod
    def _hx_is(v,t):
        if ((v is None) and ((t is None))):
            return False
        if (t is None):
            return False
        if (t == Dynamic):
            return True
        isBool = isinstance(v,bool)
        if ((t == Bool) and isBool):
            return True
        if ((((not isBool) and (not (t == Bool))) and (t == Int)) and isinstance(v,int)):
            return True
        vIsFloat = isinstance(v,float)
        tmp = None
        tmp1 = None
        tmp2 = None
        tmp3 = None
        if (((not isBool) and vIsFloat) and (t == Int)):
            f = v
            if ((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))):
                tmp3 = (not python_lib_Math.isnan(f))
            else:
                tmp3 = False
        else:
            tmp3 = False
        if tmp3:
            tmp4 = None
            try:
                tmp4 = int(v)
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                e = _hx_e1
                tmp4 = None
            tmp2 = (v == tmp4)
        else:
            tmp2 = False
        if tmp2:
            tmp1 = (v <= 2147483647)
        else:
            tmp1 = False
        if tmp1:
            tmp = (v >= -2147483648)
        else:
            tmp = False
        if tmp:
            return True
        if (((not isBool) and (t == Float)) and isinstance(v,(float, int))):
            return True
        if (t == str):
            return isinstance(v,str)
        isEnumType = (t == Enum)
        if ((isEnumType and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_constructs")):
            return True
        if isEnumType:
            return False
        isClassType = (t == Class)
        if ((((isClassType and (not isinstance(v,Enum))) and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_class_name")) and (not hasattr(v,"_hx_constructs"))):
            return True
        if isClassType:
            return False
        tmp5 = None
        try:
            tmp5 = isinstance(v,t)
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            e1 = _hx_e1
            tmp5 = False
        if tmp5:
            return True
        if python_lib_Inspect.isclass(t):
            loop = None
            def _hx_local_1(intf):
                f1 = (intf._hx_interfaces if (hasattr(intf,"_hx_interfaces")) else [])
                if (f1 is not None):
                    _g = 0
                    while (_g < len(f1)):
                        i = (f1[_g] if _g >= 0 and _g < len(f1) else None)
                        _g = (_g + 1)
                        if HxOverrides.eq(i,t):
                            return True
                        else:
                            l = loop(i)
                            if l:
                                return True
                    return False
                else:
                    return False
            loop = _hx_local_1
            loop1 = loop
            currentClass = v.__class__
            while (currentClass is not None):
                if loop1(currentClass):
                    return True
                currentClass = python_Boot.getSuperClass(currentClass)
            return False
        else:
            return False

    @staticmethod
    def string(s):
        return python_Boot.toString1(s,"")

    @staticmethod
    def parseInt(x):
        if (x is None):
            return None
        try:
            return int(x)
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            e = _hx_e1
            try:
                prefix = HxString.substr(x,0,2).lower()
                if (prefix == "0x"):
                    return int(x,16)
                raise _HxException("fail")
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                e1 = _hx_e1
                x1 = Std.parseFloat(x)
                r = None
                try:
                    r = int(x1)
                except Exception as _hx_e:
                    _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                    e2 = _hx_e1
                    r = None
                if (r is None):
                    r1 = Std.shortenPossibleNumber(x)
                    if (r1 != x):
                        return Std.parseInt(r1)
                    else:
                        return None
                return r

    @staticmethod
    def shortenPossibleNumber(x):
        r = ""
        _g1 = 0
        _g = len(x)
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            c = ("" if (((i < 0) or ((i >= len(x))))) else x[i])
            _g2 = HxString.charCodeAt(c,0)
            if (_g2 is None):
                break
            else:
                _g21 = _g2
                if (((((((((((_g21 == 57) or ((_g21 == 56))) or ((_g21 == 55))) or ((_g21 == 54))) or ((_g21 == 53))) or ((_g21 == 52))) or ((_g21 == 51))) or ((_g21 == 50))) or ((_g21 == 49))) or ((_g21 == 48))) or ((_g21 == 46))):
                    r = (("null" if r is None else r) + ("null" if c is None else c))
                else:
                    break
        return r

    @staticmethod
    def parseFloat(x):
        try:
            return float(x)
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            e = _hx_e1
            if (x is not None):
                r1 = Std.shortenPossibleNumber(x)
                if (r1 != x):
                    return Std.parseFloat(r1)
            return Math.NaN
Std._hx_class = Std
_hx_classes["Std"] = Std


class Float:
    _hx_class_name = "Float"
Float._hx_class = Float
_hx_classes["Float"] = Float


class Int:
    _hx_class_name = "Int"
Int._hx_class = Int
_hx_classes["Int"] = Int


class Bool:
    _hx_class_name = "Bool"
Bool._hx_class = Bool
_hx_classes["Bool"] = Bool


class Dynamic:
    _hx_class_name = "Dynamic"
Dynamic._hx_class = Dynamic
_hx_classes["Dynamic"] = Dynamic


class StringBuf:
    _hx_class_name = "StringBuf"
    __slots__ = ("b",)
    _hx_fields = ["b"]

    def __init__(self):
        self.b = python_lib_io_StringIO()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
        _hx_o.length = None
StringBuf._hx_class = StringBuf
_hx_classes["StringBuf"] = StringBuf


class StringTools:
    _hx_class_name = "StringTools"
    __slots__ = ()
    _hx_statics = ["isSpace", "ltrim", "rtrim", "trim", "lpad", "replace", "hex"]

    @staticmethod
    def isSpace(s,pos):
        if (((len(s) == 0) or ((pos < 0))) or ((pos >= len(s)))):
            return False
        c = HxString.charCodeAt(s,pos)
        if (not (((c > 8) and ((c < 14))))):
            return (c == 32)
        else:
            return True

    @staticmethod
    def ltrim(s):
        l = len(s)
        r = 0
        while ((r < l) and StringTools.isSpace(s,r)):
            r = (r + 1)
        if (r > 0):
            return HxString.substr(s,r,(l - r))
        else:
            return s

    @staticmethod
    def rtrim(s):
        l = len(s)
        r = 0
        while ((r < l) and StringTools.isSpace(s,((l - r) - 1))):
            r = (r + 1)
        if (r > 0):
            return HxString.substr(s,0,(l - r))
        else:
            return s

    @staticmethod
    def trim(s):
        return StringTools.ltrim(StringTools.rtrim(s))

    @staticmethod
    def lpad(s,c,l):
        if (len(c) <= 0):
            return s
        while (len(s) < l):
            s = (("null" if c is None else c) + ("null" if s is None else s))
        return s

    @staticmethod
    def replace(s,sub,by):
        _this = (list(s) if ((sub == "")) else s.split(sub))
        return by.join([python_Boot.toString1(x1,'') for x1 in _this])

    @staticmethod
    def hex(n,digits = None):
        s = ""
        hexChars = "0123456789ABCDEF"
        while True:
            index = (n & 15)
            s = (HxOverrides.stringOrNull((("" if (((index < 0) or ((index >= len(hexChars))))) else hexChars[index]))) + ("null" if s is None else s))
            n = HxOverrides.rshift(n, 4)
            if (not ((n > 0))):
                break
        if ((digits is not None) and ((len(s) < digits))):
            diff = (digits - len(s))
            _g1 = 0
            _g = diff
            while (_g1 < _g):
                _ = _g1
                _g1 = (_g1 + 1)
                s = ("0" + ("null" if s is None else s))
        return s
StringTools._hx_class = StringTools
_hx_classes["StringTools"] = StringTools


class sys_FileSystem:
    _hx_class_name = "sys.FileSystem"
    __slots__ = ()
    _hx_statics = ["exists", "createDirectory", "deleteFile"]

    @staticmethod
    def exists(path):
        return python_lib_os_Path.exists(path)

    @staticmethod
    def createDirectory(path):
        python_lib_Os.makedirs(path,511,True)

    @staticmethod
    def deleteFile(path):
        python_lib_Os.remove(path)
sys_FileSystem._hx_class = sys_FileSystem
_hx_classes["sys.FileSystem"] = sys_FileSystem


class haxe_IMap:
    _hx_class_name = "haxe.IMap"
    __slots__ = ()
haxe_IMap._hx_class = haxe_IMap
_hx_classes["haxe.IMap"] = haxe_IMap


class haxe_ds_StringMap:
    _hx_class_name = "haxe.ds.StringMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["remove", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def remove(self,key):
        has = (key in self.h)
        if has:
            del self.h[key]
        return has

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_StringMap._hx_class = haxe_ds_StringMap
_hx_classes["haxe.ds.StringMap"] = haxe_ds_StringMap


class python_HaxeIterator:
    _hx_class_name = "python.HaxeIterator"
    __slots__ = ("it", "x", "has", "checked")
    _hx_fields = ["it", "x", "has", "checked"]
    _hx_methods = ["next", "hasNext"]

    def __init__(self,it):
        self.checked = False
        self.has = False
        self.x = None
        self.it = it

    def next(self):
        if (not self.checked):
            self.hasNext()
        self.checked = False
        return self.x

    def hasNext(self):
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                if isinstance(_hx_e1, StopIteration):
                    s = _hx_e1
                    self.has = False
                    self.x = None
                else:
                    raise _hx_e
            self.checked = True
        return self.has

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.it = None
        _hx_o.x = None
        _hx_o.has = None
        _hx_o.checked = None
python_HaxeIterator._hx_class = python_HaxeIterator
_hx_classes["python.HaxeIterator"] = python_HaxeIterator

class ValueType(Enum):
    __slots__ = ()
    _hx_class_name = "ValueType"
    _hx_constructs = ["TNull", "TInt", "TFloat", "TBool", "TObject", "TFunction", "TClass", "TEnum", "TUnknown"]

    @staticmethod
    def TClass(c):
        return ValueType("TClass", 6, [c])

    @staticmethod
    def TEnum(e):
        return ValueType("TEnum", 7, [e])
ValueType.TNull = ValueType("TNull", 0, list())
ValueType.TInt = ValueType("TInt", 1, list())
ValueType.TFloat = ValueType("TFloat", 2, list())
ValueType.TBool = ValueType("TBool", 3, list())
ValueType.TObject = ValueType("TObject", 4, list())
ValueType.TFunction = ValueType("TFunction", 5, list())
ValueType.TUnknown = ValueType("TUnknown", 8, list())
ValueType._hx_class = ValueType
_hx_classes["ValueType"] = ValueType


class Type:
    _hx_class_name = "Type"
    __slots__ = ()
    _hx_statics = ["getClass", "getSuperClass", "getClassName", "getEnumName", "resolveClass", "resolveEnum", "createEmptyInstance", "createEnum", "getEnumConstructs", "typeof"]

    @staticmethod
    def getClass(o):
        if (o is None):
            return None
        if ((o is not None) and (((o == str) or python_lib_Inspect.isclass(o)))):
            return None
        if isinstance(o,_hx_AnonObject):
            return None
        if hasattr(o,"_hx_class"):
            return o._hx_class
        if hasattr(o,"__class__"):
            return o.__class__
        else:
            return None

    @staticmethod
    def getSuperClass(c):
        return python_Boot.getSuperClass(c)

    @staticmethod
    def getClassName(c):
        if hasattr(c,"_hx_class_name"):
            return c._hx_class_name
        else:
            if (c == list):
                return "Array"
            if (c == Math):
                return "Math"
            if (c == str):
                return "String"
            try:
                return c.__name__
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                e = _hx_e1
                return None

    @staticmethod
    def getEnumName(e):
        return e._hx_class_name

    @staticmethod
    def resolveClass(name):
        if (name == "Array"):
            return list
        if (name == "Math"):
            return Math
        if (name == "String"):
            return str
        cl = _hx_classes.get(name,None)
        if ((cl is None) or (not (((cl is not None) and (((cl == str) or python_lib_Inspect.isclass(cl))))))):
            return None
        return cl

    @staticmethod
    def resolveEnum(name):
        if (name == "Bool"):
            return Bool
        o = Type.resolveClass(name)
        if hasattr(o,"_hx_constructs"):
            return o
        else:
            return None

    @staticmethod
    def createEmptyInstance(cl):
        i = cl.__new__(cl)
        callInit = None
        def _hx_local_0(cl1):
            sc = Type.getSuperClass(cl1)
            if (sc is not None):
                callInit(sc)
            if hasattr(cl1,"_hx_empty_init"):
                cl1._hx_empty_init(i)
        callInit = _hx_local_0
        callInit1 = callInit
        callInit1(cl)
        return i

    @staticmethod
    def createEnum(e,constr,params = None):
        f = Reflect.field(e,constr)
        if (f is None):
            raise _HxException(("No such constructor " + ("null" if constr is None else constr)))
        if Reflect.isFunction(f):
            if (params is None):
                raise _HxException((("Constructor " + ("null" if constr is None else constr)) + " need parameters"))
            return Reflect.callMethod(e,f,params)
        if ((params is not None) and ((len(params) != 0))):
            raise _HxException((("Constructor " + ("null" if constr is None else constr)) + " does not need parameters"))
        return f

    @staticmethod
    def getEnumConstructs(e):
        if hasattr(e,"_hx_constructs"):
            x = e._hx_constructs
            return list(x)
        else:
            return []

    @staticmethod
    def typeof(v):
        if (v is None):
            return ValueType.TNull
        elif isinstance(v,bool):
            return ValueType.TBool
        elif isinstance(v,int):
            return ValueType.TInt
        elif isinstance(v,float):
            return ValueType.TFloat
        elif isinstance(v,str):
            return ValueType.TClass(str)
        elif isinstance(v,list):
            return ValueType.TClass(list)
        elif (isinstance(v,_hx_AnonObject) or python_lib_Inspect.isclass(v)):
            return ValueType.TObject
        elif isinstance(v,Enum):
            return ValueType.TEnum(v.__class__)
        elif (isinstance(v,type) or hasattr(v,"_hx_class")):
            return ValueType.TClass(v.__class__)
        elif callable(v):
            return ValueType.TFunction
        else:
            return ValueType.TUnknown
Type._hx_class = Type
_hx_classes["Type"] = Type


class VariantInfo:
    _hx_class_name = "VariantInfo"
    __slots__ = ("_variantId", "_variantName", "_experimentId", "_experimentName", "_currentPhase", "_participationPhase", "_cycle")
    _hx_fields = ["_variantId", "_variantName", "_experimentId", "_experimentName", "_currentPhase", "_participationPhase", "_cycle"]
    _hx_methods = ["getVariantId", "getVariantName", "getExperimentId", "getExperimentName", "getCurrentPhase", "getParticipationPhase", "getCycle"]
    _hx_statics = ["initWithVariant"]

    def __init__(self,variantId,variantName,experimentId,experimentName,cycle,currentPhase,participationPhase):
        self._variantId = variantId
        self._variantName = variantName
        self._experimentId = experimentId
        self._experimentName = experimentName
        self._cycle = cycle
        self._currentPhase = currentPhase
        self._participationPhase = participationPhase

    def getVariantId(self):
        return self._variantId

    def getVariantName(self):
        return self._variantName

    def getExperimentId(self):
        return self._experimentId

    def getExperimentName(self):
        return self._experimentName

    def getCurrentPhase(self):
        return self._currentPhase

    def getParticipationPhase(self):
        return self._participationPhase

    def getCycle(self):
        return self._cycle

    @staticmethod
    def initWithVariant(variant):
        participationPhase = 0
        variantString = ((("v" + Std.string(variant.getVariantID())) + "_") + Std.string(variant.getCycle()))
        if apptimize_support_properties_ABTInternalProperties.sharedInstance().isNamespacedPropertyAvailable(variantString,apptimize_support_properties_CustomPropertyNamespace.ApptimizeInternal):
            participationPhase = apptimize_support_properties_ABTInternalProperties.sharedInstance().valueForNamespacedProperty(variantString,apptimize_support_properties_CustomPropertyNamespace.ApptimizeInternal)
        return VariantInfo(variant.getVariantID(),variant.getVariantName(),variant.getExperimentID(),variant.getExperimentName(),variant.getCycle(),variant.getPhase(),participationPhase)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._variantId = None
        _hx_o._variantName = None
        _hx_o._experimentId = None
        _hx_o._experimentName = None
        _hx_o._currentPhase = None
        _hx_o._participationPhase = None
        _hx_o._cycle = None
VariantInfo._hx_class = VariantInfo
_hx_classes["VariantInfo"] = VariantInfo

class apptimize_ABTApptimizeVariableType(Enum):
    __slots__ = ()
    _hx_class_name = "apptimize.ABTApptimizeVariableType"
    _hx_constructs = ["Invalid", "String", "Double", "Integer", "Boolean", "Array", "Dictionary"]
apptimize_ABTApptimizeVariableType.Invalid = apptimize_ABTApptimizeVariableType("Invalid", 0, list())
apptimize_ABTApptimizeVariableType.String = apptimize_ABTApptimizeVariableType("String", 1, list())
apptimize_ABTApptimizeVariableType.Double = apptimize_ABTApptimizeVariableType("Double", 2, list())
apptimize_ABTApptimizeVariableType.Integer = apptimize_ABTApptimizeVariableType("Integer", 3, list())
apptimize_ABTApptimizeVariableType.Boolean = apptimize_ABTApptimizeVariableType("Boolean", 4, list())
apptimize_ABTApptimizeVariableType.Array = apptimize_ABTApptimizeVariableType("Array", 5, list())
apptimize_ABTApptimizeVariableType.Dictionary = apptimize_ABTApptimizeVariableType("Dictionary", 6, list())
apptimize_ABTApptimizeVariableType._hx_class = apptimize_ABTApptimizeVariableType
_hx_classes["apptimize.ABTApptimizeVariableType"] = apptimize_ABTApptimizeVariableType


class apptimize_ABTApptimizeVariable:
    _hx_class_name = "apptimize.ABTApptimizeVariable"
    __slots__ = ()
    _hx_statics = ["getValue", "apptimizeVariableTypeForString"]

    @staticmethod
    def getValue(name,userID,anonID,_hx_type,nestedType = None,customAttributes = None):
        apptimize_ABTDataStore._checkForUpdatedMetadataIfNecessary()
        env = apptimize_filter_ABTFilterEnvironment(userID,anonID,customAttributes)
        metadata = apptimize_ABTDataStore.sharedInstance().getMetaData()
        if (metadata is None):
            return None
        alterations = metadata.selectAlterationsIntoArray(env)
        _g = 0
        while (_g < len(alterations)):
            alteration = (alterations[_g] if _g >= 0 and _g < len(alterations) else None)
            _g = (_g + 1)
            try:
                if (alteration.getKey() == name):
                    def _hx_local_0():
                        _hx_local_1 = alteration
                        if Std._hx_is(_hx_local_1,apptimize_models_ABTValueAlteration):
                            _hx_local_1
                        else:
                            raise _HxException("Class cast error")
                        return _hx_local_1
                    valueAlteration = _hx_local_0()
                    alterationType = apptimize_ABTApptimizeVariable.apptimizeVariableTypeForString(valueAlteration.getType())
                    alterationNestedType = None
                    if (valueAlteration.getNestedType() is not None):
                        alterationNestedType = apptimize_ABTApptimizeVariable.apptimizeVariableTypeForString(valueAlteration.getNestedType())
                    if ((alterationType == _hx_type) and ((alterationNestedType == nestedType))):
                        variant = valueAlteration.getVariant()
                        apptimize_ABTDataStore.sharedInstance().incrementVariantRunCount(env,variant)
                        if (not valueAlteration.useDefaultValue()):
                            return valueAlteration.getValue()
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                if isinstance(_hx_e1, str):
                    msg = _hx_e1
                    apptimize_ABTLogger.w((("Alteration found for key \"" + HxOverrides.stringOrNull(alteration.getKey())) + "\" isn't a value alteration."))
                    return None
                else:
                    raise _hx_e
        apptimize_ABTLogger.w((("No alteration found for dynamic variable \"" + ("null" if name is None else name)) + "\"."))
        return None

    @staticmethod
    def apptimizeVariableTypeForString(stringType):
        _hx_type = stringType.lower()
        if (_hx_type == "string"):
            return apptimize_ABTApptimizeVariableType.String
        elif (_hx_type == "double"):
            return apptimize_ABTApptimizeVariableType.Double
        elif (_hx_type == "int"):
            return apptimize_ABTApptimizeVariableType.Integer
        elif (_hx_type == "boolean"):
            return apptimize_ABTApptimizeVariableType.Boolean
        elif (_hx_type == "list"):
            return apptimize_ABTApptimizeVariableType.Array
        elif (_hx_type == "dictionary"):
            return apptimize_ABTApptimizeVariableType.Dictionary
        else:
            return apptimize_ABTApptimizeVariableType.Invalid
apptimize_ABTApptimizeVariable._hx_class = apptimize_ABTApptimizeVariable
_hx_classes["apptimize.ABTApptimizeVariable"] = apptimize_ABTApptimizeVariable


class apptimize_ABTDataStore:
    _hx_class_name = "apptimize.ABTDataStore"
    __slots__ = ("resultLogs", "applicationResultLog", "metaData")
    _hx_fields = ["resultLogs", "applicationResultLog", "metaData"]
    _hx_methods = ["hasMetadata", "_getCurrentEtag", "loadMetaData", "reloadFromDisk", "overrideMetadata", "getMetaData", "writeToDiskIfNeeded", "_saveResultLogs", "addResultLogEntry", "flushTracking", "incrementVariantRunCount", "generateEvent"]
    _hx_statics = ["appKey", "serverGuid", "_instance", "_lastCheckTime", "_lastSubmitCheckTime", "sharedInstance", "clear", "_resetCheckTimeIfNeeded", "_resetSubmitTimeIfNeeded", "getAppKey", "checkForUpdatedMetaData", "_checkForUpdatedMetadataIfNecessary", "_submitResultsIfNecessary", "_submitResultLog", "getServerGUID"]

    def __init__(self):
        self.metaData = None
        self.applicationResultLog = None
        results_cache_size = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.RESULTS_CACHE_SIZE)
        self.resultLogs = apptimize_support_persistence_ABTPersistence.loadObject(apptimize_support_persistence_ABTPersistence.kResultLogsKey)
        if (self.resultLogs is None):
            self.resultLogs = apptimize_util_ABTLRUCache(Std.parseInt(results_cache_size))
        self.applicationResultLog = apptimize_models_results_ABTResultLog(None)

    def hasMetadata(self):
        return (self.metaData is not None)

    def _getCurrentEtag(self):
        if (self.metaData is not None):
            return self.metaData.getEtag()
        return None

    def loadMetaData(self,appKey):
        apptimize_ABTDataStore.appKey = appKey
        self.reloadFromDisk()
        if (not self.hasMetadata()):
            apptimize_api_ABTApiClient.sharedInstance().downloadMetaDataForKey(appKey,self._getCurrentEtag())
            apptimize_ABTDataStore._resetCheckTimeIfNeeded()

    def reloadFromDisk(self):
        metadata = apptimize_support_persistence_ABTPersistence.loadObject(apptimize_support_persistence_ABTPersistence.kMetadataKey)
        if (metadata is not None):
            apptimize_ABTLogger.v("Existing metadata loaded from storage, will update if necessary.")
            self.overrideMetadata(metadata,False)
        else:
            apptimize_ABTLogger.v("No existing metadata found in storage.")

    def overrideMetadata(self,md,shouldWriteToDisk = True):
        if (shouldWriteToDisk is None):
            shouldWriteToDisk = True
        if ((md.getAppKey() == apptimize_ABTDataStore.getAppKey()) and ((((self.metaData is None) or ((self.metaData.getSequenceNumber() < md.getSequenceNumber()))) or ((self.metaData.getAppKey() != md.getAppKey()))))):
            self.metaData = md
            if shouldWriteToDisk:
                self.writeToDiskIfNeeded()
            apptimize_events_ABTEventManager.dispatchOnMetadataUpdated()
            apptimize_ABTLogger.i((("Updated metadata for app key \"" + HxOverrides.stringOrNull(md.getAppKey())) + "\"."))
            apptimize_ABTLogger.v(("New metadata:\n" + HxOverrides.stringOrNull(haxe_format_JsonPrinter.print(md.getMetaData(),None,"  "))))
        else:
            apptimize_ABTLogger.i("Existing metadata is up-to-date.")

    def getMetaData(self):
        md = None
        apptimize_util_ABTDataLock.lock(apptimize_util_ABTDataLock.METADATA_LOCK_KEY)
        md = self.metaData
        apptimize_util_ABTDataLock.release(apptimize_util_ABTDataLock.METADATA_LOCK_KEY)
        return md

    def writeToDiskIfNeeded(self):
        md = self.getMetaData()
        if (md is not None):
            apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kMetadataKey,md)

    def _saveResultLogs(self):
        apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kResultLogsKey,self.resultLogs)

    def addResultLogEntry(self,env,entry):
        resultLog = self.resultLogs.getValue(env.getUserOrAnonID())
        if (resultLog is None):
            resultLog = apptimize_models_results_ABTResultLog(env)
            self.resultLogs.insert(env.getUserOrAnonID(),resultLog,apptimize_ABTDataStore._submitResultLog)
        resultLog.logEntry(entry)
        if (resultLog.entryCount() > apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_ENTRIES_KEY)):
            self.resultLogs.remove(env.getUserOrAnonID(),apptimize_ABTDataStore._submitResultLog)
        self._saveResultLogs()

    def flushTracking(self):
        apptimize_api_ABTApiClient.sharedInstance().flushFailedResultsQueue()
        self.resultLogs.clear(apptimize_ABTDataStore._submitResultLog)
        self._saveResultLogs()

    def incrementVariantRunCount(self,env,variant):
        if (Type.getClass(variant) == apptimize_models_ABTHotfixVariant):
            return
        variantStickyString = ((("v" + Std.string(variant.getVariantID())) + "_") + Std.string(variant.getCycle()))
        experimentStickyString = ((("e" + Std.string(variant.getExperimentID())) + "_") + Std.string(variant.getCycle()))
        phase = variant.getPhase()
        variantShownEntry = apptimize_models_results_ABTResultEntryVariantShown(env,variant.getVariantID(),variant.getCycle(),phase)
        apptimize_ABTLogger.v((("Incrementing variant run count for variant ID \"" + Std.string(variant.getVariantID())) + "\"."))
        apptimize_events_ABTEventManager.dispatchOnParticipation(variant.getExperimentName(),variant.getVariantName())
        self.addResultLogEntry(env,variantShownEntry)

    def generateEvent(self,eventName,eventSource,eventAttributes,env):
        if (not Apptimize._isInitialized):
            apptimize_ABTLogger.w((("Event \"" + ("null" if eventName is None else eventName)) + "\" will not be tracked until Apptimize.setup() is called."))
            return
        eventEntry = apptimize_models_results_ABTResultEntryEvent(env,eventName,eventSource,eventAttributes)
        apptimize_ABTLogger.v((((("Event logged with name \"" + ("null" if eventName is None else eventName)) + "\" and source \"") + ("null" if eventSource is None else eventSource)) + "\"."))
        self.addResultLogEntry(env,eventEntry)
    appKey = None
    serverGuid = None
    _instance = None

    @staticmethod
    def sharedInstance():
        if (apptimize_ABTDataStore._instance is None):
            apptimize_ABTDataStore._instance = apptimize_ABTDataStore()
        return apptimize_ABTDataStore._instance

    @staticmethod
    def clear():
        apptimize_support_persistence_ABTPersistence.clear()
        apptimize_ABTDataStore._instance = None

    @staticmethod
    def _resetCheckTimeIfNeeded():
        resetClock = False
        apptimize_util_ABTDataLock.lock(apptimize_util_ABTDataLock.CHECK_TIME_LOCK_KEY)
        timeout = Std.parseFloat(apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.FOREGROUND_PERIOD_MS_KEY))
        currentTime = (python_lib_Time.mktime(Date.now().date.timetuple()) * 1000)
        timeSinceLastCheck = (currentTime - apptimize_ABTDataStore._lastCheckTime)
        if (timeSinceLastCheck > timeout):
            apptimize_ABTDataStore._lastCheckTime = currentTime
            resetClock = True
        apptimize_util_ABTDataLock.release(apptimize_util_ABTDataLock.CHECK_TIME_LOCK_KEY)
        return resetClock

    @staticmethod
    def _resetSubmitTimeIfNeeded():
        resetClock = False
        apptimize_util_ABTDataLock.lock(apptimize_util_ABTDataLock.CHECK_TIME_LOCK_KEY)
        timeout = Std.parseFloat(apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.RESULT_POST_DELAY_MS_KEY))
        currentTime = (python_lib_Time.mktime(Date.now().date.timetuple()) * 1000)
        timeSinceLastCheck = (currentTime - apptimize_ABTDataStore._lastSubmitCheckTime)
        if (timeSinceLastCheck > timeout):
            apptimize_ABTDataStore._lastSubmitCheckTime = currentTime
            resetClock = True
        apptimize_util_ABTDataLock.release(apptimize_util_ABTDataLock.CHECK_TIME_LOCK_KEY)
        return resetClock

    @staticmethod
    def getAppKey():
        return apptimize_ABTDataStore.appKey

    @staticmethod
    def checkForUpdatedMetaData(checkImmediately = False):
        if (checkImmediately is None):
            checkImmediately = False
        if (Apptimize._isInitialized and ((apptimize_ABTDataStore._resetCheckTimeIfNeeded() or checkImmediately))):
            apptimize_api_ABTApiClient.sharedInstance().downloadMetaDataForKey(apptimize_ABTDataStore.getAppKey(),apptimize_ABTDataStore.sharedInstance()._getCurrentEtag())

    @staticmethod
    def _checkForUpdatedMetadataIfNecessary():
        if (apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_INTERVAL_MS) >= 0):
            apptimize_ABTDataStore.checkForUpdatedMetaData()
        apptimize_ABTDataStore._submitResultsIfNecessary()

    @staticmethod
    def _submitResultsIfNecessary():
        if apptimize_ABTDataStore._resetSubmitTimeIfNeeded():
            apptimize_ABTDataStore.sharedInstance().flushTracking()

    @staticmethod
    def _submitResultLog(log):
        apptimize_api_ABTApiClient.sharedInstance().postResultsForKey(apptimize_ABTDataStore.getAppKey(),log)
        apptimize_ABTDataStore.sharedInstance()._saveResultLogs()

    @staticmethod
    def getServerGUID():
        if (apptimize_ABTDataStore.serverGuid is None):
            apptimize_ABTDataStore.serverGuid = apptimize_api_ABTUserGuid.generateUserGuid()
        return apptimize_ABTDataStore.serverGuid

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.resultLogs = None
        _hx_o.applicationResultLog = None
        _hx_o.metaData = None
apptimize_ABTDataStore._hx_class = apptimize_ABTDataStore
_hx_classes["apptimize.ABTDataStore"] = apptimize_ABTDataStore


class apptimize_ABTLogger:
    _hx_class_name = "apptimize.ABTLogger"
    __slots__ = ()
    _hx_statics = ["LOG_LEVEL_VERBOSE", "LOG_LEVEL_DEBUG", "LOG_LEVEL_INFO", "LOG_LEVEL_WARN", "LOG_LEVEL_ERROR", "LOG_LEVEL_NONE", "logLevel", "logLevelFromString", "setLogLevel", "c", "e", "w", "i", "v", "log_out"]

    @staticmethod
    def logLevelFromString(logLevel):
        level = logLevel.upper()
        if (level == "LOG_LEVEL_VERBOSE"):
            return apptimize_ABTLogger.LOG_LEVEL_VERBOSE
        if (level == "LOG_LEVEL_DEBUG"):
            return apptimize_ABTLogger.LOG_LEVEL_DEBUG
        if (level == "LOG_LEVEL_INFO"):
            return apptimize_ABTLogger.LOG_LEVEL_INFO
        if (level == "LOG_LEVEL_ERROR"):
            return apptimize_ABTLogger.LOG_LEVEL_ERROR
        if (level == "LOG_LEVEL_WARN"):
            return apptimize_ABTLogger.LOG_LEVEL_WARN
        if (level == "LOG_LEVEL_NONE"):
            return apptimize_ABTLogger.LOG_LEVEL_NONE
        return apptimize_ABTLogger.LOG_LEVEL_NONE

    @staticmethod
    def setLogLevel(level):
        apptimize_ABTLogger.logLevel = level

    @staticmethod
    def c(msg):
        apptimize_ABTLogger.log_out(msg)
        apptimize_util_ABTException.throwException(msg)

    @staticmethod
    def e(msg):
        if (apptimize_ABTLogger.logLevel <= apptimize_ABTLogger.LOG_LEVEL_ERROR):
            apptimize_ABTLogger.log_out(msg)

    @staticmethod
    def w(msg):
        if (apptimize_ABTLogger.logLevel <= apptimize_ABTLogger.LOG_LEVEL_WARN):
            apptimize_ABTLogger.log_out(msg)

    @staticmethod
    def i(msg):
        if (apptimize_ABTLogger.logLevel <= apptimize_ABTLogger.LOG_LEVEL_INFO):
            apptimize_ABTLogger.log_out(msg)

    @staticmethod
    def v(msg):
        if (apptimize_ABTLogger.logLevel <= apptimize_ABTLogger.LOG_LEVEL_VERBOSE):
            apptimize_ABTLogger.log_out(msg)

    @staticmethod
    def log_out(msg):
        print(str(("Apptimize: " + ("null" if msg is None else msg))))
apptimize_ABTLogger._hx_class = apptimize_ABTLogger
_hx_classes["apptimize.ABTLogger"] = apptimize_ABTLogger


class apptimize_api_ABTApiClient:
    _hx_class_name = "apptimize.api.ABTApiClient"
    __slots__ = ()
    _hx_methods = ["downloadMetaDataForKey", "postResultsForKey", "flushFailedResultsQueue"]
    _hx_statics = ["_instance", "sharedInstance"]

    def __init__(self):
        pass

    def downloadMetaDataForKey(self,appKey,etag):
        def _hx_local_0(json,etag1):
            md = apptimize_models_ABTMetadata.loadFromString(json)
            md.setEtag(etag1)
            apptimize_ABTDataStore.sharedInstance().overrideMetadata(md)
        def _hx_local_1(error):
            apptimize_ABTLogger.e(("Failed to download metadata with error: " + ("null" if error is None else error)))
        mdRequest = apptimize_api_ABTApiMetadataRequest(self,appKey,etag,_hx_local_0,_hx_local_1)

    def postResultsForKey(self,appKey,log):
        def _hx_local_0(response):
            pass
        def _hx_local_1(response1):
            pass
        resultsRequest = apptimize_api_ABTApiResultsPost(self,appKey,log,_hx_local_0,_hx_local_1)
        apptimize_api_ABTApiResultsPost.pushRequest(resultsRequest)

    def flushFailedResultsQueue(self):
        apptimize_api_ABTApiResultsPost.processNextRequest()
    _instance = None

    @staticmethod
    def sharedInstance():
        if (apptimize_api_ABTApiClient._instance is None):
            apptimize_api_ABTApiClient._instance = apptimize_api_ABTApiClient()
        return apptimize_api_ABTApiClient._instance

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_api_ABTApiClient._hx_class = apptimize_api_ABTApiClient
_hx_classes["apptimize.api.ABTApiClient"] = apptimize_api_ABTApiClient


class apptimize_api_ABTApiMetadataRequest:
    _hx_class_name = "apptimize.api.ABTApiMetadataRequest"
    __slots__ = ("apiClient", "appKey", "successCallback", "failureCallback")
    _hx_fields = ["apiClient", "appKey", "successCallback", "failureCallback"]
    _hx_methods = ["_apiSuccess", "_getMetadataUrl", "_headersForRequest"]

    def __init__(self,client,applicationKey,etag,success,failure):
        self.failureCallback = None
        self.successCallback = None
        self.appKey = None
        self.apiClient = None
        _gthis = self
        self.apiClient = client
        self.appKey = applicationKey
        self.successCallback = success
        self.failureCallback = failure
        url = self._getMetadataUrl()
        url = (("null" if url is None else url) + ("null" if applicationKey is None else applicationKey))
        apptimize_ABTLogger.v(("Checking for new metadata from url: " + ("null" if url is None else url)))
        def _hx_local_1(response):
            _gthis._apiSuccess(response)
        def _hx_local_2(response1):
            _gthis.failureCallback(response1.text)
        apptimize_http_ABTHttpRequest.get(url,self._headersForRequest(etag),_hx_local_1,_hx_local_2)

    def _apiSuccess(self,response):
        if (response.responseCode == 304):
            apptimize_ABTLogger.v("Got HTTP response 304, metadata not updated.")
            return
        json = apptimize_api_ABTMetadataProcessor.jsonFromMetadataDownload(response.bytes)
        if (json is not None):
            apptimize_ABTLogger.v("Request for metadata completed successfully.")
            self.successCallback(json,response.etag)
        else:
            errorString = "Failed to download metadata with error: response was empty."
            apptimize_ABTLogger.w(errorString)
            self.failureCallback(errorString)

    def _getMetadataUrl(self):
        metadataUrl = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.META_DATA_URL_KEY)
        if (metadataUrl is not None):
            return metadataUrl
        elif apptimize_ABTDataStore.sharedInstance().hasMetadata():
            return apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.META_DATA_URL_HL_KEY)
        else:
            return apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.META_DATA_URL_LL_KEY)

    def _headersForRequest(self,etag):
        if (etag is not None):
            _g = haxe_ds_StringMap()
            _g.h["ETag"] = etag
            _g.h["If-None-Match"] = etag
            return _g
        else:
            return None

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.apiClient = None
        _hx_o.appKey = None
        _hx_o.successCallback = None
        _hx_o.failureCallback = None
apptimize_api_ABTApiMetadataRequest._hx_class = apptimize_api_ABTApiMetadataRequest
_hx_classes["apptimize.api.ABTApiMetadataRequest"] = apptimize_api_ABTApiMetadataRequest


class apptimize_api_ABTResultsPostSession:
    _hx_class_name = "apptimize.api.ABTResultsPostSession"
    __slots__ = ("sessionId", "lastTimestamp")
    _hx_fields = ["sessionId", "lastTimestamp"]
    _hx_statics = ["create"]

    def __init__(self):
        self.lastTimestamp = None
        self.sessionId = None

    @staticmethod
    def create():
        instance = apptimize_api_ABTResultsPostSession()
        instance.sessionId = apptimize_ABTDataStore.getServerGUID()
        instance.lastTimestamp = (python_lib_Time.mktime(Date.now().date.timetuple()) * 1000)
        return instance

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.sessionId = None
        _hx_o.lastTimestamp = None
apptimize_api_ABTResultsPostSession._hx_class = apptimize_api_ABTResultsPostSession
_hx_classes["apptimize.api.ABTResultsPostSession"] = apptimize_api_ABTResultsPostSession


class apptimize_api_ABTApiResultsPost:
    _hx_class_name = "apptimize.api.ABTApiResultsPost"
    __slots__ = ("_apiClient", "_appKey", "_requestBytes", "_success", "_failure", "_failureCount", "_url")
    _hx_fields = ["_apiClient", "_appKey", "_requestBytes", "_success", "_failure", "_failureCount", "_url"]
    _hx_methods = ["_post", "incrementFailureCountForCode", "hxSerialize", "hxUnserialize"]
    _hx_statics = ["_posting", "RESULTS_LOCK_KEY", "onSuccess", "removeNextResultPost", "processNextRequest", "_lockAndPostIfAvailable", "_releasePosting", "canSendNextPost", "onFailure", "getPendingResultsCache", "pushRequest"]

    def __init__(self,client,applicationKey,log,success,failure):
        self._failureCount = 0
        self._apiClient = client
        self._appKey = applicationKey
        self._success = success
        self._failure = failure
        urls = apptimize_ABTDataStore.sharedInstance().getMetaData().getCheckinUrls()
        index = Math.floor(((((len(urls) - 1) + 1)) * python_lib_Random.random()))
        postUrl = (HxOverrides.stringOrNull((urls[index] if index >= 0 and index < len(urls) else None)) + "v4/")
        self._url = postUrl
        jsonBytes = haxe_io_Bytes.ofString(log.toJSON())
        self._requestBytes = jsonBytes

    def _post(self):
        _gthis = self
        apptimize_ABTLogger.v(("Posting results to: " + HxOverrides.stringOrNull(self._url)))
        def _hx_local_0(response):
            apptimize_ABTLogger.i("Successfully posted results.")
            apptimize_ABTLogger.v(("Results JSON:\n" + Std.string(_gthis._requestBytes)))
            apptimize_api_ABTApiResultsPost.onSuccess(response)
        def _hx_local_1(response1):
            _gthis.incrementFailureCountForCode(response1.responseCode)
            apptimize_ABTLogger.e(((("Failed to post results, queuing for retry later: " + Std.string(response1.responseCode)) + " ") + HxOverrides.stringOrNull(response1.text)))
            apptimize_ABTLogger.e(("Results JSON:\n" + Std.string(_gthis._requestBytes)))
            apptimize_api_ABTApiResultsPost.onFailure(response1)
        apptimize_http_ABTHttpRequest.post(self._url,self._requestBytes,self._appKey,_hx_local_0,_hx_local_1)

    def incrementFailureCountForCode(self,status):
        if (status >= 400):
            _hx_local_0 = self
            _hx_local_1 = _hx_local_0._failureCount
            _hx_local_0._failureCount = (_hx_local_1 + 1)
            _hx_local_1

    def hxSerialize(self,s):
        s.serialize(self._appKey)
        s.serialize(self._requestBytes)
        s.serialize(self._failureCount)
        s.serialize(self._url)

    def hxUnserialize(self,u):
        self._appKey = u.unserialize()
        self._requestBytes = u.unserialize()
        self._failureCount = u.unserialize()
        self._url = u.unserialize()

    @staticmethod
    def onSuccess(response):
        apptimize_api_ABTApiResultsPost._posting = False
        result = apptimize_api_ABTApiResultsPost.removeNextResultPost()
        if (result._success is not None):
            result._success(response)
        if (len(apptimize_api_ABTApiResultsPost.getPendingResultsCache()) <= 0):
            apptimize_api_ABTApiResultsPost._releasePosting()
        apptimize_api_ABTApiResultsPost.processNextRequest()

    @staticmethod
    def removeNextResultPost():
        result = None
        apptimize_util_ABTDataLock.lock(apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY)
        cache = apptimize_api_ABTApiResultsPost.getPendingResultsCache()
        result = (None if ((len(cache) == 0)) else cache.pop(0))
        apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kResultPostsKey,cache)
        apptimize_util_ABTDataLock.release(apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY)
        return result

    @staticmethod
    def processNextRequest():
        if ((len(apptimize_api_ABTApiResultsPost.getPendingResultsCache()) == 0) or apptimize_api_ABTApiResultsPost._posting):
            return
        apptimize_ABTLogger.v((("Processing next request in results cache (" + Std.string(len(apptimize_api_ABTApiResultsPost.getPendingResultsCache()))) + " pending)"))
        apptimize_api_ABTApiResultsPost._lockAndPostIfAvailable()

    @staticmethod
    def _lockAndPostIfAvailable():
        cache = apptimize_api_ABTApiResultsPost.getPendingResultsCache()
        if (apptimize_api_ABTApiResultsPost.canSendNextPost(True) and ((len(cache) > 0))):
            apptimize_api_ABTApiResultsPost._posting = True
            result = (cache[0] if 0 < len(cache) else None)
            result._post()

    @staticmethod
    def _releasePosting():
        if apptimize_api_ABTApiResultsPost._posting:
            apptimize_api_ABTApiResultsPost._posting = False
            apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kPostManagementKey,None)

    @staticmethod
    def canSendNextPost(claimPosting):
        currentSender = apptimize_support_persistence_ABTPersistence.loadObject(apptimize_support_persistence_ABTPersistence.kPostManagementKey)
        if (((currentSender is None) or ((currentSender.sessionId == apptimize_ABTDataStore.getServerGUID()))) or ((((python_lib_Time.mktime(Date.now().date.timetuple()) * 1000) - currentSender.lastTimestamp) > apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_POST_SENDER_TIMEOUT_MS_KEY)))):
            if claimPosting:
                apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kPostManagementKey,apptimize_api_ABTResultsPostSession.create())
            return True
        return False

    @staticmethod
    def onFailure(response):
        result = python_internal_ArrayImpl._get(apptimize_api_ABTApiResultsPost.getPendingResultsCache(), 0)
        if (result._failureCount > apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_POST_FAILURE_KEY)):
            result = apptimize_api_ABTApiResultsPost.removeNextResultPost()
            apptimize_ABTLogger.e("Dropping result post after repeated failure.")
        if (result._failure is not None):
            result._failure(response)
        apptimize_api_ABTApiResultsPost._releasePosting()

    @staticmethod
    def getPendingResultsCache():
        requestCache = None
        apptimize_util_ABTDataLock.lock(apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY)
        requestCache = apptimize_support_persistence_ABTPersistence.loadObject(apptimize_support_persistence_ABTPersistence.kResultPostsKey)
        if (requestCache is None):
            requestCache = list()
        apptimize_util_ABTDataLock.release(apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY)
        return requestCache

    @staticmethod
    def pushRequest(resultRequest):
        cache = apptimize_api_ABTApiResultsPost.getPendingResultsCache()
        apptimize_util_ABTDataLock.lock(apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY)
        cache.append(resultRequest)
        if (len(cache) > apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.MAXIMUM_PENDING_RESULTS_KEY)):
            if (len(cache) != 0):
                cache.pop(0)
        apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kResultPostsKey,cache)
        apptimize_util_ABTDataLock.release(apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY)
        apptimize_api_ABTApiResultsPost.processNextRequest()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._apiClient = None
        _hx_o._appKey = None
        _hx_o._requestBytes = None
        _hx_o._success = None
        _hx_o._failure = None
        _hx_o._failureCount = None
        _hx_o._url = None
apptimize_api_ABTApiResultsPost._hx_class = apptimize_api_ABTApiResultsPost
_hx_classes["apptimize.api.ABTApiResultsPost"] = apptimize_api_ABTApiResultsPost


class apptimize_api_ABTMetadataProcessor:
    _hx_class_name = "apptimize.api.ABTMetadataProcessor"
    __slots__ = ()
    _hx_statics = ["jsonFromMetadataDownload"]

    @staticmethod
    def jsonFromMetadataDownload(_hx_bytes):
        decompressedData = apptimize_util_ABTUtilGzip.decompress(_hx_bytes)
        return decompressedData.getString(0,decompressedData.length)
apptimize_api_ABTMetadataProcessor._hx_class = apptimize_api_ABTMetadataProcessor
_hx_classes["apptimize.api.ABTMetadataProcessor"] = apptimize_api_ABTMetadataProcessor


class apptimize_api_ABTUserGuid:
    _hx_class_name = "apptimize.api.ABTUserGuid"
    __slots__ = ()
    _hx_statics = ["_userGuid", "generateUserGuid", "S4", "isValidGuid"]
    _userGuid = None

    @staticmethod
    def generateUserGuid():
        apptimize_api_ABTUserGuid._userGuid = (((((((((((HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4()) + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4())) + "-") + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4())) + "-") + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4())) + "-") + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4())) + "-") + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4())) + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4())) + HxOverrides.stringOrNull(apptimize_api_ABTUserGuid.S4()))
        return apptimize_api_ABTUserGuid._userGuid

    @staticmethod
    def S4(randomFunction = None):
        if (randomFunction is None):
            randomFunction = _Math_Math_Impl_.random
        x = (randomFunction() * 65536)
        rnd = None
        try:
            rnd = int(x)
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            e = _hx_e1
            rnd = None
        return StringTools.hex(rnd,4)

    @staticmethod
    def isValidGuid(guid):
        regex = EReg("(^([0-9A-Fa-f]{8}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{12})$)","")
        regex.matchObj = python_lib_Re.search(regex.pattern,guid)
        return (regex.matchObj is not None)
apptimize_api_ABTUserGuid._hx_class = apptimize_api_ABTUserGuid
_hx_classes["apptimize.api.ABTUserGuid"] = apptimize_api_ABTUserGuid


class apptimize_events_ABTEventManager:
    _hx_class_name = "apptimize.events.ABTEventManager"
    __slots__ = ()
    _hx_statics = ["_onParticipationCallback", "_onMetadataUpdatedCallback", "setOnMetadataUpdatedCallback", "dispatchOnMetadataUpdated", "setOnParticipationCallback", "dispatchOnParticipation"]
    _onParticipationCallback = None
    _onMetadataUpdatedCallback = None

    @staticmethod
    def setOnMetadataUpdatedCallback(processCallback):
        apptimize_events_ABTEventManager._onMetadataUpdatedCallback = processCallback

    @staticmethod
    def dispatchOnMetadataUpdated():
        if (apptimize_events_ABTEventManager._onMetadataUpdatedCallback is not None):
            apptimize_events_ABTEventManager._onMetadataUpdatedCallback()

    @staticmethod
    def setOnParticipationCallback(runCallback):
        apptimize_events_ABTEventManager._onParticipationCallback = runCallback

    @staticmethod
    def dispatchOnParticipation(experimentName,variantName):
        if (apptimize_events_ABTEventManager._onParticipationCallback is not None):
            apptimize_events_ABTEventManager._onParticipationCallback(experimentName,variantName)
apptimize_events_ABTEventManager._hx_class = apptimize_events_ABTEventManager
_hx_classes["apptimize.events.ABTEventManager"] = apptimize_events_ABTEventManager

class apptimize_filter_ABTFilterResult(Enum):
    __slots__ = ()
    _hx_class_name = "apptimize.filter.ABTFilterResult"
    _hx_constructs = ["ABTFilterResultUnknown", "ABTFilterResultFalse", "ABTFilterResultTrue"]
apptimize_filter_ABTFilterResult.ABTFilterResultUnknown = apptimize_filter_ABTFilterResult("ABTFilterResultUnknown", 0, list())
apptimize_filter_ABTFilterResult.ABTFilterResultFalse = apptimize_filter_ABTFilterResult("ABTFilterResultFalse", 1, list())
apptimize_filter_ABTFilterResult.ABTFilterResultTrue = apptimize_filter_ABTFilterResult("ABTFilterResultTrue", 2, list())
apptimize_filter_ABTFilterResult._hx_class = apptimize_filter_ABTFilterResult
_hx_classes["apptimize.filter.ABTFilterResult"] = apptimize_filter_ABTFilterResult

class apptimize_filter_ABTFilterPropertySource(Enum):
    __slots__ = ()
    _hx_class_name = "apptimize.filter.ABTFilterPropertySource"
    _hx_constructs = ["ABTFilterPropertySourceDevice", "ABTFilterPropertySourceUser", "ABTFilterPropertySourcePrefixed"]
apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice = apptimize_filter_ABTFilterPropertySource("ABTFilterPropertySourceDevice", 0, list())
apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceUser = apptimize_filter_ABTFilterPropertySource("ABTFilterPropertySourceUser", 1, list())
apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourcePrefixed = apptimize_filter_ABTFilterPropertySource("ABTFilterPropertySourcePrefixed", 2, list())
apptimize_filter_ABTFilterPropertySource._hx_class = apptimize_filter_ABTFilterPropertySource
_hx_classes["apptimize.filter.ABTFilterPropertySource"] = apptimize_filter_ABTFilterPropertySource

class apptimize_filter_ABTFilterType(Enum):
    __slots__ = ()
    _hx_class_name = "apptimize.filter.ABTFilterType"
    _hx_constructs = ["ABTFilterTypeUnknown", "ABTFilterTypeSimple", "ABTFilterTypeList", "ABTFilterTypeSet", "ABTFilterTypeCompound", "ABTFilterTypePropertyless", "ABTFilterTypeNamed"]
apptimize_filter_ABTFilterType.ABTFilterTypeUnknown = apptimize_filter_ABTFilterType("ABTFilterTypeUnknown", 0, list())
apptimize_filter_ABTFilterType.ABTFilterTypeSimple = apptimize_filter_ABTFilterType("ABTFilterTypeSimple", 1, list())
apptimize_filter_ABTFilterType.ABTFilterTypeList = apptimize_filter_ABTFilterType("ABTFilterTypeList", 2, list())
apptimize_filter_ABTFilterType.ABTFilterTypeSet = apptimize_filter_ABTFilterType("ABTFilterTypeSet", 3, list())
apptimize_filter_ABTFilterType.ABTFilterTypeCompound = apptimize_filter_ABTFilterType("ABTFilterTypeCompound", 4, list())
apptimize_filter_ABTFilterType.ABTFilterTypePropertyless = apptimize_filter_ABTFilterType("ABTFilterTypePropertyless", 5, list())
apptimize_filter_ABTFilterType.ABTFilterTypeNamed = apptimize_filter_ABTFilterType("ABTFilterTypeNamed", 6, list())
apptimize_filter_ABTFilterType._hx_class = apptimize_filter_ABTFilterType
_hx_classes["apptimize.filter.ABTFilterType"] = apptimize_filter_ABTFilterType

class apptimize_filter_ABTFilterOperator(Enum):
    __slots__ = ()
    _hx_class_name = "apptimize.filter.ABTFilterOperator"
    _hx_constructs = ["ABTFilterOperatorUnknown", "ABTFilterOperatorEquals", "ABTFilterOperatorNotEquals", "ABTFilterOperatorRegex", "ABTFilterOperatorNotRegex", "ABTFilterOperatorGreaterThan", "ABTFilterOperatorGreaterThanOrEqual", "ABTFilterOperatorLessThan", "ABTFilterOperatorLessThanOrEqual", "ABTFilterOperatorInList", "ABTFilterOperatorNotInList", "ABTFilterOperatorIntersection", "ABTFilterOperatorCompoundOr", "ABTFilterOperatorCompoundAnd", "ABTFilterOperatorCompoundSingleNot", "ABTFilterOperatorCompoundSingleIsNull", "ABTFilterOperatorCompoundSingleIsNotNull", "ABTFilterOperatorPropertyIsNull", "ABTFilterOperatorPropertyIsNotNull", "ABTFilterOperatorPropertyIsRecognized", "ABTFilterOperatorPropertyIsNotRecognized", "ABTFilterOperatorOperatorIsRecognized", "ABTFilterOperatorOperatorIsNotRecognized", "ABTFilterOperatorValueOf"]
apptimize_filter_ABTFilterOperator.ABTFilterOperatorUnknown = apptimize_filter_ABTFilterOperator("ABTFilterOperatorUnknown", 0, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals = apptimize_filter_ABTFilterOperator("ABTFilterOperatorEquals", 1, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotEquals = apptimize_filter_ABTFilterOperator("ABTFilterOperatorNotEquals", 2, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorRegex = apptimize_filter_ABTFilterOperator("ABTFilterOperatorRegex", 3, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotRegex = apptimize_filter_ABTFilterOperator("ABTFilterOperatorNotRegex", 4, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThan = apptimize_filter_ABTFilterOperator("ABTFilterOperatorGreaterThan", 5, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThanOrEqual = apptimize_filter_ABTFilterOperator("ABTFilterOperatorGreaterThanOrEqual", 6, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThan = apptimize_filter_ABTFilterOperator("ABTFilterOperatorLessThan", 7, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThanOrEqual = apptimize_filter_ABTFilterOperator("ABTFilterOperatorLessThanOrEqual", 8, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorInList = apptimize_filter_ABTFilterOperator("ABTFilterOperatorInList", 9, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotInList = apptimize_filter_ABTFilterOperator("ABTFilterOperatorNotInList", 10, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorIntersection = apptimize_filter_ABTFilterOperator("ABTFilterOperatorIntersection", 11, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundOr = apptimize_filter_ABTFilterOperator("ABTFilterOperatorCompoundOr", 12, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundAnd = apptimize_filter_ABTFilterOperator("ABTFilterOperatorCompoundAnd", 13, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleNot = apptimize_filter_ABTFilterOperator("ABTFilterOperatorCompoundSingleNot", 14, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleIsNull = apptimize_filter_ABTFilterOperator("ABTFilterOperatorCompoundSingleIsNull", 15, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleIsNotNull = apptimize_filter_ABTFilterOperator("ABTFilterOperatorCompoundSingleIsNotNull", 16, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNull = apptimize_filter_ABTFilterOperator("ABTFilterOperatorPropertyIsNull", 17, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNotNull = apptimize_filter_ABTFilterOperator("ABTFilterOperatorPropertyIsNotNull", 18, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsRecognized = apptimize_filter_ABTFilterOperator("ABTFilterOperatorPropertyIsRecognized", 19, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNotRecognized = apptimize_filter_ABTFilterOperator("ABTFilterOperatorPropertyIsNotRecognized", 20, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorOperatorIsRecognized = apptimize_filter_ABTFilterOperator("ABTFilterOperatorOperatorIsRecognized", 21, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorOperatorIsNotRecognized = apptimize_filter_ABTFilterOperator("ABTFilterOperatorOperatorIsNotRecognized", 22, list())
apptimize_filter_ABTFilterOperator.ABTFilterOperatorValueOf = apptimize_filter_ABTFilterOperator("ABTFilterOperatorValueOf", 23, list())
apptimize_filter_ABTFilterOperator._hx_class = apptimize_filter_ABTFilterOperator
_hx_classes["apptimize.filter.ABTFilterOperator"] = apptimize_filter_ABTFilterOperator


class apptimize_filter_ABTFilter:
    _hx_class_name = "apptimize.filter.ABTFilter"
    __slots__ = ("property", "propertySource", "value", "filterType", "filterOperator", "callServerURL")
    _hx_fields = ["property", "propertySource", "value", "filterType", "filterOperator", "callServerURL"]
    _hx_methods = ["fromJSON", "isSupportedOperator", "isSupportedProperty", "currentDeviceValueForProperty", "currentDeviceValue", "hasSupportedProperty", "filterMatchesEnvironment"]
    _hx_statics = ["kABTFilterKeyValue", "kABTFilterKeyType", "kABTFilterKeyProperty", "kABTFilterKeyOperator", "kABTFilterKeyPropertySource", "kABTFilterKeyCallServerInputs", "kABTFilterKeyCallURLKey", "kABTFilterKeyUserAttribute", "kABTFilterKeyPrefixedAttribute", "kABTFilterKeyNamedFilter", "filterFromJSON", "classForType", "filterForTypeFromJSON", "operatorFromString", "typeFromOperator"]

    def __init__(self):
        self.callServerURL = None
        self.filterOperator = None
        self.filterType = None
        self.value = None
        self.propertySource = None
        self.property = None

    def fromJSON(self,json):
        jsonProperty = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyProperty)
        if (jsonProperty is not None):
            self.property = jsonProperty
            self.propertySource = apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice
        else:
            jsonProperty = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyUserAttribute)
            if (jsonProperty is not None):
                self.property = jsonProperty
                self.propertySource = apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceUser
            else:
                jsonProperty = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyPrefixedAttribute)
                if (jsonProperty is not None):
                    self.property = jsonProperty
                    self.propertySource = apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourcePrefixed
        self.filterOperator = apptimize_filter_ABTFilter.operatorFromString(Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyOperator))
        self.filterType = apptimize_filter_ABTFilter.filterForTypeFromJSON(json)
        if (self.filterType == apptimize_filter_ABTFilterType.ABTFilterTypeUnknown):
            apptimize_ABTLogger.w("Unknown filter type: setting value without type checking.")
            self.value = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyValue)
        self.callServerURL = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyCallURLKey)

    def isSupportedOperator(self,operator):
        return (apptimize_filter_ABTFilter.operatorFromString(operator) != apptimize_filter_ABTFilterOperator.ABTFilterOperatorUnknown)

    def isSupportedProperty(self,env,property,source):
        result = False
        if (source == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice):
            result = apptimize_support_properties_ABTApplicationProperties.sharedInstance().isPropertyAvailable(property)
        if (source == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceUser):
            result = env.customProperties.isNamespacedPropertyAvailable(property,apptimize_support_properties_CustomPropertyNamespace.UserAttribute)
        if (source == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourcePrefixed):
            if (not env.customProperties.isPropertyAvailable(property)):
                result = apptimize_support_properties_ABTInternalProperties.sharedInstance().isPropertyAvailable(property)
            else:
                result = True
        if (not result):
            apptimize_ABTLogger.w((("Property \"" + ("null" if property is None else property)) + "\" not found which is expected by a filter."))
        return result

    def currentDeviceValueForProperty(self,env,property,propertySource):
        if (propertySource == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice):
            return apptimize_support_properties_ABTApplicationProperties.sharedInstance().valueForProperty(property)
        if (propertySource == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceUser):
            return env.customProperties.valueForNamespacedProperty(property,apptimize_support_properties_CustomPropertyNamespace.UserAttribute)
        if (self.propertySource == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourcePrefixed):
            value = env.customProperties.valueForProperty(property)
            if (value is None):
                value = apptimize_support_properties_ABTInternalProperties.sharedInstance().valueForProperty(property)
            return value
        return None

    def currentDeviceValue(self,env):
        if (self.propertySource == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice):
            return apptimize_support_properties_ABTApplicationProperties.sharedInstance().valueForProperty(self.property)
        if (self.propertySource == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceUser):
            return env.customProperties.valueForNamespacedProperty(self.property,apptimize_support_properties_CustomPropertyNamespace.UserAttribute)
        if (self.propertySource == apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourcePrefixed):
            value = env.customProperties.valueForProperty(self.property)
            if (value is None):
                value = apptimize_support_properties_ABTInternalProperties.sharedInstance().valueForProperty(self.property)
            return value
        return None

    def hasSupportedProperty(self,env):
        return self.isSupportedProperty(env,self.property,self.propertySource)

    def filterMatchesEnvironment(self,env):
        apptimize_ABTLogger.e("Unknown filter type. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def filterFromJSON(json):
        filterType = apptimize_filter_ABTFilter.filterForTypeFromJSON(json)
        classType = apptimize_filter_ABTFilter.classForType(filterType)
        if (classType is None):
            apptimize_ABTLogger.e(("Unable to find filter type: " + Std.string(filterType)))
            return None
        abtFilter = classType(*[])
        abtFilter.fromJSON(json)
        return abtFilter

    @staticmethod
    def classForType(filterType):
        if (filterType == apptimize_filter_ABTFilterType.ABTFilterTypeSimple):
            return apptimize_filter_ABTSimpleFilter
        if (filterType == apptimize_filter_ABTFilterType.ABTFilterTypeCompound):
            return apptimize_filter_ABTCompoundFilter
        if (filterType == apptimize_filter_ABTFilterType.ABTFilterTypeList):
            return apptimize_filter_ABTListFilter
        if (filterType == apptimize_filter_ABTFilterType.ABTFilterTypeSet):
            return apptimize_filter_ABTSetFilter
        if (filterType == apptimize_filter_ABTFilterType.ABTFilterTypeNamed):
            return apptimize_filter_ABTNamedFilter
        return apptimize_filter_ABTUnknownFilter

    @staticmethod
    def filterForTypeFromJSON(json):
        operator = apptimize_filter_ABTFilter.operatorFromString(Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyOperator))
        _hx_type = apptimize_filter_ABTFilter.typeFromOperator(operator)
        return _hx_type

    @staticmethod
    def operatorFromString(string):
        if ("=" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals
        if ("!=" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotEquals
        if ("regex" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorRegex
        if ("not_regex" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotRegex
        if (">" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThan
        if (">=" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThanOrEqual
        if ("<" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThan
        if ("<=" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThanOrEqual
        if ("in" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorInList
        if ("not_in" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotInList
        if ("intersection" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorIntersection
        if ("or" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundOr
        if ("and" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundAnd
        if ("not" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleNot
        if ("is_null" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleIsNull
        if ("is_not_null" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleIsNotNull
        if ("is_property_null" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNull
        if ("is_property_not_null" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNotNull
        if ("is_recognized_property" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsRecognized
        if ("is_not_recognized_property" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNotRecognized
        if ("is_recognized_operator" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorOperatorIsRecognized
        if ("is_not_recognized_operator" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorOperatorIsNotRecognized
        if ("value_of" == string):
            return apptimize_filter_ABTFilterOperator.ABTFilterOperatorValueOf
        return apptimize_filter_ABTFilterOperator.ABTFilterOperatorUnknown

    @staticmethod
    def typeFromOperator(operator):
        operator1 = operator.index
        if (operator1 == 0):
            pass
        elif (operator1 == 1):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 2):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 3):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 4):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 5):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 6):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 7):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 8):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSimple
        elif (operator1 == 9):
            return apptimize_filter_ABTFilterType.ABTFilterTypeList
        elif (operator1 == 10):
            return apptimize_filter_ABTFilterType.ABTFilterTypeList
        elif (operator1 == 11):
            return apptimize_filter_ABTFilterType.ABTFilterTypeSet
        elif (operator1 == 12):
            return apptimize_filter_ABTFilterType.ABTFilterTypeCompound
        elif (operator1 == 13):
            return apptimize_filter_ABTFilterType.ABTFilterTypeCompound
        elif (operator1 == 14):
            return apptimize_filter_ABTFilterType.ABTFilterTypeCompound
        elif (operator1 == 15):
            return apptimize_filter_ABTFilterType.ABTFilterTypeCompound
        elif (operator1 == 16):
            return apptimize_filter_ABTFilterType.ABTFilterTypeCompound
        elif (operator1 == 17):
            return apptimize_filter_ABTFilterType.ABTFilterTypePropertyless
        elif (operator1 == 18):
            return apptimize_filter_ABTFilterType.ABTFilterTypePropertyless
        elif (operator1 == 19):
            return apptimize_filter_ABTFilterType.ABTFilterTypePropertyless
        elif (operator1 == 20):
            return apptimize_filter_ABTFilterType.ABTFilterTypePropertyless
        elif (operator1 == 21):
            return apptimize_filter_ABTFilterType.ABTFilterTypePropertyless
        elif (operator1 == 22):
            return apptimize_filter_ABTFilterType.ABTFilterTypePropertyless
        elif (operator1 == 23):
            return apptimize_filter_ABTFilterType.ABTFilterTypeNamed
        else:
            pass
        apptimize_ABTLogger.e("Unknown filter type. Filter match is unknown.")
        return apptimize_filter_ABTFilterType.ABTFilterTypeUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.property = None
        _hx_o.propertySource = None
        _hx_o.value = None
        _hx_o.filterType = None
        _hx_o.filterOperator = None
        _hx_o.callServerURL = None
apptimize_filter_ABTFilter._hx_class = apptimize_filter_ABTFilter
_hx_classes["apptimize.filter.ABTFilter"] = apptimize_filter_ABTFilter


class apptimize_filter_ABTSimpleFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTSimpleFilter"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        self.value = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyValue)

    def filterMatchesEnvironment(self,env):
        if (not self.hasSupportedProperty(env)):
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        currentValue = self.currentDeviceValue(env)
        filterValue = self.value
        if ((currentValue is None) or ((filterValue is None))):
            apptimize_ABTLogger.w("Filter has null value type. Filter match is unknown.")
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        if (Type.getClass(currentValue) == str):
            if ((Type.typeof(filterValue) == ValueType.TFloat) or ((Type.typeof(filterValue) == ValueType.TInt))):
                return apptimize_filter_ABTFilterUtils.ABTEvaluateNumber(currentValue,self.filterOperator,filterValue)
            if (Type.getClass(filterValue) != str):
                apptimize_ABTLogger.w("Filter value does not match property type of string. Filter match is unknown.")
                return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
            if (((self.property == "apptimize_version") or ((self.property == "system_version"))) or ((self.property == "app_version"))):
                return apptimize_filter_ABTFilterUtils.ABTEvaluateVersionString(currentValue,self.filterOperator,filterValue)
            return apptimize_filter_ABTFilterUtils.ABTEvaluateString(currentValue,self.filterOperator,filterValue)
        if ((Type.typeof(currentValue) == ValueType.TFloat) or ((Type.typeof(currentValue) == ValueType.TInt))):
            if (Type.getClass(filterValue) == str):
                return apptimize_filter_ABTFilterUtils.ABTEvaluateNumber(currentValue,self.filterOperator,filterValue)
            if ((Type.typeof(filterValue) != ValueType.TFloat) and ((Type.typeof(filterValue) != ValueType.TInt))):
                apptimize_ABTLogger.w("Filter value does not match property type of number. Filter match is unknown.")
                return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
            return apptimize_filter_ABTFilterUtils.ABTEvaluateNumber(currentValue,self.filterOperator,filterValue)
        if (Type.typeof(currentValue) == ValueType.TBool):
            if (Type.getClass(filterValue) == str):
                if (filterValue == "true"):
                    filterValue = True
                if (filterValue == "false"):
                    filterValue = False
            return apptimize_filter_ABTFilterUtils.ABTEvaluateBool(currentValue,self.filterOperator,filterValue)
        apptimize_ABTLogger.w("Simple filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_filter_ABTSimpleFilter._hx_class = apptimize_filter_ABTSimpleFilter
_hx_classes["apptimize.filter.ABTSimpleFilter"] = apptimize_filter_ABTSimpleFilter


class apptimize_filter_ABTCompoundFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTCompoundFilter"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        filtersArray = list()
        dynamicArray = Reflect.field(json,"value")
        _g = 0
        while (_g < len(dynamicArray)):
            _hx_filter = (dynamicArray[_g] if _g >= 0 and _g < len(dynamicArray) else None)
            _g = (_g + 1)
            ff = apptimize_filter_ABTFilter.filterFromJSON(_hx_filter)
            filtersArray.append(ff)
        self.value = filtersArray

    def filterMatchesEnvironment(self,env):
        children = self.value
        if (len(children) < 1):
            apptimize_ABTLogger.w((("Compound filter \"" + Std.string(self)) + "\" has an empty compound set. Filter match is unknown."))
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundAnd):
            result = apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            _g = 0
            while (_g < len(children)):
                _hx_filter = (children[_g] if _g >= 0 and _g < len(children) else None)
                _g = (_g + 1)
                currentResult = _hx_filter.filterMatchesEnvironment(env)
                result = apptimize_filter_ABTFilterUtils.ABTFilterAnd(result,currentResult)
            return result
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundOr):
            result1 = apptimize_filter_ABTFilterResult.ABTFilterResultFalse
            _g1 = 0
            while (_g1 < len(children)):
                filter1 = (children[_g1] if _g1 >= 0 and _g1 < len(children) else None)
                _g1 = (_g1 + 1)
                currentResult1 = filter1.filterMatchesEnvironment(env)
                result1 = apptimize_filter_ABTFilterUtils.ABTFilterOr(result1,currentResult1)
            return result1
        if ((self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleNot) and ((len(children) == 1))):
            child = (children[0] if 0 < len(children) else None)
            result2 = child.filterMatchesEnvironment(env)
            if (result2 == apptimize_filter_ABTFilterResult.ABTFilterResultFalse):
                result2 = apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            elif (result2 == apptimize_filter_ABTFilterResult.ABTFilterResultTrue):
                result2 = apptimize_filter_ABTFilterResult.ABTFilterResultFalse
            return result2
        if ((self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleIsNull) and ((len(children) == 1))):
            child1 = (children[0] if 0 < len(children) else None)
            result3 = (apptimize_filter_ABTFilterResult.ABTFilterResultTrue if ((child1.filterMatchesEnvironment(env) == apptimize_filter_ABTFilterResult.ABTFilterResultUnknown)) else apptimize_filter_ABTFilterResult.ABTFilterResultFalse)
            return result3
        if ((self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorCompoundSingleIsNotNull) and ((len(children) == 1))):
            child2 = (children[0] if 0 < len(children) else None)
            if (child2.filterMatchesEnvironment(env) != apptimize_filter_ABTFilterResult.ABTFilterResultUnknown):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        apptimize_ABTLogger.w((("Filter \"" + Std.string(self)) + "\" has an unsupported compound operator or children count. Filter match is unknown."))
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_filter_ABTCompoundFilter._hx_class = apptimize_filter_ABTCompoundFilter
_hx_classes["apptimize.filter.ABTCompoundFilter"] = apptimize_filter_ABTCompoundFilter


class apptimize_filter_ABTListFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTListFilter"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        self.value = Reflect.field(json,"value")

    def filterMatchesEnvironment(self,env):
        if (not self.hasSupportedProperty(env)):
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        children = self.value
        currentValue = self.currentDeviceValue(env)
        if (currentValue is None):
            apptimize_ABTLogger.w((("Filter \"" + Std.string(self)) + "\" is attempting to match against a null device property."))
            if (python_internal_ArrayImpl.indexOf(children,currentValue,None) > -1):
                if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorInList):
                    return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
                else:
                    return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
            elif (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorInList):
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
        inList = False
        _g = 0
        while (_g < len(children)):
            childValue = (children[_g] if _g >= 0 and _g < len(children) else None)
            _g = (_g + 1)
            if (Type.getClass(currentValue) == str):
                if (not inList):
                    inList = (apptimize_filter_ABTFilterUtils.ABTEvaluateString(currentValue,apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals,childValue) == apptimize_filter_ABTFilterResult.ABTFilterResultTrue)
                else:
                    inList = True
            elif (not inList):
                inList = (apptimize_filter_ABTFilterUtils.ABTEvaluateNumber(currentValue,apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals,childValue) == apptimize_filter_ABTFilterResult.ABTFilterResultTrue)
            else:
                inList = True
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotInList):
            if (not inList):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if inList:
            return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
        else:
            return apptimize_filter_ABTFilterResult.ABTFilterResultFalse

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_filter_ABTListFilter._hx_class = apptimize_filter_ABTListFilter
_hx_classes["apptimize.filter.ABTListFilter"] = apptimize_filter_ABTListFilter


class apptimize_filter_ABTSetFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTSetFilter"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)

    def filterMatchesEnvironment(self,env):
        apptimize_ABTLogger.e("Set filter not implemented. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_filter_ABTSetFilter._hx_class = apptimize_filter_ABTSetFilter
_hx_classes["apptimize.filter.ABTSetFilter"] = apptimize_filter_ABTSetFilter


class apptimize_filter_ABTUnknownFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTUnknownFilter"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)

    def filterMatchesEnvironment(self,env):
        apptimize_ABTLogger.e("Unknown filter requested. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_filter_ABTUnknownFilter._hx_class = apptimize_filter_ABTUnknownFilter
_hx_classes["apptimize.filter.ABTUnknownFilter"] = apptimize_filter_ABTUnknownFilter


class apptimize_filter_ABTPropertylessFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTPropertylessFilter"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        self.value = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyValue)

    def filterMatchesEnvironment(self,env):
        filterValue = self.value
        if ((filterValue is None) or ((Type.getClass(filterValue) != str))):
            apptimize_ABTLogger.w("Property-less filter requires a string value. Filter match is unknown.")
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        filterString = filterValue
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNull):
            currentValue = self.currentDeviceValueForProperty(env,filterString,apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice)
            if (currentValue is None):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNotNull):
            currentValue1 = self.currentDeviceValueForProperty(env,filterString,apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice)
            if (currentValue1 is not None):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsRecognized):
            if (self.isSupportedProperty(env,filterString,apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice) == True):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorPropertyIsNotRecognized):
            if (self.isSupportedProperty(env,filterString,apptimize_filter_ABTFilterPropertySource.ABTFilterPropertySourceDevice) == False):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorOperatorIsRecognized):
            if (self.isSupportedOperator(filterString) == True):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (self.filterOperator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorOperatorIsNotRecognized):
            if (self.isSupportedOperator(filterString) == False):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        apptimize_ABTLogger.w("Property-less filter attempted with an invalid operator. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_filter_ABTPropertylessFilter._hx_class = apptimize_filter_ABTPropertylessFilter
_hx_classes["apptimize.filter.ABTPropertylessFilter"] = apptimize_filter_ABTPropertylessFilter


class apptimize_filter_ABTNamedFilter(apptimize_filter_ABTFilter):
    _hx_class_name = "apptimize.filter.ABTNamedFilter"
    __slots__ = ("namedFilter",)
    _hx_fields = ["namedFilter"]
    _hx_methods = ["fromJSON", "filterMatchesEnvironment"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilter


    def __init__(self):
        self.namedFilter = None
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        self.namedFilter = Reflect.field(json,apptimize_filter_ABTFilter.kABTFilterKeyNamedFilter)

    def filterMatchesEnvironment(self,env):
        apptimize_ABTLogger.e("Named filter not implemented. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.namedFilter = None
apptimize_filter_ABTNamedFilter._hx_class = apptimize_filter_ABTNamedFilter
_hx_classes["apptimize.filter.ABTNamedFilter"] = apptimize_filter_ABTNamedFilter


class apptimize_filter_ABTFilterUtils:
    _hx_class_name = "apptimize.filter.ABTFilterUtils"
    __slots__ = ()
    _hx_statics = ["__meta__", "ABTFilterAnd", "ABTFilterOr", "ABTEvaluateString", "ABTEvaluateBool", "ABTEvaluateNumber", "ABTEvaluateVersionString"]

    @staticmethod
    def ABTFilterAnd(left,right):
        if ((left == apptimize_filter_ABTFilterResult.ABTFilterResultTrue) and ((right == apptimize_filter_ABTFilterResult.ABTFilterResultUnknown))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        if ((left == apptimize_filter_ABTFilterResult.ABTFilterResultTrue) and ((right == apptimize_filter_ABTFilterResult.ABTFilterResultFalse))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if ((left == apptimize_filter_ABTFilterResult.ABTFilterResultUnknown) and ((right == apptimize_filter_ABTFilterResult.ABTFilterResultFalse))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        return left

    @staticmethod
    def ABTFilterOr(left,right):
        if ((left == apptimize_filter_ABTFilterResult.ABTFilterResultUnknown) and ((right == apptimize_filter_ABTFilterResult.ABTFilterResultFalse))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        if ((left == apptimize_filter_ABTFilterResult.ABTFilterResultTrue) and ((right == apptimize_filter_ABTFilterResult.ABTFilterResultFalse))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
        if ((left == apptimize_filter_ABTFilterResult.ABTFilterResultTrue) and ((right == apptimize_filter_ABTFilterResult.ABTFilterResultUnknown))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
        return right

    @staticmethod
    def ABTEvaluateString(left,operator,right):
        leftString = ""
        rightString = ""
        if ((left is None) or ((right is None))):
            apptimize_ABTLogger.w("String comparison attempted with null string. Filter match is unknown.")
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        if (Type.getClass(left) == str):
            leftString = left
        if (Type.getClass(right) == str):
            rightString = right
        leftString = leftString.lower()
        rightString = rightString.lower()
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals):
            if (leftString == rightString):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotEquals):
            if (leftString != rightString):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        apptimize_ABTLogger.w("String comparison attempted with an invalid operator. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def ABTEvaluateBool(left,operator,right):
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals):
            if (left == right):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotEquals):
            if (left != right):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        apptimize_ABTLogger.w("Bool comparison attempted with an invalid operator. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def ABTEvaluateNumber(left,operator,right):
        leftFloat = None
        rightFloat = None
        if ((left is None) or ((right is None))):
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        if (Type.getClass(left) == str):
            leftFloat = Std.parseFloat(left)
        else:
            leftFloat = left
        if (Type.getClass(right) == str):
            rightFloat = Std.parseFloat(right)
        else:
            rightFloat = right
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals):
            if (leftFloat == rightFloat):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotEquals):
            if (leftFloat != rightFloat):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThan):
            if (leftFloat > rightFloat):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThanOrEqual):
            if (leftFloat >= rightFloat):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThan):
            if (leftFloat < rightFloat):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThanOrEqual):
            if (leftFloat <= rightFloat):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        apptimize_ABTLogger.w("Number comparison attempted with an invalid operator. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown

    @staticmethod
    def ABTEvaluateVersionString(left,operator,right):
        if (not left):
            left = "0"
        if (not right):
            right = "0"
        if ((Type.getClass(left) != str) or ((Type.getClass(right) != str))):
            apptimize_ABTLogger.w("Unable to compare versions as values are not strings. Filter match is unknown.")
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        leftString = left
        rightString = right
        leftComponents = leftString.split(".")
        rightComponents = rightString.split(".")
        leftLength = len(leftComponents)
        if (leftLength < 3):
            _g = leftLength
            while (_g < 3):
                i = _g
                _g = (_g + 1)
                leftComponents.append("0")
        rightLength = len(rightComponents)
        if (rightLength < 3):
            _g1 = rightLength
            while (_g1 < 3):
                i1 = _g1
                _g1 = (_g1 + 1)
                rightComponents.append("0")
        leftString = ".".join([python_Boot.toString1(x1,'') for x1 in leftComponents])
        rightString = ".".join([python_Boot.toString1(x1,'') for x1 in rightComponents])
        tmp = None
        if (True if ((leftString is None)) else (len(StringTools.trim(leftString)) == 0)):
            tmp = False
        else:
            _this = hx_strings__Version_Version_Impl_.VALIDATOR_VERSION
            tmp = hx_strings__Pattern_MatcherImpl(_this.ereg,_this.pattern,_this.options,leftString).matches()
        if (not tmp):
            apptimize_ABTLogger.w((("Unable to validate left (current) version: " + ("null" if leftString is None else leftString)) + ". Filter match is unknown."))
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        tmp1 = None
        if (True if ((rightString is None)) else (len(StringTools.trim(rightString)) == 0)):
            tmp1 = False
        else:
            _this1 = hx_strings__Version_Version_Impl_.VALIDATOR_VERSION
            tmp1 = hx_strings__Pattern_MatcherImpl(_this1.ereg,_this1.pattern,_this1.options,rightString).matches()
        if (not tmp1):
            apptimize_ABTLogger.w((("Unable to validate right (filter) version: " + ("null" if rightString is None else rightString)) + ". Filter match is unknown."))
            return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        leftVersion = hx_strings__Version_Version_Impl_.of(leftString)
        rightVersion = hx_strings__Version_Version_Impl_.of(rightString)
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorEquals):
            if (hx_strings__Version_Version_Impl_.compareTo(leftVersion,rightVersion,False) == 0):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorNotEquals):
            if (hx_strings__Version_Version_Impl_.compareTo(leftVersion,rightVersion,False) != 0):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThan):
            if (hx_strings__Version_Version_Impl_.compareTo(leftVersion,rightVersion) > 0):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorGreaterThanOrEqual):
            if (hx_strings__Version_Version_Impl_.compareTo(leftVersion,rightVersion) >= 0):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThan):
            if (hx_strings__Version_Version_Impl_.compareTo(leftVersion,rightVersion) < 0):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        if (operator == apptimize_filter_ABTFilterOperator.ABTFilterOperatorLessThanOrEqual):
            if (hx_strings__Version_Version_Impl_.compareTo(leftVersion,rightVersion) <= 0):
                return apptimize_filter_ABTFilterResult.ABTFilterResultTrue
            else:
                return apptimize_filter_ABTFilterResult.ABTFilterResultFalse
        apptimize_ABTLogger.w("Version comparison attempted with an invalid operator. Filter match is unknown.")
        return apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
apptimize_filter_ABTFilterUtils._hx_class = apptimize_filter_ABTFilterUtils
_hx_classes["apptimize.filter.ABTFilterUtils"] = apptimize_filter_ABTFilterUtils


class apptimize_filter_ABTFilterEnvironment:
    _hx_class_name = "apptimize.filter.ABTFilterEnvironment"
    __slots__ = ("userID", "anonID", "customProperties")
    _hx_fields = ["userID", "anonID", "customProperties"]
    _hx_methods = ["hash", "getUserOrAnonID"]

    def __init__(self,userId = None,anonId = None,customAttributes = None):
        self.userID = userId
        self.anonID = anonId
        self.customProperties = apptimize_support_properties_ABTCustomProperties()
        if (customAttributes is not None):
            self.customProperties.setProperties(apptimize_util_ABTUtilDictionary.nativeObjectToStringMap(customAttributes))

    def hash(self):
        hasher = apptimize_util_ABTHash()
        if (self.userID is None):
            hasher.push(haxe_io_Bytes.ofString(self.anonID))
        else:
            hasher.push(haxe_io_Bytes.ofString(self.userID))
        key = self.customProperties.availableProperties.keys()
        while key.hasNext():
            key1 = key.next()
            hasher.push(haxe_io_Bytes.ofString(key1))
            value = self.customProperties.availableProperties.h.get(key1,None)
            hasher.push(haxe_io_Bytes.ofString(("" + Std.string(value))))
        key2 = apptimize_support_properties_ABTApplicationProperties.sharedInstance().availableProperties.keys()
        while key2.hasNext():
            key3 = key2.next()
            hasher.push(haxe_io_Bytes.ofString(key3))
            value1 = apptimize_support_properties_ABTApplicationProperties.sharedInstance().availableProperties.h.get(key3,None)
            hasher.push(haxe_io_Bytes.ofString(("" + Std.string(value1))))
        key4 = apptimize_support_properties_ABTInternalProperties.sharedInstance().availableProperties.keys()
        while key4.hasNext():
            key5 = key4.next()
            hasher.push(haxe_io_Bytes.ofString(key5))
            value2 = apptimize_support_properties_ABTInternalProperties.sharedInstance().availableProperties.h.get(key5,None)
            hasher.push(haxe_io_Bytes.ofString(("" + Std.string(value2))))
        return hasher.hash()

    def getUserOrAnonID(self):
        if (self.userID is not None):
            return self.userID
        return self.anonID

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.userID = None
        _hx_o.anonID = None
        _hx_o.customProperties = None
apptimize_filter_ABTFilterEnvironment._hx_class = apptimize_filter_ABTFilterEnvironment
_hx_classes["apptimize.filter.ABTFilterEnvironment"] = apptimize_filter_ABTFilterEnvironment


class apptimize_filter_ABTFilterableObject:
    _hx_class_name = "apptimize.filter.ABTFilterableObject"
    __slots__ = ("filters", "filters2", "overridingInclusiveFilters", "matchingFilters", "nonMatchingFilters", "filterResult", "isOverridingInclusiveFilter")
    _hx_fields = ["filters", "filters2", "overridingInclusiveFilters", "matchingFilters", "nonMatchingFilters", "filterResult", "isOverridingInclusiveFilter"]
    _hx_methods = ["initialize", "performFilterMatchingWithEnvironment", "fromJSON"]

    def __init__(self):
        self.isOverridingInclusiveFilter = None
        self.filterResult = None
        self.nonMatchingFilters = None
        self.matchingFilters = None
        self.overridingInclusiveFilters = None
        self.filters2 = None
        self.filters = None
        self.initialize()

    def initialize(self):
        self.filters = list()
        self.filters2 = list()
        self.matchingFilters = list()
        self.nonMatchingFilters = list()
        self.overridingInclusiveFilters = list()
        self.filterResult = apptimize_filter_ABTFilterResult.ABTFilterResultUnknown
        self.isOverridingInclusiveFilter = False

    def performFilterMatchingWithEnvironment(self,env):
        filterResult = apptimize_filter_ABTFilterResult.ABTFilterResultTrue
        if (self.filters is None):
            return filterResult
        _g = 0
        _g1 = self.filters
        while (_g < len(_g1)):
            _hx_filter = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            match = _hx_filter.filterMatchesEnvironment(env)
            filterResult = apptimize_filter_ABTFilterUtils.ABTFilterAnd(filterResult,match)
        return filterResult

    def fromJSON(self,json):
        if (Reflect.field(json,"filters") is not None):
            filterArray = Reflect.field(json,"filters")
            _g = 0
            while (_g < len(filterArray)):
                _hx_filter = (filterArray[_g] if _g >= 0 and _g < len(filterArray) else None)
                _g = (_g + 1)
                _this = self.filters
                x = apptimize_filter_ABTFilter.filterFromJSON(_hx_filter)
                _this.append(x)
        if (Reflect.field(json,"filters2") is not None):
            filterArray1 = Reflect.field(json,"filters2")
            _g1 = 0
            while (_g1 < len(filterArray1)):
                filter1 = (filterArray1[_g1] if _g1 >= 0 and _g1 < len(filterArray1) else None)
                _g1 = (_g1 + 1)
                _this1 = self.filters2
                x1 = apptimize_filter_ABTFilter.filterFromJSON(filter1)
                _this1.append(x1)
        if (len(self.filters2) > 0):
            self.filters = (self.filters + self.filters2)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.filters = None
        _hx_o.filters2 = None
        _hx_o.overridingInclusiveFilters = None
        _hx_o.matchingFilters = None
        _hx_o.nonMatchingFilters = None
        _hx_o.filterResult = None
        _hx_o.isOverridingInclusiveFilter = None
apptimize_filter_ABTFilterableObject._hx_class = apptimize_filter_ABTFilterableObject
_hx_classes["apptimize.filter.ABTFilterableObject"] = apptimize_filter_ABTFilterableObject


class apptimize_http_ABTHttpResponse:
    _hx_class_name = "apptimize.http.ABTHttpResponse"
    __slots__ = ("bytes", "text", "responseCode", "etag")
    _hx_fields = ["bytes", "text", "responseCode", "etag"]
    _hx_methods = ["isSuccess"]

    def __init__(self):
        self.etag = None
        self.responseCode = -1
        self.text = ""
        self.bytes = None

    def isSuccess(self):
        if (self.responseCode != 200):
            return (self.responseCode == 304)
        else:
            return True

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.bytes = None
        _hx_o.text = None
        _hx_o.responseCode = None
        _hx_o.etag = None
apptimize_http_ABTHttpResponse._hx_class = apptimize_http_ABTHttpResponse
_hx_classes["apptimize.http.ABTHttpResponse"] = apptimize_http_ABTHttpResponse


class apptimize_http_ABTHttpRequestInterface:
    _hx_class_name = "apptimize.http.ABTHttpRequestInterface"
    __slots__ = ()
    _hx_methods = ["get", "post"]
apptimize_http_ABTHttpRequestInterface._hx_class = apptimize_http_ABTHttpRequestInterface
_hx_classes["apptimize.http.ABTHttpRequestInterface"] = apptimize_http_ABTHttpRequestInterface


class apptimize_http_ABTHttpRequest:
    _hx_class_name = "apptimize.http.ABTHttpRequest"
    __slots__ = ()
    _hx_statics = ["getRequestInterface", "get", "post"]

    @staticmethod
    def getRequestInterface():
        return apptimize_http_ABTHttpRequestPython()

    @staticmethod
    def get(url,requestHeaders,successCallback,failureCallback):
        requestInterface = apptimize_http_ABTHttpRequest.getRequestInterface()
        requestInterface.get(url,requestHeaders,successCallback,failureCallback)

    @staticmethod
    def post(url,data,appKey,successCallback,failureCallback):
        requestInterface = apptimize_http_ABTHttpRequest.getRequestInterface()
        requestInterface.post(url,data,appKey,successCallback,failureCallback)
apptimize_http_ABTHttpRequest._hx_class = apptimize_http_ABTHttpRequest
_hx_classes["apptimize.http.ABTHttpRequest"] = apptimize_http_ABTHttpRequest


class apptimize_http_ABTHttpRequestPython:
    _hx_class_name = "apptimize.http.ABTHttpRequestPython"
    __slots__ = ("_successCallback", "_failureCallback")
    _hx_fields = ["_successCallback", "_failureCallback"]
    _hx_methods = ["get", "processGetResponse", "post", "processPostResponse"]
    _hx_interfaces = [apptimize_http_ABTHttpRequestInterface]

    def __init__(self):
        self._failureCallback = None
        self._successCallback = None

    def get(self,url,requestHeaders,successCallback,failureCallback):
        isThreaded = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY)
        self._successCallback = successCallback
        self._failureCallback = failureCallback
        headers = apptimize_util_ABTUtilDictionary.stringMapToNativeDictionary(requestHeaders)
        if isThreaded:
            s = apptimize_native_python_Session()
            Reflect.field(s.headers,"update")(headers)
            session = apptimize_native_python_FuturesSession(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'session': s})))
            session.get(url,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'background_callback': self.processGetResponse})))
        else:
            try:
                resp = apptimize_native_python_Requests.get(url,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'headers': headers})))
                self.processGetResponse(None,resp)
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                exception = _hx_e1
                response = apptimize_http_ABTHttpResponse()
                response.text = (("Failed to download with GET request with exception: \"" + Std.string(exception)) + "\".")
                self._failureCallback(response)

    def processGetResponse(self,session,response):
        httpResponse = apptimize_http_ABTHttpResponse()
        httpResponse.bytes = Reflect.field(response,"content")
        httpResponse.responseCode = Reflect.field(response,"status_code")
        responseHeaders = Reflect.field(response,"headers")
        httpResponse.etag = responseHeaders.get("etag")
        if httpResponse.isSuccess():
            self._successCallback(httpResponse)
        else:
            self._failureCallback(httpResponse)

    def post(self,url,data,appKey,successCallback,failureCallback):
        isThreaded = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY)
        headers = dict()
        headers["X-App-Key"] = appKey
        headers["Content-Type"] = "application/json; charset=UTF-8"
        self._successCallback = successCallback
        self._failureCallback = failureCallback
        if isThreaded:
            s = apptimize_native_python_Session()
            Reflect.field(s.headers,"update")(headers)
            session = apptimize_native_python_FuturesSession(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'session': s})))
            session.post(url,data.b,None,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'background_callback': self.processPostResponse})))
        else:
            try:
                resp = apptimize_native_python_Requests.post(url,data.b,None,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'headers': headers})))
                self.processPostResponse(None,resp)
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                exception = _hx_e1
                response = apptimize_http_ABTHttpResponse()
                response.text = (((("Failed to POST to url  \"" + ("null" if url is None else url)) + "\" with exception: ") + Std.string(exception)) + ".")
                self._failureCallback(response)

    def processPostResponse(self,session,response):
        httpResponse = apptimize_http_ABTHttpResponse()
        httpResponse.text = Reflect.field(response,"text")
        httpResponse.responseCode = Reflect.field(response,"status_code")
        if httpResponse.isSuccess():
            self._successCallback(httpResponse)
        else:
            self._failureCallback(httpResponse)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._successCallback = None
        _hx_o._failureCallback = None
apptimize_http_ABTHttpRequestPython._hx_class = apptimize_http_ABTHttpRequestPython
_hx_classes["apptimize.http.ABTHttpRequestPython"] = apptimize_http_ABTHttpRequestPython


class apptimize_models_ABTAlteration(apptimize_filter_ABTFilterableObject):
    _hx_class_name = "apptimize.models.ABTAlteration"
    __slots__ = ("_variant", "_key")
    _hx_fields = ["_variant", "_key"]
    _hx_methods = ["fromJSON", "selectAlterationsIntoArray", "getKey", "getVariant"]
    _hx_statics = ["alterationFromJSON", "classForType"]
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilterableObject


    def __init__(self):
        self._key = None
        self._variant = None
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)

    def selectAlterationsIntoArray(self,env,target):
        filterResult = self.performFilterMatchingWithEnvironment(env)
        if (filterResult == apptimize_filter_ABTFilterResult.ABTFilterResultTrue):
            apptimize_ABTLogger.v((((((("Selecting alteration \"" + HxOverrides.stringOrNull(self.getKey())) + "\" for variant \"") + HxOverrides.stringOrNull(self.getVariant().getVariantName())) + "\" for user ") + HxOverrides.stringOrNull(env.getUserOrAnonID())) + "."))
            target.append(self)

    def getKey(self):
        return self._key

    def getVariant(self):
        return self._variant

    @staticmethod
    def alterationFromJSON(json,variant):
        classType = apptimize_models_ABTAlteration.classForType(Reflect.field(json,"type"))
        instance = classType(*[])
        instance.initialize()
        instance.fromJSON(json)
        instance._variant = variant
        return instance

    @staticmethod
    def classForType(_hx_type):
        if (_hx_type == "block"):
            return apptimize_models_ABTBlockAlteration
        return apptimize_models_ABTValueAlteration

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._variant = None
        _hx_o._key = None
apptimize_models_ABTAlteration._hx_class = apptimize_models_ABTAlteration
_hx_classes["apptimize.models.ABTAlteration"] = apptimize_models_ABTAlteration


class apptimize_models_ABTBlockAlteration(apptimize_models_ABTAlteration):
    _hx_class_name = "apptimize.models.ABTBlockAlteration"
    __slots__ = ("methodName",)
    _hx_fields = ["methodName"]
    _hx_methods = ["fromJSON"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_ABTAlteration


    def __init__(self):
        self.methodName = None
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        self._key = Reflect.field(json,"key")
        self.methodName = Reflect.field(json,"methodName")

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.methodName = None
apptimize_models_ABTBlockAlteration._hx_class = apptimize_models_ABTBlockAlteration
_hx_classes["apptimize.models.ABTBlockAlteration"] = apptimize_models_ABTBlockAlteration


class apptimize_models_ABTValueAlteration(apptimize_models_ABTAlteration):
    _hx_class_name = "apptimize.models.ABTValueAlteration"
    __slots__ = ("_value", "_type", "_nestedType", "_useDefaultValue")
    _hx_fields = ["_value", "_type", "_nestedType", "_useDefaultValue"]
    _hx_methods = ["fromJSON", "useDefaultValue", "getValue", "getType", "getNestedType"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_ABTAlteration


    def __init__(self):
        self._useDefaultValue = None
        self._nestedType = None
        self._type = None
        self._value = None
        super().__init__()

    def fromJSON(self,json):
        super().fromJSON(json)
        self._key = Reflect.field(json,"key")
        self._value = Reflect.field(json,"value")
        self._type = Reflect.field(json,"type")
        self._nestedType = Reflect.field(json,"nestedType")
        self._useDefaultValue = Reflect.field(json,"useDefaultValue")
        if ((self._value is not None) and ((self._type == "dictionary"))):
            self._value = apptimize_util_ABTUtilDictionary.dynamicToNativeDictionary(self._value)

    def useDefaultValue(self):
        return self._useDefaultValue

    def getValue(self):
        return self._value

    def getType(self):
        return self._type

    def getNestedType(self):
        return self._nestedType

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._value = None
        _hx_o._type = None
        _hx_o._nestedType = None
        _hx_o._useDefaultValue = None
apptimize_models_ABTValueAlteration._hx_class = apptimize_models_ABTValueAlteration
_hx_classes["apptimize.models.ABTValueAlteration"] = apptimize_models_ABTValueAlteration


class apptimize_models_ABTJSONObject:
    _hx_class_name = "apptimize.models.ABTJSONObject"
    __slots__ = ()
apptimize_models_ABTJSONObject._hx_class = apptimize_models_ABTJSONObject
_hx_classes["apptimize.models.ABTJSONObject"] = apptimize_models_ABTJSONObject


class apptimize_models_ABTMetadata:
    _hx_class_name = "apptimize.models.ABTMetadata"
    __slots__ = ("_jsonData", "_seedGroups", "_hotfixes", "_selectedAlterationsByKey", "_alterationCache", "_etag")
    _hx_fields = ["_jsonData", "_seedGroups", "_hotfixes", "_selectedAlterationsByKey", "_alterationCache", "_etag"]
    _hx_methods = ["_load_data", "_updateWithSelectedAlterations", "selectAlterationsIntoArray", "metadataProcessed", "getVariantsCyclesPhases", "clearAlterationCache", "getMetaData", "getSequenceNumber", "getCheckinUrls", "getAppKey", "getEtag", "setEtag", "hxSerialize", "hxUnserialize"]
    _hx_statics = ["loadFromString"]

    def __init__(self):
        self._etag = None
        self._alterationCache = None
        self._selectedAlterationsByKey = None
        self._hotfixes = None
        self._seedGroups = None
        self._jsonData = None

    def _load_data(self,content):
        self.clearAlterationCache()
        self._jsonData = python_lib_Json.loads(content,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        self._seedGroups = list()
        _g = 0
        _g1 = self._jsonData.seedGroups
        while (_g < len(_g1)):
            sg = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            _this = self._seedGroups
            x = apptimize_models_ABTSeedGroup(sg)
            _this.append(x)
        self._hotfixes = list()
        _g2 = 0
        _g11 = self._jsonData.hotfixes
        while (_g2 < len(_g11)):
            hf = (_g11[_g2] if _g2 >= 0 and _g2 < len(_g11) else None)
            _g2 = (_g2 + 1)
            _this1 = self._hotfixes
            x1 = apptimize_models_ABTHotfixVariant(hf)
            _this1.append(x1)

    def _updateWithSelectedAlterations(self,selections):
        self._selectedAlterationsByKey = haxe_ds_StringMap()
        _g = 0
        while (_g < len(selections)):
            alteration = (selections[_g] if _g >= 0 and _g < len(selections) else None)
            _g = (_g + 1)
            alt = alteration
            this1 = self._selectedAlterationsByKey
            k = alt.getKey()
            this1.h[k] = alt

    def selectAlterationsIntoArray(self,env):
        envHash = env.hash()
        if self._alterationCache.hasKey(envHash):
            return self._alterationCache.getValue(envHash)
        alterations = list()
        _g = 0
        _g1 = self._seedGroups
        while (_g < len(_g1)):
            seedgroup = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            seedgroup.selectAlterationsIntoArray(env,alterations)
        _g2 = 0
        _g11 = self._hotfixes
        while (_g2 < len(_g11)):
            hotfix = (_g11[_g2] if _g2 >= 0 and _g2 < len(_g11) else None)
            _g2 = (_g2 + 1)
            hotfix.selectAlterationsIntoArray(env,alterations)
        self._alterationCache.insert(envHash,alterations)
        self._updateWithSelectedAlterations(alterations)
        self.metadataProcessed(env,alterations)
        return alterations

    def metadataProcessed(self,env,alterations):
        metadataProcessedEntry = apptimize_models_results_ABTResultEntryMetadataProcessed(env,self.getSequenceNumber(),self.getVariantsCyclesPhases(alterations))
        apptimize_ABTDataStore.sharedInstance().addResultLogEntry(env,metadataProcessedEntry)

    def getVariantsCyclesPhases(self,alterations):
        variantsCyclesPhases = haxe_ds_IntMap()
        _g = 0
        while (_g < len(alterations)):
            alteration = (alterations[_g] if _g >= 0 and _g < len(alterations) else None)
            _g = (_g + 1)
            variant = alteration.getVariant()
            phase = variant.getPhase()
            variantStickyString = ((("v" + Std.string(variant.getVariantID())) + "_") + Std.string(variant.getCycle()))
            if apptimize_support_properties_ABTInternalProperties.sharedInstance().isNamespacedPropertyAvailable(variantStickyString,apptimize_support_properties_CustomPropertyNamespace.ApptimizeInternal):
                phase = apptimize_support_properties_ABTInternalProperties.sharedInstance().valueForNamespacedProperty(variantStickyString,apptimize_support_properties_CustomPropertyNamespace.ApptimizeInternal)
            if ((Type.getClass(variant) != apptimize_models_ABTHotfixVariant) and (not (variant.getVariantID() in variantsCyclesPhases.h))):
                k = variant.getVariantID()
                v = _hx_AnonObject({'v': variant.getVariantID(), 'c': variant.getCycle(), 'p': phase})
                variantsCyclesPhases.set(k,v)
        return Lambda.array(variantsCyclesPhases)

    def clearAlterationCache(self):
        self._alterationCache = apptimize_util_ABTLRUCache(apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.ALTERATION_CACHE_SIZE))

    def getMetaData(self):
        return self._jsonData

    def getSequenceNumber(self):
        return self._jsonData.sequenceNumber

    def getCheckinUrls(self):
        return self._jsonData.checkinUrls

    def getAppKey(self):
        return self._jsonData.appKey

    def getEtag(self):
        return self._etag

    def setEtag(self,etag):
        self._etag = etag

    def hxSerialize(self,s):
        s.serialize(haxe_format_JsonPrinter.print(self._jsonData,None,None))
        s.serialize(self._etag)

    def hxUnserialize(self,u):
        self._load_data(u.unserialize())
        self._etag = u.unserialize()

    @staticmethod
    def loadFromString(content):
        m = apptimize_models_ABTMetadata()
        m._load_data(content)
        return m

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._jsonData = None
        _hx_o._seedGroups = None
        _hx_o._hotfixes = None
        _hx_o._selectedAlterationsByKey = None
        _hx_o._alterationCache = None
        _hx_o._etag = None
apptimize_models_ABTMetadata._hx_class = apptimize_models_ABTMetadata
_hx_classes["apptimize.models.ABTMetadata"] = apptimize_models_ABTMetadata


class apptimize_models_ABTRange:
    _hx_class_name = "apptimize.models.ABTRange"
    __slots__ = ("start", "end")
    _hx_fields = ["start", "end"]
    _hx_methods = ["fromJSON"]

    def __init__(self,json):
        self.end = None
        self.start = None
        self.fromJSON(json)

    def fromJSON(self,json):
        self.start = (json[0] if 0 < len(json) else None)
        self.end = (json[1] if 1 < len(json) else None)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.start = None
        _hx_o.end = None
apptimize_models_ABTRange._hx_class = apptimize_models_ABTRange
_hx_classes["apptimize.models.ABTRange"] = apptimize_models_ABTRange


class apptimize_models_ABTRangeGroup(apptimize_filter_ABTFilterableObject):
    _hx_class_name = "apptimize.models.ABTRangeGroup"
    __slots__ = ("ranges", "seedGroups", "variants")
    _hx_fields = ["ranges", "seedGroups", "variants"]
    _hx_methods = ["fromJSON", "selectAlterationsIntoArray", "isSelectedBySeed"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilterableObject


    def __init__(self,group):
        self.variants = None
        self.seedGroups = None
        self.ranges = None
        super().__init__()
        self.fromJSON(group)

    def fromJSON(self,group):
        super().fromJSON(group)
        rangeGroup = group
        self.ranges = list()
        if (rangeGroup.ranges is not None):
            _g = 0
            _g1 = rangeGroup.ranges
            while (_g < len(_g1)):
                range = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                _this = self.ranges
                x = apptimize_models_ABTRange(range)
                _this.append(x)
        self.seedGroups = list()
        if (rangeGroup.seedGroups is not None):
            _g2 = 0
            _g11 = rangeGroup.seedGroups
            while (_g2 < len(_g11)):
                sg = (_g11[_g2] if _g2 >= 0 and _g2 < len(_g11) else None)
                _g2 = (_g2 + 1)
                _this1 = self.seedGroups
                x1 = apptimize_models_ABTSeedGroup(sg)
                _this1.append(x1)
        self.variants = list()
        if (rangeGroup.variants is not None):
            _g3 = 0
            _g12 = rangeGroup.variants
            while (_g3 < len(_g12)):
                variant = (_g12[_g3] if _g3 >= 0 and _g3 < len(_g12) else None)
                _g3 = (_g3 + 1)
                _this2 = self.variants
                x2 = apptimize_models_ABTVariant(variant)
                _this2.append(x2)

    def selectAlterationsIntoArray(self,env,target):
        if (self.performFilterMatchingWithEnvironment(env) != apptimize_filter_ABTFilterResult.ABTFilterResultTrue):
            return
        _g = 0
        _g1 = self.variants
        while (_g < len(_g1)):
            variant = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            variant.selectAlterationsIntoArray(env,target)
        _g2 = 0
        _g11 = self.seedGroups
        while (_g2 < len(_g11)):
            seedgroup = (_g11[_g2] if _g2 >= 0 and _g2 < len(_g11) else None)
            _g2 = (_g2 + 1)
            seedgroup.selectAlterationsIntoArray(env,target)

    def isSelectedBySeed(self,seed):
        _g = 0
        _g1 = self.ranges
        while (_g < len(_g1)):
            range = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if ((seed >= range.start) and ((seed < range.end))):
                return True
        return False

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.ranges = None
        _hx_o.seedGroups = None
        _hx_o.variants = None
apptimize_models_ABTRangeGroup._hx_class = apptimize_models_ABTRangeGroup
_hx_classes["apptimize.models.ABTRangeGroup"] = apptimize_models_ABTRangeGroup


class apptimize_models_ABTSeed:
    _hx_class_name = "apptimize.models.ABTSeed"
    __slots__ = ("type", "value")
    _hx_fields = ["type", "value"]
    _hx_methods = ["fromDef", "computedSeedMaterial"]

    def __init__(self,seed):
        self.value = None
        self.type = None
        self.fromDef(seed)

    def fromDef(self,seed):
        self.type = seed.type
        self.value = Reflect.field(seed,"value")

    def computedSeedMaterial(self,userID):
        if (self.type == "guid"):
            base = haxe_io_Bytes.ofString("0123456789abcdef")
            resultStr = StringTools.replace(userID,"-","").lower()
            try:
                if (len(resultStr) == 32):
                    return haxe_crypto_Sha1.make(haxe_crypto_BaseCode(base).decodeBytes(haxe_io_Bytes.ofString(resultStr)))
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                if isinstance(_hx_e1, str):
                    baseCodeError = _hx_e1
                    apptimize_ABTLogger.w("Invalid GUID supplied - treating as string user ID.")
                else:
                    raise _hx_e
            return haxe_crypto_Sha1.make(haxe_io_Bytes.ofString(userID))
        elif (self.value is not None):
            return haxe_crypto_Sha1.make(haxe_io_Bytes.ofString(self.value))
        else:
            apptimize_ABTLogger.e((("Unable to calculate seed for supplied user ID of type: " + HxOverrides.stringOrNull(self.type)) + "."))
            return None

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.type = None
        _hx_o.value = None
apptimize_models_ABTSeed._hx_class = apptimize_models_ABTSeed
_hx_classes["apptimize.models.ABTSeed"] = apptimize_models_ABTSeed


class apptimize_models_ABTSeedGroup(apptimize_filter_ABTFilterableObject):
    _hx_class_name = "apptimize.models.ABTSeedGroup"
    __slots__ = ("rangeGroups", "seeds")
    _hx_fields = ["rangeGroups", "seeds"]
    _hx_methods = ["fromJSON", "computedSeedMaterial", "seed", "selectAlterationsIntoArray"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilterableObject


    def __init__(self,group):
        self.seeds = None
        self.rangeGroups = None
        super().__init__()
        self.fromJSON(group)

    def fromJSON(self,group):
        super().fromJSON(group)
        jsonSeedGroup = group
        self.rangeGroups = list()
        if (jsonSeedGroup.rangeGroups is not None):
            _g = 0
            _g1 = jsonSeedGroup.rangeGroups
            while (_g < len(_g1)):
                range = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                _this = self.rangeGroups
                x = apptimize_models_ABTRangeGroup(range)
                _this.append(x)
        self.seeds = list()
        if (jsonSeedGroup.seeds is not None):
            _g2 = 0
            _g11 = jsonSeedGroup.seeds
            while (_g2 < len(_g11)):
                seed = (_g11[_g2] if _g2 >= 0 and _g2 < len(_g11) else None)
                _g2 = (_g2 + 1)
                _this1 = self.seeds
                x1 = apptimize_models_ABTSeed(seed)
                _this1.append(x1)

    def computedSeedMaterial(self,userID):
        buffer = haxe_io_BytesBuffer()
        _g = 0
        _g1 = self.seeds
        while (_g < len(_g1)):
            seed = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            b = seed.computedSeedMaterial(userID)
            _hx_len = b.length
            if ((_hx_len < 0) or ((_hx_len > b.length))):
                raise _HxException(haxe_io_Error.OutsideBounds)
            b1 = buffer.b
            b2 = b.b
            _g11 = 0
            _g2 = _hx_len
            while (_g11 < _g2):
                i = _g11
                _g11 = (_g11 + 1)
                _this = buffer.b
                _this.append(b2[i])
        return haxe_crypto_Sha1.make(buffer.getBytes())

    def seed(self,userID):
        data = self.computedSeedMaterial(userID)
        _hx_len = data.length
        if (_hx_len < 4):
            apptimize_ABTLogger.e((("User ID length too short for seed: " + Std.string(_hx_len)) + "."))
            return 0
        l = (_hx_len - 4)
        seed = (((data.b[(l + 3)] | ((data.b[(l + 2)] << 8))) | ((data.b[(l + 1)] << 16))) | ((data.b[l] << 24)))
        seed = (seed & 1073741823)
        return seed

    def selectAlterationsIntoArray(self,env,target):
        if (self.performFilterMatchingWithEnvironment(env) != apptimize_filter_ABTFilterResult.ABTFilterResultTrue):
            return
        seed = self.seed(env.getUserOrAnonID())
        apptimize_ABTLogger.v((((("Calculated seed for user " + HxOverrides.stringOrNull(env.getUserOrAnonID())) + ": ") + Std.string(seed)) + "."))
        _g = 0
        _g1 = self.rangeGroups
        while (_g < len(_g1)):
            rangeGroup = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if rangeGroup.isSelectedBySeed(seed):
                rangeGroup.selectAlterationsIntoArray(env,target)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.rangeGroups = None
        _hx_o.seeds = None
apptimize_models_ABTSeedGroup._hx_class = apptimize_models_ABTSeedGroup
_hx_classes["apptimize.models.ABTSeedGroup"] = apptimize_models_ABTSeedGroup


class apptimize_models_ABTVariant(apptimize_filter_ABTFilterableObject):
    _hx_class_name = "apptimize.models.ABTVariant"
    __slots__ = ("alterations", "alterations2", "codeBlockName", "experimentId", "experimentName", "experimentType", "startTime", "variantId", "variantName", "cycle", "phase")
    _hx_fields = ["alterations", "alterations2", "codeBlockName", "experimentId", "experimentName", "experimentType", "startTime", "variantId", "variantName", "cycle", "phase"]
    _hx_methods = ["fromJSON", "selectAlterationsIntoArray", "getVariantID", "getVariantName", "getExperimentID", "getExperimentName", "getCodeBlockName", "getPhase", "getCycle"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_filter_ABTFilterableObject


    def __init__(self,variant):
        self.phase = None
        self.cycle = None
        self.variantName = None
        self.variantId = None
        self.startTime = None
        self.experimentType = None
        self.experimentName = None
        self.experimentId = None
        self.codeBlockName = None
        self.alterations2 = None
        self.alterations = None
        super().__init__()
        self.fromJSON(variant)

    def fromJSON(self,obj):
        super().fromJSON(obj)
        variant = obj
        self.alterations = list()
        self.alterations2 = list()
        _g = 0
        _g1 = variant.alterations
        while (_g < len(_g1)):
            alteration = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            _this = self.alterations
            x = apptimize_models_ABTAlteration.alterationFromJSON(alteration,self)
            _this.append(x)
        self.overridingInclusiveFilters = list()
        self.codeBlockName = variant.codeBlockName
        if (Type.getClass(self) != apptimize_models_ABTHotfixVariant):
            self.experimentId = variant.experimentId
            self.experimentName = variant.experimentName
            self.experimentType = variant.experimentType
            self.startTime = variant.startTime
            self.variantName = variant.variantName
            self.variantId = variant.variantId
            self.cycle = variant.cycle
            self.phase = variant.phase
        if (hasattr(variant,(("_hx_" + "alterations2") if (("alterations2" in python_Boot.keywords)) else (("_hx_" + "alterations2") if (((((len("alterations2") > 2) and ((ord("alterations2"[0]) == 95))) and ((ord("alterations2"[1]) == 95))) and ((ord("alterations2"[(len("alterations2") - 1)]) != 95)))) else "alterations2"))) and ((variant.alterations2 is not None))):
            _g2 = 0
            _g11 = variant.alterations2
            while (_g2 < len(_g11)):
                alteration1 = (_g11[_g2] if _g2 >= 0 and _g2 < len(_g11) else None)
                _g2 = (_g2 + 1)
                _this1 = self.alterations2
                x1 = apptimize_models_ABTAlteration.alterationFromJSON(alteration1,self)
                _this1.append(x1)
            self.alterations = (self.alterations + self.alterations2)

    def selectAlterationsIntoArray(self,env,target):
        if (self.performFilterMatchingWithEnvironment(env) != apptimize_filter_ABTFilterResult.ABTFilterResultTrue):
            return
        _g = 0
        _g1 = self.alterations
        while (_g < len(_g1)):
            alteration = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            alteration.selectAlterationsIntoArray(env,target)

    def getVariantID(self):
        return self.variantId

    def getVariantName(self):
        return self.variantName

    def getExperimentID(self):
        return self.experimentId

    def getExperimentName(self):
        return self.experimentName

    def getCodeBlockName(self):
        return self.codeBlockName

    def getPhase(self):
        return self.phase

    def getCycle(self):
        return self.cycle

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.alterations = None
        _hx_o.alterations2 = None
        _hx_o.codeBlockName = None
        _hx_o.experimentId = None
        _hx_o.experimentName = None
        _hx_o.experimentType = None
        _hx_o.startTime = None
        _hx_o.variantId = None
        _hx_o.variantName = None
        _hx_o.cycle = None
        _hx_o.phase = None
apptimize_models_ABTVariant._hx_class = apptimize_models_ABTVariant
_hx_classes["apptimize.models.ABTVariant"] = apptimize_models_ABTVariant


class apptimize_models_ABTHotfixVariant(apptimize_models_ABTVariant):
    _hx_class_name = "apptimize.models.ABTHotfixVariant"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_ABTVariant


    def __init__(self,variant):
        super().__init__(variant)
apptimize_models_ABTHotfixVariant._hx_class = apptimize_models_ABTHotfixVariant
_hx_classes["apptimize.models.ABTHotfixVariant"] = apptimize_models_ABTHotfixVariant


class haxe__Int64____Int64:
    _hx_class_name = "haxe._Int64.___Int64"
    __slots__ = ("high", "low")
    _hx_fields = ["high", "low"]

    def __init__(self,high,low):
        self.high = high
        self.low = low

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.high = None
        _hx_o.low = None
haxe__Int64____Int64._hx_class = haxe__Int64____Int64
_hx_classes["haxe._Int64.___Int64"] = haxe__Int64____Int64


class apptimize_models_results_ABTResultEntry(apptimize_models_ABTJSONObject):
    _hx_class_name = "apptimize.models.results.ABTResultEntry"
    __slots__ = ("_id", "_monotonicTimestamp", "_deviceTimestamp", "_userAttributes", "_prefixedAttributes")
    _hx_fields = ["_id", "_monotonicTimestamp", "_deviceTimestamp", "_userAttributes", "_prefixedAttributes"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = ["_sequenceNumber", "_lastTimestamp"]
    _hx_interfaces = []
    _hx_super = apptimize_models_ABTJSONObject


    def __init__(self,env):
        self._prefixedAttributes = None
        self._userAttributes = None
        self._monotonicTimestamp = None
        ret = apptimize_models_results_ABTResultEntry._sequenceNumber
        this1 = haxe__Int64____Int64(apptimize_models_results_ABTResultEntry._sequenceNumber.high,apptimize_models_results_ABTResultEntry._sequenceNumber.low)
        apptimize_models_results_ABTResultEntry._sequenceNumber = this1
        def _hx_local_2():
            _hx_local_0 = apptimize_models_results_ABTResultEntry._sequenceNumber
            _hx_local_1 = _hx_local_0.low
            _hx_local_0.low = (_hx_local_1 + 1)
            return _hx_local_1
        ret1 = _hx_local_2()
        tmp = (apptimize_models_results_ABTResultEntry._sequenceNumber.low + (2 ** 31)) % (2 ** 32)
        tmp1 = (2 ** 31)
        apptimize_models_results_ABTResultEntry._sequenceNumber.low = (tmp - tmp1)
        if (apptimize_models_results_ABTResultEntry._sequenceNumber.low == 0):
            def _hx_local_5():
                _hx_local_3 = apptimize_models_results_ABTResultEntry._sequenceNumber
                _hx_local_4 = _hx_local_3.high
                _hx_local_3.high = (_hx_local_4 + 1)
                return _hx_local_4
            ret2 = _hx_local_5()
            tmp2 = (apptimize_models_results_ABTResultEntry._sequenceNumber.high + (2 ** 31)) % (2 ** 32)
            tmp3 = (2 ** 31)
            apptimize_models_results_ABTResultEntry._sequenceNumber.high = (tmp2 - tmp3)
        self._id = apptimize_models_results_ABTResultEntry._sequenceNumber
        self._deviceTimestamp = haxe_Int64Helper.fromFloat((python_lib_Time.mktime(Date.now().date.timetuple()) * 1000))
        self._monotonicTimestamp = self._deviceTimestamp
        a = apptimize_models_results_ABTResultEntry._lastTimestamp
        b = self._monotonicTimestamp
        v = (((a.high - b.high) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
        if (v != 0):
            v = v
        else:
            v = haxe__Int32_Int32_Impl_.ucompare(a.low,b.low)
        if ((((v if ((b.high < 0)) else -1) if ((a.high < 0)) else (v if ((b.high >= 0)) else 1))) >= 0):
            a1 = apptimize_models_results_ABTResultEntry._lastTimestamp
            this2 = haxe__Int64____Int64(0,1)
            b1 = this2
            high = (((a1.high + b1.high) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            low = (((a1.low + b1.low) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            if (haxe__Int32_Int32_Impl_.ucompare(low,a1.low) < 0):
                ret3 = high
                high = (high + 1)
                high = ((high + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            this3 = haxe__Int64____Int64(high,low)
            self._monotonicTimestamp = this3
        apptimize_models_results_ABTResultEntry._lastTimestamp = self._monotonicTimestamp
        self._prefixedAttributes = haxe_ds_StringMap()
        if ((env is not None) and ((env.customProperties.availableProperties is not None))):
            env.customProperties.addJSONProperties(self._prefixedAttributes)
        apptimize_support_properties_ABTInternalProperties.sharedInstance().addJSONProperties(self._prefixedAttributes)
        apptimize_support_properties_ABTApplicationProperties.sharedInstance().addJSONProperties(self._prefixedAttributes)

    def JSONRepresentation(self):
        _g = haxe_ds_StringMap()
        value = apptimize_util_ABTInt64Utils.toPreprocessedString(self._id)
        _g.h["ei"] = value
        value1 = apptimize_util_ABTInt64Utils.toPreprocessedString(self._monotonicTimestamp)
        _g.h["mt"] = value1
        value2 = apptimize_util_ABTInt64Utils.toPreprocessedString(self._deviceTimestamp)
        _g.h["dt"] = value2
        _g.h["pa"] = self._prefixedAttributes
        jsonDict = _g
        if (self._userAttributes is not None):
            v = self._userAttributes
            jsonDict.h["ua"] = v
        return jsonDict

    def hxSerialize(self,s):
        apptimize_util_ABTInt64Utils._serializeInt64(self._id,s)
        apptimize_util_ABTInt64Utils._serializeInt64(self._monotonicTimestamp,s)
        apptimize_util_ABTInt64Utils._serializeInt64(self._deviceTimestamp,s)
        s.serialize(self._userAttributes)
        s.serialize(self._prefixedAttributes)

    def hxUnserialize(self,u):
        self._id = apptimize_util_ABTInt64Utils._deserializeInt64(u)
        self._monotonicTimestamp = apptimize_util_ABTInt64Utils._deserializeInt64(u)
        self._deviceTimestamp = apptimize_util_ABTInt64Utils._deserializeInt64(u)
        self._userAttributes = u.unserialize()
        self._prefixedAttributes = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._id = None
        _hx_o._monotonicTimestamp = None
        _hx_o._deviceTimestamp = None
        _hx_o._userAttributes = None
        _hx_o._prefixedAttributes = None
apptimize_models_results_ABTResultEntry._hx_class = apptimize_models_results_ABTResultEntry
_hx_classes["apptimize.models.results.ABTResultEntry"] = apptimize_models_results_ABTResultEntry


class apptimize_models_results_ABTResultEntryVariantShown(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryVariantShown"
    __slots__ = ("_type", "_variantID", "_cycle", "_phase")
    _hx_fields = ["_type", "_variantID", "_cycle", "_phase"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,env,variantID,cycle,phase):
        self._phase = None
        self._cycle = None
        self._variantID = None
        self._type = "v"
        super().__init__(env)
        self._variantID = variantID
        self._cycle = cycle
        self._phase = phase

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = self._variantID
        jsonDict.h["v"] = v1
        _g = haxe_ds_StringMap()
        _g.h["v"] = self._variantID
        _g.h["c"] = self._cycle
        _g.h["p"] = self._phase
        v2 = _g
        jsonDict.h["vp"] = v2
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        s.serialize(self._variantID)
        s.serialize(self._cycle)
        s.serialize(self._phase)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._variantID = u.unserialize()
        self._cycle = u.unserialize()
        self._phase = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._variantID = None
        _hx_o._cycle = None
        _hx_o._phase = None
apptimize_models_results_ABTResultEntryVariantShown._hx_class = apptimize_models_results_ABTResultEntryVariantShown
_hx_classes["apptimize.models.results.ABTResultEntryVariantShown"] = apptimize_models_results_ABTResultEntryVariantShown


class apptimize_models_results_ABTResultEntryEvent(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryEvent"
    __slots__ = ("_type", "_name", "_source", "_attributes")
    _hx_fields = ["_type", "_name", "_source", "_attributes"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,env,name,source,attributes):
        self._attributes = None
        self._source = None
        self._name = None
        self._type = "ee"
        super().__init__(env)
        self._name = name
        self._source = source
        self._attributes = attributes

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = self._name
        jsonDict.h["n"] = v1
        v2 = self._source
        jsonDict.h["s"] = v2
        v3 = self._attributes
        jsonDict.h["a"] = v3
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        s.serialize(self._name)
        s.serialize(self._source)
        s.serialize(self._attributes)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._name = u.unserialize()
        self._source = u.unserialize()
        self._attributes = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._name = None
        _hx_o._source = None
        _hx_o._attributes = None
apptimize_models_results_ABTResultEntryEvent._hx_class = apptimize_models_results_ABTResultEntryEvent
_hx_classes["apptimize.models.results.ABTResultEntryEvent"] = apptimize_models_results_ABTResultEntryEvent


class apptimize_models_results_ABTResultEntryMetadataProcessed(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryMetadataProcessed"
    __slots__ = ("_type", "_metadataSequenceNumber", "_enrolledVariantsCyclesPhases", "_enrolledVariantIDs")
    _hx_fields = ["_type", "_metadataSequenceNumber", "_enrolledVariantsCyclesPhases", "_enrolledVariantIDs"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,env,sequence,enrolledVariantsCyclesPhases):
        self._enrolledVariantIDs = None
        self._enrolledVariantsCyclesPhases = None
        self._metadataSequenceNumber = None
        self._type = "md"
        super().__init__(env)
        self._metadataSequenceNumber = sequence
        self._enrolledVariantsCyclesPhases = enrolledVariantsCyclesPhases
        self._enrolledVariantIDs = list()
        _g = 0
        _g1 = self._enrolledVariantsCyclesPhases
        while (_g < len(_g1)):
            variantCyclePhase = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            _this = self._enrolledVariantIDs
            x = variantCyclePhase.v
            _this.append(x)

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        if (len(self._enrolledVariantsCyclesPhases) > 0):
            v = self._enrolledVariantsCyclesPhases
            jsonDict.h["vp"] = v
        v1 = self._enrolledVariantIDs
        jsonDict.h["v"] = v1
        v2 = self._metadataSequenceNumber
        jsonDict.h["s"] = v2
        v3 = self._type
        jsonDict.h["ty"] = v3
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        s.serialize(self._metadataSequenceNumber)
        s.serialize(self._enrolledVariantIDs)
        s.serialize(self._enrolledVariantsCyclesPhases)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._metadataSequenceNumber = u.unserialize()
        self._enrolledVariantIDs = u.unserialize()
        self._enrolledVariantsCyclesPhases = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._metadataSequenceNumber = None
        _hx_o._enrolledVariantsCyclesPhases = None
        _hx_o._enrolledVariantIDs = None
apptimize_models_results_ABTResultEntryMetadataProcessed._hx_class = apptimize_models_results_ABTResultEntryMetadataProcessed
_hx_classes["apptimize.models.results.ABTResultEntryMetadataProcessed"] = apptimize_models_results_ABTResultEntryMetadataProcessed


class apptimize_models_results_ABTResultEntryAttributesChanged(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryAttributesChanged"
    __slots__ = ("_type", "_enrolledVariantsCyclesPhases", "_enrolledVariantIDs")
    _hx_fields = ["_type", "_enrolledVariantsCyclesPhases", "_enrolledVariantIDs"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,env,enrolledVariantsCyclesPhases):
        self._enrolledVariantIDs = None
        self._enrolledVariantsCyclesPhases = None
        self._type = "ac"
        super().__init__(env)
        self._enrolledVariantsCyclesPhases = enrolledVariantsCyclesPhases
        self._enrolledVariantIDs = list()
        _g = 0
        _g1 = self._enrolledVariantsCyclesPhases
        while (_g < len(_g1)):
            variantCyclePhase = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            _this = self._enrolledVariantIDs
            x = variantCyclePhase.v
            _this.append(x)

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = self._enrolledVariantIDs
        jsonDict.h["v"] = v1
        if (len(self._enrolledVariantsCyclesPhases) > 0):
            v2 = self._enrolledVariantsCyclesPhases
            jsonDict.h["vp"] = v2
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        s.serialize(self._enrolledVariantIDs)
        s.serialize(self._enrolledVariantsCyclesPhases)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._enrolledVariantIDs = u.unserialize()
        self._enrolledVariantsCyclesPhases = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._enrolledVariantsCyclesPhases = None
        _hx_o._enrolledVariantIDs = None
apptimize_models_results_ABTResultEntryAttributesChanged._hx_class = apptimize_models_results_ABTResultEntryAttributesChanged
_hx_classes["apptimize.models.results.ABTResultEntryAttributesChanged"] = apptimize_models_results_ABTResultEntryAttributesChanged


class apptimize_models_results_ABTResultEntryUserEnd(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryUserEnd"
    __slots__ = ("_type", "_nextUserID")
    _hx_fields = ["_type", "_nextUserID"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,env,nextUserID):
        self._nextUserID = None
        self._type = "ue"
        super().__init__(env)
        self._nextUserID = nextUserID

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = self._nextUserID
        jsonDict.h["n"] = v1
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        s.serialize(self._nextUserID)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._nextUserID = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._nextUserID = None
apptimize_models_results_ABTResultEntryUserEnd._hx_class = apptimize_models_results_ABTResultEntryUserEnd
_hx_classes["apptimize.models.results.ABTResultEntryUserEnd"] = apptimize_models_results_ABTResultEntryUserEnd


class apptimize_models_results_ABTResultEntryUserStart(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryUserStart"
    __slots__ = ("_type", "_previousUserID")
    _hx_fields = ["_type", "_previousUserID"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,env,previousUserID):
        self._previousUserID = None
        self._type = "us"
        super().__init__(env)
        self._previousUserID = previousUserID

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = self._previousUserID
        jsonDict.h["p"] = v1
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        s.serialize(self._previousUserID)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._previousUserID = u.unserialize()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._previousUserID = None
apptimize_models_results_ABTResultEntryUserStart._hx_class = apptimize_models_results_ABTResultEntryUserStart
_hx_classes["apptimize.models.results.ABTResultEntryUserStart"] = apptimize_models_results_ABTResultEntryUserStart


class apptimize_models_results_ABTResultEntrySuccessfullyPosted(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntrySuccessfullyPosted"
    __slots__ = ("_type", "_timestampFromServer", "_firstEntryID", "_lastEntryID")
    _hx_fields = ["_type", "_timestampFromServer", "_firstEntryID", "_lastEntryID"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,timestampFromServer,firstEntryID,lastEntryID):
        this1 = haxe__Int64____Int64(0,0)
        self._lastEntryID = this1
        this11 = haxe__Int64____Int64(0,0)
        self._firstEntryID = this11
        this12 = haxe__Int64____Int64(0,0)
        self._timestampFromServer = this12
        self._type = "sp"
        super().__init__(None)
        self._timestampFromServer = timestampFromServer
        self._firstEntryID = firstEntryID
        self._lastEntryID = lastEntryID

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = apptimize_util_ABTInt64Utils.toPreprocessedString(self._timestampFromServer)
        jsonDict.h["t"] = v1
        v2 = apptimize_util_ABTInt64Utils.toPreprocessedString(self._firstEntryID)
        jsonDict.h["f"] = v2
        v3 = apptimize_util_ABTInt64Utils.toPreprocessedString(self._lastEntryID)
        jsonDict.h["l"] = v3
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        apptimize_util_ABTInt64Utils._serializeInt64(self._timestampFromServer,s)
        apptimize_util_ABTInt64Utils._serializeInt64(self._firstEntryID,s)
        apptimize_util_ABTInt64Utils._serializeInt64(self._lastEntryID,s)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._timestampFromServer = apptimize_util_ABTInt64Utils._deserializeInt64(u)
        self._firstEntryID = apptimize_util_ABTInt64Utils._deserializeInt64(u)
        self._lastEntryID = apptimize_util_ABTInt64Utils._deserializeInt64(u)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._timestampFromServer = None
        _hx_o._firstEntryID = None
        _hx_o._lastEntryID = None
apptimize_models_results_ABTResultEntrySuccessfullyPosted._hx_class = apptimize_models_results_ABTResultEntrySuccessfullyPosted
_hx_classes["apptimize.models.results.ABTResultEntrySuccessfullyPosted"] = apptimize_models_results_ABTResultEntrySuccessfullyPosted


class apptimize_models_results_ABTResultEntryDataTypeLimitReached(apptimize_models_results_ABTResultEntry):
    _hx_class_name = "apptimize.models.results.ABTResultEntryDataTypeLimitReached"
    __slots__ = ("_type", "_currentEntryCount")
    _hx_fields = ["_type", "_currentEntryCount"]
    _hx_methods = ["JSONRepresentation", "hxSerialize", "hxUnserialize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_models_results_ABTResultEntry


    def __init__(self,currentEntryCount):
        this1 = haxe__Int64____Int64(0,0)
        self._currentEntryCount = this1
        self._type = "dl"
        super().__init__(None)
        self._currentEntryCount = currentEntryCount

    def JSONRepresentation(self):
        jsonDict = super().JSONRepresentation()
        v = self._type
        jsonDict.h["ty"] = v
        v1 = apptimize_util_ABTInt64Utils.toPreprocessedString(self._currentEntryCount)
        jsonDict.h["c"] = v1
        return jsonDict

    def hxSerialize(self,s):
        super().hxSerialize(s)
        s.serialize(self._type)
        apptimize_util_ABTInt64Utils._serializeInt64(self._currentEntryCount,s)

    def hxUnserialize(self,u):
        super().hxUnserialize(u)
        self._type = u.unserialize()
        self._currentEntryCount = apptimize_util_ABTInt64Utils._deserializeInt64(u)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._type = None
        _hx_o._currentEntryCount = None
apptimize_models_results_ABTResultEntryDataTypeLimitReached._hx_class = apptimize_models_results_ABTResultEntryDataTypeLimitReached
_hx_classes["apptimize.models.results.ABTResultEntryDataTypeLimitReached"] = apptimize_models_results_ABTResultEntryDataTypeLimitReached


class apptimize_models_results_ABTResultLog:
    _hx_class_name = "apptimize.models.results.ABTResultLog"
    __slots__ = ("entries", "userID", "anonID")
    _hx_fields = ["entries", "userID", "anonID"]
    _hx_methods = ["logEntry", "entryCount", "toJSON"]

    def __init__(self,env):
        self.anonID = None
        self.userID = None
        if (env is not None):
            self.userID = env.userID
            self.anonID = env.anonID
        self.entries = list()

    def logEntry(self,entry):
        _this = self.entries
        _this.append(entry)

    def entryCount(self):
        return len(self.entries)

    def toJSON(self):
        json = haxe_ds_StringMap()
        jsonEntries = list()
        _g = 0
        _g1 = self.entries
        while (_g < len(_g1)):
            entry = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            x = entry.JSONRepresentation()
            jsonEntries.append(x)
        v = "v4"
        json.h["type"] = v
        v1 = apptimize_ABTDataStore.getAppKey()
        json.h["a"] = v1
        v2 = apptimize_ABTDataStore.getServerGUID()
        json.h["g"] = v2
        currentDate = Date.now()
        nowMs = haxe_Int64Helper.fromFloat((python_lib_Time.mktime(Date.now().date.timetuple()) * 1000))
        v3 = apptimize_util_ABTInt64Utils.toPreprocessedString(nowMs)
        json.h["c"] = v3
        v4 = jsonEntries
        json.h["e"] = v4
        v5 = ("Cross Platform " + HxOverrides.stringOrNull(Apptimize.getApptimizeSDKVersion()))
        json.h["v"] = v5
        if (self.userID is not None):
            v6 = self.userID
            json.h["u"] = v6
        return apptimize_util_ABTJSONUtils.stringify(json)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.entries = None
        _hx_o.userID = None
        _hx_o.anonID = None
apptimize_models_results_ABTResultLog._hx_class = apptimize_models_results_ABTResultLog
_hx_classes["apptimize.models.results.ABTResultLog"] = apptimize_models_results_ABTResultLog


class apptimize_support_initialize_ABTPlatformInitialize:
    _hx_class_name = "apptimize.support.initialize.ABTPlatformInitialize"
    __slots__ = ()
    _hx_statics = ["_metadataTimer", "_interval", "_backgroundInterval", "initialize", "_onExit", "_setupPolling"]
    _metadataTimer = None
    _interval = None
    _backgroundInterval = None

    @staticmethod
    def initialize():
        apptimize_support_persistence_ABTPersistence.saveString(apptimize_support_persistence_ABTPersistence.kApptimizeVersionKey,Apptimize.getApptimizeSDKVersion())
        isThreaded = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY)
        if isThreaded:
            apptimize_native_python_AtExit.register(apptimize_support_initialize_ABTPlatformInitialize._onExit)
            def _hx_local_0():
                haxe_EntryPoint.run()
            worker = _hx_local_0
            eventThread = python_lib_threading_Thread(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'target': worker})))
            eventThread.daemon = True
            apptimize_support_initialize_ABTPlatformInitialize._setupPolling()
            eventThread.start()
        Apptimize.updateApptimizeMetadataOnce()

    @staticmethod
    def _onExit():
        apptimize_support_initialize_ABTPlatformInitialize._metadataTimer.stop()

    @staticmethod
    def _setupPolling():
        apptimize_support_initialize_ABTPlatformInitialize._interval = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_INTERVAL_MS)
        apptimize_support_initialize_ABTPlatformInitialize._backgroundInterval = apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_BACKGROUND_INTERVAL_MS)
        if (apptimize_support_initialize_ABTPlatformInitialize._interval > 0):
            apptimize_ABTLogger.v((("Metadata update interval set to " + Std.string(apptimize_support_initialize_ABTPlatformInitialize._interval)) + " milliseconds."))
            apptimize_support_initialize_ABTPlatformInitialize._metadataTimer = haxe_Timer(apptimize_support_initialize_ABTPlatformInitialize._interval)
            apptimize_support_initialize_ABTPlatformInitialize._metadataTimer.run = Apptimize.updateApptimizeMetadataOnce
apptimize_support_initialize_ABTPlatformInitialize._hx_class = apptimize_support_initialize_ABTPlatformInitialize
_hx_classes["apptimize.support.initialize.ABTPlatformInitialize"] = apptimize_support_initialize_ABTPlatformInitialize


class apptimize_support_persistence_ABTPersistentInterface:
    _hx_class_name = "apptimize.support.persistence.ABTPersistentInterface"
    __slots__ = ()
    _hx_methods = ["save", "load", "clear"]
apptimize_support_persistence_ABTPersistentInterface._hx_class = apptimize_support_persistence_ABTPersistentInterface
_hx_classes["apptimize.support.persistence.ABTPersistentInterface"] = apptimize_support_persistence_ABTPersistentInterface


class apptimize_support_persistence_ABTPIDiskStorage:
    _hx_class_name = "apptimize.support.persistence.ABTPIDiskStorage"
    __slots__ = ("_localStoragePath", "_extension", "_keys")
    _hx_fields = ["_localStoragePath", "_extension", "_keys"]
    _hx_methods = ["dataFromDisk", "deleteFile", "save", "load", "clear"]
    _hx_interfaces = [apptimize_support_persistence_ABTPersistentInterface]

    def __init__(self):
        self._keys = None
        self._extension = ".data"
        self._localStoragePath = "data/apptimize/"
        if (not sys_FileSystem.exists(self._localStoragePath)):
            sys_FileSystem.createDirectory(self._localStoragePath)
        self._keys = list()

    def dataFromDisk(self,path,localPath = ""):
        if (localPath is None):
            localPath = ""
        filePath = ((("null" if localPath is None else localPath) + ("null" if path is None else path)) + HxOverrides.stringOrNull(self._extension))
        if sys_FileSystem.exists(filePath):
            content = sys_io_File.getContent(filePath)
            return content
        else:
            apptimize_ABTLogger.v((("File not found: " + ("null" if filePath is None else filePath)) + ". Unable to load data from disk."))
        return None

    def deleteFile(self,key,localPath = ""):
        if (localPath is None):
            localPath = ""
        if sys_FileSystem.exists(((("null" if localPath is None else localPath) + ("null" if key is None else key)) + HxOverrides.stringOrNull(self._extension))):
            sys_FileSystem.deleteFile(((("null" if localPath is None else localPath) + ("null" if key is None else key)) + HxOverrides.stringOrNull(self._extension)))

    def save(self,key,value):
        filePath = ((HxOverrides.stringOrNull(self._localStoragePath) + ("null" if key is None else key)) + HxOverrides.stringOrNull(self._extension))
        if (value is not None):
            sys_io_File.saveContent(filePath,value)
            _this = self._keys
            _this.append(key)
        else:
            self.deleteFile(key,self._localStoragePath)
            python_internal_ArrayImpl.remove(self._keys,key)

    def load(self,key):
        result = self.dataFromDisk(key,self._localStoragePath)
        return result

    def clear(self):
        _g = 0
        _g1 = self._keys
        while (_g < len(_g1)):
            key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            self.deleteFile(key,self._localStoragePath)
        self._keys = list()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._localStoragePath = None
        _hx_o._extension = None
        _hx_o._keys = None
apptimize_support_persistence_ABTPIDiskStorage._hx_class = apptimize_support_persistence_ABTPIDiskStorage
_hx_classes["apptimize.support.persistence.ABTPIDiskStorage"] = apptimize_support_persistence_ABTPIDiskStorage


class apptimize_support_persistence_ABTPersistence:
    _hx_class_name = "apptimize.support.persistence.ABTPersistence"
    __slots__ = ()
    _hx_statics = ["kMetadataKey", "kAnonymousGuidKey", "kInternalPropertiesKey", "kResultLogsKey", "kResultPostsKey", "kApptimizeVersionKey", "kPostManagementKey", "_persistentInterface", "getPersistentInterface", "clear", "saveString", "saveObject", "loadString", "loadObject"]
    _persistentInterface = None

    @staticmethod
    def getPersistentInterface():
        if (apptimize_support_persistence_ABTPersistence._persistentInterface is None):
            apptimize_support_persistence_ABTPersistence._persistentInterface = apptimize_support_persistence_ABTPIDiskStorage()
        return apptimize_support_persistence_ABTPersistence._persistentInterface

    @staticmethod
    def clear():
        apptimize_util_ABTDataLock.lock(apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY)
        apptimize_support_persistence_ABTPersistence.getPersistentInterface().clear()
        apptimize_util_ABTDataLock.release(apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY)

    @staticmethod
    def saveString(key,value):
        apptimize_util_ABTDataLock.lock(apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY)
        apptimize_support_persistence_ABTPersistence.getPersistentInterface().save(key,value)
        apptimize_util_ABTDataLock.release(apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY)

    @staticmethod
    def saveObject(key,value):
        serializer = haxe_Serializer()
        serializer.serialize(value)
        serializer.serialize(Apptimize.getApptimizeSDKVersion())
        apptimize_support_persistence_ABTPersistence.saveString(key,serializer.toString())

    @staticmethod
    def loadString(key):
        result = None
        apptimize_util_ABTDataLock.lock(apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY)
        result = apptimize_support_persistence_ABTPersistence.getPersistentInterface().load(key)
        apptimize_util_ABTDataLock.release(apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY)
        return result

    @staticmethod
    def loadObject(key):
        result = None
        serializedObject = apptimize_support_persistence_ABTPersistence.loadString(key)
        if (serializedObject is not None):
            try:
                unserializer = haxe_Unserializer(serializedObject)
                result = unserializer.unserialize()
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                unknown = _hx_e1
                apptimize_ABTLogger.e(((("Error deserializing \"" + ("null" if key is None else key)) + "\" from persistent storage. Error: ") + Std.string(unknown)))
                return None
        return result
apptimize_support_persistence_ABTPersistence._hx_class = apptimize_support_persistence_ABTPersistence
_hx_classes["apptimize.support.persistence.ABTPersistence"] = apptimize_support_persistence_ABTPersistence


class apptimize_support_properties_ABTProperties:
    _hx_class_name = "apptimize.support.properties.ABTProperties"
    __slots__ = ("availableProperties",)
    _hx_fields = ["availableProperties"]
    _hx_methods = ["setPropertyDefaults", "isPropertyAvailable", "valueForProperty", "setProperty", "setProperties"]

    def __init__(self):
        self.availableProperties = haxe_ds_StringMap()
        self.availableProperties = haxe_ds_StringMap()
        self.setPropertyDefaults()

    def setPropertyDefaults(self):
        pass

    def isPropertyAvailable(self,propertyName):
        return (self.availableProperties.h.get(propertyName,None) is not None)

    def valueForProperty(self,propertyName):
        return self.availableProperties.h.get(propertyName,None)

    def setProperty(self,key,value):
        self.availableProperties.h[key] = value

    def setProperties(self,stringMap):
        key = stringMap.keys()
        while key.hasNext():
            key1 = key.next()
            self.setProperty(key1,stringMap.h.get(key1,None))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.availableProperties = None
apptimize_support_properties_ABTProperties._hx_class = apptimize_support_properties_ABTProperties
_hx_classes["apptimize.support.properties.ABTProperties"] = apptimize_support_properties_ABTProperties


class apptimize_support_properties_ABTApplicationProperties(apptimize_support_properties_ABTProperties):
    _hx_class_name = "apptimize.support.properties.ABTApplicationProperties"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setPropertyDefaults", "addJSONProperties"]
    _hx_statics = ["_instance", "_sigilForApplicationNamespace", "sharedInstance"]
    _hx_interfaces = []
    _hx_super = apptimize_support_properties_ABTProperties


    def __init__(self):
        super().__init__()

    def setPropertyDefaults(self):
        this1 = self.availableProperties
        v = Apptimize.getApptimizeSDKVersion()
        this1.h["apptimize_version"] = v
        this2 = self.availableProperties
        v1 = Apptimize.getApptimizeSDKPlatform()
        this2.h["apptimize_platform"] = v1
        self.availableProperties.h["app_version"] = ""
        self.availableProperties.h["app_name"] = ""

    def addJSONProperties(self,jsonProperties):
        key = self.availableProperties.keys()
        while key.hasNext():
            key1 = key.next()
            k = (HxOverrides.stringOrNull(apptimize_support_properties_ABTApplicationProperties._sigilForApplicationNamespace) + ("null" if key1 is None else key1))
            v = self.availableProperties.h.get(key1,None)
            jsonProperties.h[k] = v
    _instance = None

    @staticmethod
    def sharedInstance():
        if (apptimize_support_properties_ABTApplicationProperties._instance is None):
            apptimize_support_properties_ABTApplicationProperties._instance = apptimize_support_properties_ABTApplicationProperties()
        return apptimize_support_properties_ABTApplicationProperties._instance

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_support_properties_ABTApplicationProperties._hx_class = apptimize_support_properties_ABTApplicationProperties
_hx_classes["apptimize.support.properties.ABTApplicationProperties"] = apptimize_support_properties_ABTApplicationProperties


class apptimize_support_properties_ABTConfigProperties(apptimize_support_properties_ABTProperties):
    _hx_class_name = "apptimize.support.properties.ABTConfigProperties"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setPropertyDefaults"]
    _hx_statics = ["META_DATA_URL_KEY", "META_DATA_URL_LL_KEY", "META_DATA_URL_HL_KEY", "LOG_LEVEL", "FOREGROUND_PERIOD_MS_KEY", "RESULT_POST_DELAY_MS_KEY", "THREADING_ENABLED_KEY", "ALTERATION_CACHE_SIZE", "RESULTS_CACHE_SIZE", "MAXIMUM_RESULT_ENTRIES_KEY", "MAXIMUM_PENDING_RESULTS_KEY", "METADATA_POLLING_INTERVAL_MS", "METADATA_POLLING_BACKGROUND_INTERVAL_MS", "EXCEPTIONS_ENABLED_KEY", "MAXIMUM_RESULT_POST_FAILURE_KEY", "MAXIMUM_RESULT_POST_SENDER_TIMEOUT_MS_KEY", "_instance", "sharedInstance"]
    _hx_interfaces = []
    _hx_super = apptimize_support_properties_ABTProperties


    def __init__(self):
        super().__init__()

    def setPropertyDefaults(self):
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.META_DATA_URL_LL_KEY] = "https://md-ll.apptimize.com/api/metadata/v4/"
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.META_DATA_URL_HL_KEY] = "https://md-hl.apptimize.com/api/metadata/v4/"
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.META_DATA_URL_KEY] = None
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.LOG_LEVEL] = "LOG_LEVEL_VERBOSE"
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.FOREGROUND_PERIOD_MS_KEY] = 10000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.RESULT_POST_DELAY_MS_KEY] = 60000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY] = False
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.ALTERATION_CACHE_SIZE] = 10
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.RESULTS_CACHE_SIZE] = 10
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_ENTRIES_KEY] = 1000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.MAXIMUM_PENDING_RESULTS_KEY] = 1000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_INTERVAL_MS] = 60000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_POST_FAILURE_KEY] = 3
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_POST_SENDER_TIMEOUT_MS_KEY] = 3000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_BACKGROUND_INTERVAL_MS] = 86400000
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.EXCEPTIONS_ENABLED_KEY] = True
        self.availableProperties.h[apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY] = True
    _instance = None

    @staticmethod
    def sharedInstance():
        if (apptimize_support_properties_ABTConfigProperties._instance is None):
            apptimize_support_properties_ABTConfigProperties._instance = apptimize_support_properties_ABTConfigProperties()
        return apptimize_support_properties_ABTConfigProperties._instance

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_support_properties_ABTConfigProperties._hx_class = apptimize_support_properties_ABTConfigProperties
_hx_classes["apptimize.support.properties.ABTConfigProperties"] = apptimize_support_properties_ABTConfigProperties

class apptimize_support_properties_CustomPropertyNamespace(Enum):
    __slots__ = ()
    _hx_class_name = "apptimize.support.properties.CustomPropertyNamespace"
    _hx_constructs = ["UserAttribute", "ApptimizeLocal", "ApptimizeInternal"]
apptimize_support_properties_CustomPropertyNamespace.UserAttribute = apptimize_support_properties_CustomPropertyNamespace("UserAttribute", 0, list())
apptimize_support_properties_CustomPropertyNamespace.ApptimizeLocal = apptimize_support_properties_CustomPropertyNamespace("ApptimizeLocal", 1, list())
apptimize_support_properties_CustomPropertyNamespace.ApptimizeInternal = apptimize_support_properties_CustomPropertyNamespace("ApptimizeInternal", 2, list())
apptimize_support_properties_CustomPropertyNamespace._hx_class = apptimize_support_properties_CustomPropertyNamespace
_hx_classes["apptimize.support.properties.CustomPropertyNamespace"] = apptimize_support_properties_CustomPropertyNamespace


class apptimize_support_properties_ABTCustomProperties(apptimize_support_properties_ABTProperties):
    _hx_class_name = "apptimize.support.properties.ABTCustomProperties"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setPropertyDefaults", "setProperty", "setPropertyForNamespace", "sigilForNamespace", "isNamespacedPropertyAvailable", "valueForNamespacedProperty", "addJSONProperties"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = apptimize_support_properties_ABTProperties


    def __init__(self):
        super().__init__()

    def setPropertyDefaults(self):
        pass

    def setProperty(self,key,value):
        self.setPropertyForNamespace(key,value,apptimize_support_properties_CustomPropertyNamespace.UserAttribute)

    def setPropertyForNamespace(self,key,value,namespace):
        this1 = self.availableProperties
        key1 = (HxOverrides.stringOrNull(self.sigilForNamespace(namespace)) + ("null" if key is None else key))
        this1.h[key1] = value

    def sigilForNamespace(self,namespace):
        namespace1 = namespace.index
        if (namespace1 == 0):
            return "%"
        elif (namespace1 == 1):
            return "l"
        elif (namespace1 == 2):
            return "^"
        else:
            pass

    def isNamespacedPropertyAvailable(self,propertyName,namespace):
        this1 = self.availableProperties
        key = (HxOverrides.stringOrNull(self.sigilForNamespace(namespace)) + ("null" if propertyName is None else propertyName))
        return (this1.h.get(key,None) is not None)

    def valueForNamespacedProperty(self,propertyName,namespace):
        this1 = self.availableProperties
        key = (HxOverrides.stringOrNull(self.sigilForNamespace(namespace)) + ("null" if propertyName is None else propertyName))
        return this1.h.get(key,None)

    def addJSONProperties(self,jsonProperties):
        key = self.availableProperties.keys()
        while key.hasNext():
            key1 = key.next()
            if ((("" if ((0 >= len(key1))) else key1[0])) != self.sigilForNamespace(apptimize_support_properties_CustomPropertyNamespace.ApptimizeLocal)):
                v = self.availableProperties.h.get(key1,None)
                jsonProperties.h[key1] = v

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_support_properties_ABTCustomProperties._hx_class = apptimize_support_properties_ABTCustomProperties
_hx_classes["apptimize.support.properties.ABTCustomProperties"] = apptimize_support_properties_ABTCustomProperties


class apptimize_support_properties_ABTInternalProperties(apptimize_support_properties_ABTCustomProperties):
    _hx_class_name = "apptimize.support.properties.ABTInternalProperties"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isPropertyAvailable", "valueForProperty", "setProperty", "_loadProperties", "_saveProperties", "setPropertyForNamespace", "isNamespacedPropertyAvailable", "valueForNamespacedProperty"]
    _hx_statics = ["_instance", "sharedInstance"]
    _hx_interfaces = []
    _hx_super = apptimize_support_properties_ABTCustomProperties


    def __init__(self):
        super().__init__()

    def isPropertyAvailable(self,propertyName):
        self._loadProperties()
        return super().isPropertyAvailable(propertyName)

    def valueForProperty(self,propertyName):
        self._loadProperties()
        return self.availableProperties.h.get(propertyName,None)

    def setProperty(self,key,value):
        self.setPropertyForNamespace(key,value,apptimize_support_properties_CustomPropertyNamespace.ApptimizeInternal)

    def _loadProperties(self):
        self.availableProperties = apptimize_support_persistence_ABTPersistence.loadObject(apptimize_support_persistence_ABTPersistence.kInternalPropertiesKey)
        if (self.availableProperties is None):
            self.availableProperties = haxe_ds_StringMap()

    def _saveProperties(self):
        apptimize_support_persistence_ABTPersistence.saveObject(apptimize_support_persistence_ABTPersistence.kInternalPropertiesKey,self.availableProperties)

    def setPropertyForNamespace(self,key,value,namespace):
        self._loadProperties()
        super().setPropertyForNamespace(key,value,namespace)
        self._saveProperties()

    def isNamespacedPropertyAvailable(self,propertyName,namespace):
        self._loadProperties()
        return super().isNamespacedPropertyAvailable(propertyName,namespace)

    def valueForNamespacedProperty(self,propertyName,namespace):
        self._loadProperties()
        return super().valueForNamespacedProperty(propertyName,namespace)
    _instance = None

    @staticmethod
    def sharedInstance():
        if (apptimize_support_properties_ABTInternalProperties._instance is None):
            apptimize_support_properties_ABTInternalProperties._instance = apptimize_support_properties_ABTInternalProperties()
        return apptimize_support_properties_ABTInternalProperties._instance

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_support_properties_ABTInternalProperties._hx_class = apptimize_support_properties_ABTInternalProperties
_hx_classes["apptimize.support.properties.ABTInternalProperties"] = apptimize_support_properties_ABTInternalProperties


class apptimize_util_PlatformLock:
    _hx_class_name = "apptimize.util.PlatformLock"
    __slots__ = ()
    _hx_methods = ["acquire", "release"]
apptimize_util_PlatformLock._hx_class = apptimize_util_PlatformLock
_hx_classes["apptimize.util.PlatformLock"] = apptimize_util_PlatformLock


class apptimize_util_PythonPlatformLock:
    _hx_class_name = "apptimize.util.PythonPlatformLock"
    __slots__ = ("_lock",)
    _hx_fields = ["_lock"]
    _hx_methods = ["acquire", "release"]
    _hx_interfaces = [apptimize_util_PlatformLock]

    def __init__(self):
        self._lock = python_lib_threading_RLock()

    def acquire(self):
        if (self._lock is None):
            self._lock = python_lib_threading_RLock()
        return self._lock.acquire()

    def release(self):
        if (self._lock is not None):
            self._lock.release()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._lock = None
apptimize_util_PythonPlatformLock._hx_class = apptimize_util_PythonPlatformLock
_hx_classes["apptimize.util.PythonPlatformLock"] = apptimize_util_PythonPlatformLock


class apptimize_util_DefaultPlatformLock:
    _hx_class_name = "apptimize.util.DefaultPlatformLock"
    __slots__ = ()
    _hx_methods = ["acquire", "release"]
    _hx_interfaces = [apptimize_util_PlatformLock]

    def __init__(self):
        pass

    def acquire(self):
        return True

    def release(self):
        return

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
apptimize_util_DefaultPlatformLock._hx_class = apptimize_util_DefaultPlatformLock
_hx_classes["apptimize.util.DefaultPlatformLock"] = apptimize_util_DefaultPlatformLock


class apptimize_util_ABTDataLock:
    _hx_class_name = "apptimize.util.ABTDataLock"
    __slots__ = ()
    _hx_statics = ["SYSTEM_DATA_LOCK_KEY", "METADATA_LOCK_KEY", "CHECK_TIME_LOCK_KEY", "_lockMap", "getNewLock", "lock", "release"]

    @staticmethod
    def getNewLock(lockName):
        if (apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY) != True):
            return apptimize_util_DefaultPlatformLock()
        return apptimize_util_PythonPlatformLock()

    @staticmethod
    def lock(id):
        platform_lock = None
        if (id in apptimize_util_ABTDataLock._lockMap.h):
            platform_lock = apptimize_util_ABTDataLock._lockMap.h.get(id,None)
        else:
            platform_lock = apptimize_util_ABTDataLock.getNewLock(id)
            apptimize_util_ABTDataLock._lockMap.h[id] = platform_lock
        return platform_lock.acquire()

    @staticmethod
    def release(id):
        if (id in apptimize_util_ABTDataLock._lockMap.h):
            apptimize_util_ABTDataLock._lockMap.h.get(id,None).release()
apptimize_util_ABTDataLock._hx_class = apptimize_util_ABTDataLock
_hx_classes["apptimize.util.ABTDataLock"] = apptimize_util_ABTDataLock


class apptimize_util_ABTException:
    _hx_class_name = "apptimize.util.ABTException"
    __slots__ = ()
    _hx_statics = ["throwException"]

    @staticmethod
    def throwException(message):
        if apptimize_support_properties_ABTConfigProperties.sharedInstance().valueForProperty(apptimize_support_properties_ABTConfigProperties.EXCEPTIONS_ENABLED_KEY):
            raise _HxException(message)
apptimize_util_ABTException._hx_class = apptimize_util_ABTException
_hx_classes["apptimize.util.ABTException"] = apptimize_util_ABTException


class apptimize_util_ABTHash:
    _hx_class_name = "apptimize.util.ABTHash"
    __slots__ = ("bytesBuffer",)
    _hx_fields = ["bytesBuffer"]
    _hx_methods = ["push", "hash"]

    def __init__(self):
        self.bytesBuffer = haxe_io_BytesBuffer()

    def push(self,obj):
        _this = self.bytesBuffer
        _hx_len = obj.length
        if ((_hx_len < 0) or ((_hx_len > obj.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        b1 = _this.b
        b2 = obj.b
        _g1 = 0
        _g = _hx_len
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            _this1 = _this.b
            _this1.append(b2[i])

    def hash(self):
        return haxe_crypto_Sha1.make(self.bytesBuffer.getBytes()).toString()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.bytesBuffer = None
apptimize_util_ABTHash._hx_class = apptimize_util_ABTHash
_hx_classes["apptimize.util.ABTHash"] = apptimize_util_ABTHash


class apptimize_util_ABTInt64Utils:
    _hx_class_name = "apptimize.util.ABTInt64Utils"
    __slots__ = ()
    _hx_statics = ["toPreprocessedString", "_serializeInt64", "_deserializeInt64"]

    @staticmethod
    def toPreprocessedString(number):
        return (("wideInt_" + HxOverrides.stringOrNull(haxe__Int64_Int64_Impl_.toString(number))) + "_wideInt")

    @staticmethod
    def _serializeInt64(value,s):
        s.serialize(value.high)
        s.serialize(value.low)

    @staticmethod
    def _deserializeInt64(u):
        this1 = haxe__Int64____Int64(u.unserialize(),u.unserialize())
        return this1
apptimize_util_ABTInt64Utils._hx_class = apptimize_util_ABTInt64Utils
_hx_classes["apptimize.util.ABTInt64Utils"] = apptimize_util_ABTInt64Utils


class apptimize_util_ABTJSONUtils:
    _hx_class_name = "apptimize.util.ABTJSONUtils"
    __slots__ = ()
    _hx_statics = ["stringify"]

    @staticmethod
    def stringify(json):
        jsonString = haxe_format_JsonPrinter.print(json,None,None)
        jsonString = StringTools.replace(jsonString,"\"wideInt_","")
        jsonString = StringTools.replace(jsonString,"_wideInt\"","")
        return jsonString
apptimize_util_ABTJSONUtils._hx_class = apptimize_util_ABTJSONUtils
_hx_classes["apptimize.util.ABTJSONUtils"] = apptimize_util_ABTJSONUtils


class apptimize_util_ABTLRUCache:
    _hx_class_name = "apptimize.util.ABTLRUCache"
    __slots__ = ("_cacheSize", "_list", "_map")
    _hx_fields = ["_cacheSize", "_list", "_map"]
    _hx_methods = ["clear", "hasKey", "getValue", "remove", "insert"]

    def __init__(self,cacheSize):
        self._map = None
        self._list = None
        self._cacheSize = cacheSize
        self.clear()

    def clear(self,callback = None):
        if (callback is not None):
            _g = 0
            _g1 = self._list
            while (_g < len(_g1)):
                id = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                callback(self._map.h.get(id,None))
        self._list = list()
        self._map = haxe_ds_StringMap()

    def hasKey(self,key):
        return (self._map.h.get(key,None) is not None)

    def getValue(self,key):
        if self.hasKey(key):
            return self._map.h.get(key,None)
        return None

    def remove(self,key,callback = None):
        if (not self.hasKey(key)):
            return
        if (callback is not None):
            callback(self._map.h.get(key,None))
        python_internal_ArrayImpl.remove(self._list,key)
        self._map.remove(key)

    def insert(self,key,value,callback = None):
        if self.hasKey(key):
            self._map.h[key] = value
            python_internal_ArrayImpl.remove(self._list,key)
            _this = self._list
            _this.append(key)
        else:
            self._map.h[key] = value
            _this1 = self._list
            _this1.append(key)
            if (len(self._list) > self._cacheSize):
                _this2 = self._list
                id = (None if ((len(_this2) == 0)) else _this2.pop(0))
                if (callback is not None):
                    callback(self._map.h.get(id,None))
                self._map.remove(id)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._cacheSize = None
        _hx_o._list = None
        _hx_o._map = None
apptimize_util_ABTLRUCache._hx_class = apptimize_util_ABTLRUCache
_hx_classes["apptimize.util.ABTLRUCache"] = apptimize_util_ABTLRUCache


class apptimize_util_ABTUtilDictionary:
    _hx_class_name = "apptimize.util.ABTUtilDictionary"
    __slots__ = ()
    _hx_statics = ["dynamicToNativeDictionary", "stringMapToNativeDictionary", "nativeObjectToStringMap", "nativeDictionaryToStringMap", "dynamicObjectToStringMap", "dynamicMapToStringMap"]

    @staticmethod
    def dynamicToNativeDictionary(dynamicMap):
        pythonDict = dict()
        _hx_dict = dynamicMap
        if (_hx_dict is not None):
            _g = 0
            _g1 = python_Boot.fields(_hx_dict)
            while (_g < len(_g1)):
                key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                k = key
                pythonDict[k] = Reflect.field(_hx_dict,key)
        return pythonDict

    @staticmethod
    def stringMapToNativeDictionary(stringMap):
        pythonDict = dict()
        if (stringMap is not None):
            key = stringMap.keys()
            while key.hasNext():
                key1 = key.next()
                k = key1
                pythonDict[k] = stringMap.h.get(key1,None)
        return pythonDict

    @staticmethod
    def nativeObjectToStringMap(nativeMap):
        if (Type.getClass(nativeMap) == haxe_ds_StringMap):
            return apptimize_util_ABTUtilDictionary.dynamicMapToStringMap(nativeMap)
        if (Type.typeof(nativeMap) == ValueType.TObject):
            return apptimize_util_ABTUtilDictionary.dynamicObjectToStringMap(nativeMap)
        return apptimize_util_ABTUtilDictionary.nativeDictionaryToStringMap(nativeMap)

    @staticmethod
    def nativeDictionaryToStringMap(nativeMap):
        pythonDict = nativeMap
        _hx_map = haxe_ds_StringMap()
        if (pythonDict is not None):
            key = python_HaxeIterator(iter(pythonDict.keys()))
            while key.hasNext():
                key1 = key.next()
                value = pythonDict.get(key1)
                _hx_map.h[key1] = value
        return _hx_map

    @staticmethod
    def dynamicObjectToStringMap(object):
        _hx_map = haxe_ds_StringMap()
        fields = python_Boot.fields(object)
        _g = 0
        while (_g < len(fields)):
            field = (fields[_g] if _g >= 0 and _g < len(fields) else None)
            _g = (_g + 1)
            value = Reflect.getProperty(object,field)
            _hx_map.h[field] = value
        return _hx_map

    @staticmethod
    def dynamicMapToStringMap(_hx_map):
        stringMap = haxe_ds_StringMap()
        _hx_dict = _hx_map
        _g = 0
        _g1 = python_Boot.fields(_hx_dict)
        while (_g < len(_g1)):
            key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            value = Reflect.field(_hx_dict,key)
            stringMap.h[key] = value
        return stringMap
apptimize_util_ABTUtilDictionary._hx_class = apptimize_util_ABTUtilDictionary
_hx_classes["apptimize.util.ABTUtilDictionary"] = apptimize_util_ABTUtilDictionary


class apptimize_util_ABTUtilGzip:
    _hx_class_name = "apptimize.util.ABTUtilGzip"
    __slots__ = ()
    _hx_statics = ["jsonSignatureLength", "decompress"]

    @staticmethod
    def jsonSignatureLength(_hx_bytes):
        b = haxe_io_Bytes.ofData(_hx_bytes)
        _hx_len = ((b.b[0] << 8) | b.b[1])
        return _hx_len

    @staticmethod
    def decompress(_hx_bytes):
        bds = haxe_io_Bytes.ofData(_hx_bytes)
        sys_io_File.saveBytes("data/apptimize/raw.data",bds)
        _hx_len = apptimize_util_ABTUtilGzip.jsonSignatureLength(_hx_bytes)
        dataLength = bds.length
        sigLength = (_hx_len + 2)
        zippedLength = (dataLength - sigLength)
        orig = haxe_io_Bytes.ofData(_hx_bytes)
        bd = orig.sub(sigLength,zippedLength)
        sys_io_File.saveBytes("data/apptimize/tmp.zip",bd)
        output = format_gz_Reader(sys_io_File.read("data/apptimize/tmp.zip"))
        responseOut = output.read()
        return responseOut.data
apptimize_util_ABTUtilGzip._hx_class = apptimize_util_ABTUtilGzip
_hx_classes["apptimize.util.ABTUtilGzip"] = apptimize_util_ABTUtilGzip


class format_gz_Reader:
    _hx_class_name = "format.gz.Reader"
    __slots__ = ("i",)
    _hx_fields = ["i"]
    _hx_methods = ["read", "readHeader", "readData"]

    def __init__(self,i):
        self.i = i

    def read(self):
        h = self.readHeader()
        o = haxe_io_BytesOutput()
        self.readData(o)
        return _hx_AnonObject({'file': h.fileName, 'data': o.getBytes()})

    def readHeader(self):
        if ((self.i.readByte() != 31) or ((self.i.readByte() != 139))):
            raise _HxException("Invalid GZ header")
        if (self.i.readByte() != 8):
            raise _HxException("Invalid compression method")
        flags = self.i.readByte()
        mtime = self.i.read(4)
        xflags = self.i.readByte()
        os = self.i.readByte()
        fname = None
        comments = None
        xdata = None
        if (((flags & 4)) != 0):
            xlen = self.i.readUInt16()
            xdata = self.i.read(xlen)
        if (((flags & 8)) != 0):
            fname = self.i.readUntil(0)
        if (((flags & 16)) != 0):
            comments = self.i.readUntil(0)
        if (((flags & 2)) != 0):
            hcrc = self.i.readUInt16()
        return _hx_AnonObject({'fileName': fname, 'comments': comments, 'extraData': xdata})

    def readData(self,o,bufsize = None):
        if (bufsize is None):
            bufsize = 65536
        buf = haxe_io_Bytes.alloc(bufsize)
        tsize = 0
        inflate = haxe_zip_InflateImpl(self.i,False,False)
        while True:
            _hx_len = inflate.readBytes(buf,0,bufsize)
            o.writeFullBytes(buf,0,_hx_len)
            if (_hx_len < bufsize):
                break
            tsize = (tsize + _hx_len)
        return tsize

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.i = None
format_gz_Reader._hx_class = format_gz_Reader
_hx_classes["format.gz.Reader"] = format_gz_Reader


class haxe__EntryPoint_Lock:
    _hx_class_name = "haxe._EntryPoint.Lock"
    __slots__ = ()

    def __init__(self):
        pass
haxe__EntryPoint_Lock._hx_class = haxe__EntryPoint_Lock
_hx_classes["haxe._EntryPoint.Lock"] = haxe__EntryPoint_Lock


class haxe__EntryPoint_Mutex:
    _hx_class_name = "haxe._EntryPoint.Mutex"
    __slots__ = ()

    def __init__(self):
        pass
haxe__EntryPoint_Mutex._hx_class = haxe__EntryPoint_Mutex
_hx_classes["haxe._EntryPoint.Mutex"] = haxe__EntryPoint_Mutex


class haxe_EntryPoint:
    _hx_class_name = "haxe.EntryPoint"
    __slots__ = ()
    _hx_statics = ["sleepLock", "mutex", "pending", "threadCount", "processEvents", "run"]

    @staticmethod
    def processEvents():
        while True:
            _this = haxe_EntryPoint.mutex
            _this1 = haxe_EntryPoint.pending
            f = (None if ((len(_this1) == 0)) else _this1.pop(0))
            _this2 = haxe_EntryPoint.mutex
            if (f is None):
                break
            f()
        if ((haxe_MainLoop.pending is None) and ((haxe_EntryPoint.threadCount == 0))):
            return -1
        return haxe_MainLoop.tick()

    @staticmethod
    def run():
        while True:
            nextTick = haxe_EntryPoint.processEvents()
            if (nextTick < 0):
                break
            if (nextTick > 0):
                _this = haxe_EntryPoint.sleepLock
haxe_EntryPoint._hx_class = haxe_EntryPoint
_hx_classes["haxe.EntryPoint"] = haxe_EntryPoint


class haxe__Int32_Int32_Impl_:
    _hx_class_name = "haxe._Int32.Int32_Impl_"
    __slots__ = ()
    _hx_statics = ["ucompare"]

    @staticmethod
    def ucompare(a,b):
        if (a < 0):
            if (b < 0):
                return (((~b - ~a) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            else:
                return 1
        if (b < 0):
            return -1
        else:
            return (((a - b) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
haxe__Int32_Int32_Impl_._hx_class = haxe__Int32_Int32_Impl_
_hx_classes["haxe._Int32.Int32_Impl_"] = haxe__Int32_Int32_Impl_


class haxe__Int64_Int64_Impl_:
    _hx_class_name = "haxe._Int64.Int64_Impl_"
    __slots__ = ()
    _hx_statics = ["toString", "divMod"]
    high = None
    low = None

    @staticmethod
    def toString(this1):
        i = this1
        this2 = haxe__Int64____Int64(0,0)
        b = this2
        if ((i.high == b.high) and (i.low == b.low)):
            return "0"
        _hx_str = ""
        neg = False
        if (i.high < 0):
            neg = True
        this3 = haxe__Int64____Int64(0,10)
        ten = this3
        while True:
            this4 = haxe__Int64____Int64(0,0)
            b1 = this4
            if (not (((i.high != b1.high) or (i.low != b1.low)))):
                break
            r = haxe__Int64_Int64_Impl_.divMod(i,ten)
            if (r.modulus.high < 0):
                x = r.modulus
                high = ~x.high
                low = -x.low
                if (low == 0):
                    ret = high
                    high = (high + 1)
                    high = ((high + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                this5 = haxe__Int64____Int64(high,low)
                _hx_str = (Std.string(this5.low) + ("null" if _hx_str is None else _hx_str))
                x1 = r.quotient
                high1 = ~x1.high
                low1 = -x1.low
                if (low1 == 0):
                    ret1 = high1
                    high1 = (high1 + 1)
                    high1 = ((high1 + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                this6 = haxe__Int64____Int64(high1,low1)
                i = this6
            else:
                _hx_str = (Std.string(r.modulus.low) + ("null" if _hx_str is None else _hx_str))
                i = r.quotient
        if neg:
            _hx_str = ("-" + ("null" if _hx_str is None else _hx_str))
        return _hx_str

    @staticmethod
    def divMod(dividend,divisor):
        if (divisor.high == 0):
            _g = divisor.low
            _g1 = _g
            if (_g1 == 0):
                raise _HxException("divide by zero")
            elif (_g1 == 1):
                this1 = haxe__Int64____Int64(dividend.high,dividend.low)
                this2 = haxe__Int64____Int64(0,0)
                return _hx_AnonObject({'quotient': this1, 'modulus': this2})
            else:
                pass
        divSign = ((dividend.high < 0) != (divisor.high < 0))
        modulus = None
        if (dividend.high < 0):
            high = ~dividend.high
            low = -dividend.low
            if (low == 0):
                ret = high
                high = (high + 1)
                high = ((high + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            this3 = haxe__Int64____Int64(high,low)
            modulus = this3
        else:
            this4 = haxe__Int64____Int64(dividend.high,dividend.low)
            modulus = this4
        if (divisor.high < 0):
            high1 = ~divisor.high
            low1 = -divisor.low
            if (low1 == 0):
                ret1 = high1
                high1 = (high1 + 1)
                high1 = ((high1 + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            this5 = haxe__Int64____Int64(high1,low1)
            divisor = this5
        else:
            divisor = divisor
        this6 = haxe__Int64____Int64(0,0)
        quotient = this6
        this7 = haxe__Int64____Int64(0,1)
        mask = this7
        while (not ((divisor.high < 0))):
            v = haxe__Int32_Int32_Impl_.ucompare(divisor.high,modulus.high)
            cmp = (v if ((v != 0)) else haxe__Int32_Int32_Impl_.ucompare(divisor.low,modulus.low))
            b = 1
            b = (b & 63)
            if (b == 0):
                this8 = haxe__Int64____Int64(divisor.high,divisor.low)
                divisor = this8
            elif (b < 32):
                this9 = haxe__Int64____Int64((((((divisor.high << b)) + (2 ** 31)) % (2 ** 32) - (2 ** 31)) | HxOverrides.rshift(divisor.low, ((32 - b)))),((((divisor.low << b)) + (2 ** 31)) % (2 ** 32) - (2 ** 31)))
                divisor = this9
            else:
                this10 = haxe__Int64____Int64(((((divisor.low << (b - 32))) + (2 ** 31)) % (2 ** 32) - (2 ** 31)),0)
                divisor = this10
            b1 = 1
            b1 = (b1 & 63)
            if (b1 == 0):
                this11 = haxe__Int64____Int64(mask.high,mask.low)
                mask = this11
            elif (b1 < 32):
                this12 = haxe__Int64____Int64((((((mask.high << b1)) + (2 ** 31)) % (2 ** 32) - (2 ** 31)) | HxOverrides.rshift(mask.low, ((32 - b1)))),((((mask.low << b1)) + (2 ** 31)) % (2 ** 32) - (2 ** 31)))
                mask = this12
            else:
                this13 = haxe__Int64____Int64(((((mask.low << (b1 - 32))) + (2 ** 31)) % (2 ** 32) - (2 ** 31)),0)
                mask = this13
            if (cmp >= 0):
                break
        while True:
            this14 = haxe__Int64____Int64(0,0)
            b2 = this14
            if (not (((mask.high != b2.high) or (mask.low != b2.low)))):
                break
            v1 = haxe__Int32_Int32_Impl_.ucompare(modulus.high,divisor.high)
            if (((v1 if ((v1 != 0)) else haxe__Int32_Int32_Impl_.ucompare(modulus.low,divisor.low))) >= 0):
                this15 = haxe__Int64____Int64((quotient.high | mask.high),(quotient.low | mask.low))
                quotient = this15
                high2 = (((modulus.high - divisor.high) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                low2 = (((modulus.low - divisor.low) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                if (haxe__Int32_Int32_Impl_.ucompare(modulus.low,divisor.low) < 0):
                    ret2 = high2
                    high2 = (high2 - 1)
                    high2 = ((high2 + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                this16 = haxe__Int64____Int64(high2,low2)
                modulus = this16
            b3 = 1
            b3 = (b3 & 63)
            if (b3 == 0):
                this17 = haxe__Int64____Int64(mask.high,mask.low)
                mask = this17
            elif (b3 < 32):
                this18 = haxe__Int64____Int64(HxOverrides.rshift(mask.high, b3),(((((mask.high << (32 - b3))) + (2 ** 31)) % (2 ** 32) - (2 ** 31)) | HxOverrides.rshift(mask.low, b3)))
                mask = this18
            else:
                this19 = haxe__Int64____Int64(0,HxOverrides.rshift(mask.high, ((b3 - 32))))
                mask = this19
            b4 = 1
            b4 = (b4 & 63)
            if (b4 == 0):
                this20 = haxe__Int64____Int64(divisor.high,divisor.low)
                divisor = this20
            elif (b4 < 32):
                this21 = haxe__Int64____Int64(HxOverrides.rshift(divisor.high, b4),(((((divisor.high << (32 - b4))) + (2 ** 31)) % (2 ** 32) - (2 ** 31)) | HxOverrides.rshift(divisor.low, b4)))
                divisor = this21
            else:
                this22 = haxe__Int64____Int64(0,HxOverrides.rshift(divisor.high, ((b4 - 32))))
                divisor = this22
        if divSign:
            high3 = ~quotient.high
            low3 = -quotient.low
            if (low3 == 0):
                ret3 = high3
                high3 = (high3 + 1)
                high3 = ((high3 + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            this23 = haxe__Int64____Int64(high3,low3)
            quotient = this23
        if (dividend.high < 0):
            high4 = ~modulus.high
            low4 = -modulus.low
            if (low4 == 0):
                ret4 = high4
                high4 = (high4 + 1)
                high4 = ((high4 + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            this24 = haxe__Int64____Int64(high4,low4)
            modulus = this24
        return _hx_AnonObject({'quotient': quotient, 'modulus': modulus})
haxe__Int64_Int64_Impl_._hx_class = haxe__Int64_Int64_Impl_
_hx_classes["haxe._Int64.Int64_Impl_"] = haxe__Int64_Int64_Impl_


class haxe_Int64Helper:
    _hx_class_name = "haxe.Int64Helper"
    __slots__ = ()
    _hx_statics = ["fromFloat"]

    @staticmethod
    def fromFloat(f):
        if (python_lib_Math.isnan(f) or (not ((((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))))):
            raise _HxException("Number is NaN or Infinite")
        noFractions = (f - (HxOverrides.modf(f, 1)))
        if (noFractions > 9007199254740991):
            raise _HxException("Conversion overflow")
        if (noFractions < -9007199254740991):
            raise _HxException("Conversion underflow")
        this1 = haxe__Int64____Int64(0,0)
        result = this1
        neg = (noFractions < 0)
        rest = (-noFractions if neg else noFractions)
        i = 0
        while (rest >= 1):
            curr = HxOverrides.modf(rest, 2)
            rest = (rest / 2)
            if (curr >= 1):
                this2 = haxe__Int64____Int64(0,1)
                a = this2
                b = i
                b = (b & 63)
                b1 = None
                if (b == 0):
                    this3 = haxe__Int64____Int64(a.high,a.low)
                    b1 = this3
                elif (b < 32):
                    this4 = haxe__Int64____Int64((((((a.high << b)) + (2 ** 31)) % (2 ** 32) - (2 ** 31)) | HxOverrides.rshift(a.low, ((32 - b)))),((((a.low << b)) + (2 ** 31)) % (2 ** 32) - (2 ** 31)))
                    b1 = this4
                else:
                    this5 = haxe__Int64____Int64(((((a.low << (b - 32))) + (2 ** 31)) % (2 ** 32) - (2 ** 31)),0)
                    b1 = this5
                high = (((result.high + b1.high) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                low = (((result.low + b1.low) + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                if (haxe__Int32_Int32_Impl_.ucompare(low,result.low) < 0):
                    ret = high
                    high = (high + 1)
                    high = ((high + (2 ** 31)) % (2 ** 32) - (2 ** 31))
                this6 = haxe__Int64____Int64(high,low)
                result = this6
            i = (i + 1)
        if neg:
            high1 = ~result.high
            low1 = -result.low
            if (low1 == 0):
                ret1 = high1
                high1 = (high1 + 1)
                high1 = ((high1 + (2 ** 31)) % (2 ** 32) - (2 ** 31))
            this7 = haxe__Int64____Int64(high1,low1)
            result = this7
        return result
haxe_Int64Helper._hx_class = haxe_Int64Helper
_hx_classes["haxe.Int64Helper"] = haxe_Int64Helper


class haxe_MainEvent:
    _hx_class_name = "haxe.MainEvent"
    __slots__ = ("f", "prev", "next", "nextRun", "priority")
    _hx_fields = ["f", "prev", "next", "nextRun", "priority"]
    _hx_methods = ["delay", "stop"]

    def __init__(self,f,p):
        self.next = None
        self.prev = None
        self.f = f
        self.priority = p
        self.nextRun = -1

    def delay(self,t):
        self.nextRun = (-1 if ((t is None)) else (python_lib_Timeit.default_timer() + t))

    def stop(self):
        if (self.f is None):
            return
        self.f = None
        self.nextRun = -1
        if (self.prev is None):
            haxe_MainLoop.pending = self.next
        else:
            self.prev.next = self.next
        if (self.next is not None):
            self.next.prev = self.prev

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.f = None
        _hx_o.prev = None
        _hx_o.next = None
        _hx_o.nextRun = None
        _hx_o.priority = None
haxe_MainEvent._hx_class = haxe_MainEvent
_hx_classes["haxe.MainEvent"] = haxe_MainEvent


class haxe_MainLoop:
    _hx_class_name = "haxe.MainLoop"
    __slots__ = ()
    _hx_statics = ["pending", "add", "sortEvents", "tick"]
    threadCount = None

    @staticmethod
    def add(f,priority = 0):
        if (priority is None):
            priority = 0
        if (f is None):
            raise _HxException("Event function is null")
        e = haxe_MainEvent(f,priority)
        head = haxe_MainLoop.pending
        if (head is not None):
            head.prev = e
        e.next = head
        haxe_MainLoop.pending = e
        return e

    @staticmethod
    def sortEvents():
        _hx_list = haxe_MainLoop.pending
        if (_hx_list is None):
            return
        insize = 1
        nmerges = None
        psize = 0
        qsize = 0
        p = None
        q = None
        e = None
        tail = None
        while True:
            p = _hx_list
            _hx_list = None
            tail = None
            nmerges = 0
            while (p is not None):
                nmerges = (nmerges + 1)
                q = p
                psize = 0
                _g1 = 0
                _g = insize
                while (_g1 < _g):
                    i = _g1
                    _g1 = (_g1 + 1)
                    psize = (psize + 1)
                    q = q.next
                    if (q is None):
                        break
                qsize = insize
                while ((psize > 0) or (((qsize > 0) and ((q is not None))))):
                    if (psize == 0):
                        e = q
                        q = q.next
                        qsize = (qsize - 1)
                    elif (((qsize == 0) or ((q is None))) or (((p.priority > q.priority) or (((p.priority == q.priority) and ((p.nextRun <= q.nextRun))))))):
                        e = p
                        p = p.next
                        psize = (psize - 1)
                    else:
                        e = q
                        q = q.next
                        qsize = (qsize - 1)
                    if (tail is not None):
                        tail.next = e
                    else:
                        _hx_list = e
                    e.prev = tail
                    tail = e
                p = q
            tail.next = None
            if (nmerges <= 1):
                break
            insize = (insize * 2)
        _hx_list.prev = None
        haxe_MainLoop.pending = _hx_list

    @staticmethod
    def tick():
        haxe_MainLoop.sortEvents()
        e = haxe_MainLoop.pending
        now = python_lib_Timeit.default_timer()
        wait = 1e9
        while (e is not None):
            next = e.next
            wt = (e.nextRun - now)
            if ((e.nextRun < 0) or ((wt <= 0))):
                wait = 0
                if (e.f is not None):
                    e.f()
            elif (wait > wt):
                wait = wt
            e = next
        return wait
haxe_MainLoop._hx_class = haxe_MainLoop
_hx_classes["haxe.MainLoop"] = haxe_MainLoop


class haxe_Serializer:
    _hx_class_name = "haxe.Serializer"
    __slots__ = ("buf", "cache", "shash", "scount", "useCache", "useEnumIndex")
    _hx_fields = ["buf", "cache", "shash", "scount", "useCache", "useEnumIndex"]
    _hx_methods = ["toString", "serializeString", "serializeRef", "serializeFields", "serialize"]
    _hx_statics = ["USE_CACHE", "USE_ENUM_INDEX", "BASE64", "BASE64_CODES"]

    def __init__(self):
        self.buf = StringBuf()
        self.cache = list()
        self.useCache = haxe_Serializer.USE_CACHE
        self.useEnumIndex = haxe_Serializer.USE_ENUM_INDEX
        self.shash = haxe_ds_StringMap()
        self.scount = 0

    def toString(self):
        return self.buf.b.getvalue()

    def serializeString(self,s):
        x = self.shash.h.get(s,None)
        if (x is not None):
            self.buf.b.write("R")
            _this = self.buf
            s1 = Std.string(x)
            _this.b.write(s1)
            return
        value = self.scount
        self.scount = (self.scount + 1)
        self.shash.h[s] = value
        self.buf.b.write("y")
        s = python_lib_urllib_Parse.quote(s,"")
        _this1 = self.buf
        s2 = Std.string(len(s))
        _this1.b.write(s2)
        self.buf.b.write(":")
        _this2 = self.buf
        s3 = Std.string(s)
        _this2.b.write(s3)

    def serializeRef(self,v):
        _g1 = 0
        _g = len(self.cache)
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            if ((self.cache[i] if i >= 0 and i < len(self.cache) else None) == v):
                self.buf.b.write("r")
                _this = self.buf
                s = Std.string(i)
                _this.b.write(s)
                return True
        _this1 = self.cache
        _this1.append(v)
        return False

    def serializeFields(self,v):
        _g = 0
        _g1 = python_Boot.fields(v)
        while (_g < len(_g1)):
            f = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            self.serializeString(f)
            self.serialize(Reflect.field(v,f))
        self.buf.b.write("g")

    def serialize(self,v):
        _g = Type.typeof(v)
        _g1 = _g.index
        if (_g1 == 0):
            self.buf.b.write("n")
        elif (_g1 == 1):
            v1 = v
            if (v1 == 0):
                self.buf.b.write("z")
                return
            self.buf.b.write("i")
            _this = self.buf
            s = Std.string(v1)
            _this.b.write(s)
        elif (_g1 == 2):
            v2 = v
            if python_lib_Math.isnan(v2):
                self.buf.b.write("k")
            elif (not ((((v2 != Math.POSITIVE_INFINITY) and ((v2 != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(v2))))):
                self.buf.b.write(("m" if ((v2 < 0)) else "p"))
            else:
                self.buf.b.write("d")
                _this1 = self.buf
                s1 = Std.string(v2)
                _this1.b.write(s1)
        elif (_g1 == 3):
            self.buf.b.write(("t" if v else "f"))
        elif (_g1 == 4):
            if Std._hx_is(v,Class):
                className = Type.getClassName(v)
                self.buf.b.write("A")
                self.serializeString(className)
            elif Std._hx_is(v,Enum):
                self.buf.b.write("B")
                self.serializeString(Type.getEnumName(v))
            else:
                if (self.useCache and self.serializeRef(v)):
                    return
                self.buf.b.write("o")
                self.serializeFields(v)
        elif (_g1 == 5):
            raise _HxException("Cannot serialize function")
        elif (_g1 == 6):
            c = _g.params[0]
            if (c == str):
                self.serializeString(v)
                return
            if (self.useCache and self.serializeRef(v)):
                return
            _g2 = Type.getClassName(c)
            _g3 = _g2
            _hx_local_0 = len(_g3)
            if (_hx_local_0 == 17):
                if (_g3 == "haxe.ds.ObjectMap"):
                    self.buf.b.write("M")
                    v6 = v
                    k2 = v6.keys()
                    while k2.hasNext():
                        k3 = k2.next()
                        self.serialize(k3)
                        self.serialize(v6.h.get(k3,None))
                    self.buf.b.write("h")
                elif (_g3 == "haxe.ds.StringMap"):
                    self.buf.b.write("b")
                    v7 = v
                    k4 = v7.keys()
                    while k4.hasNext():
                        k5 = k4.next()
                        self.serializeString(k5)
                        self.serialize(v7.h.get(k5,None))
                    self.buf.b.write("h")
                else:
                    if self.useCache:
                        _this16 = self.cache
                        if (len(_this16) != 0):
                            _this16.pop()
                    if hasattr(v,(("_hx_" + "hxSerialize") if (("hxSerialize" in python_Boot.keywords)) else (("_hx_" + "hxSerialize") if (((((len("hxSerialize") > 2) and ((ord("hxSerialize"[0]) == 95))) and ((ord("hxSerialize"[1]) == 95))) and ((ord("hxSerialize"[(len("hxSerialize") - 1)]) != 95)))) else "hxSerialize"))):
                        self.buf.b.write("C")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this17 = self.cache
                            _this17.append(v)
                        Reflect.field(v,"hxSerialize")(self)
                        self.buf.b.write("g")
                    else:
                        self.buf.b.write("c")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this18 = self.cache
                            _this18.append(v)
                        self.serializeFields(v)
            elif (_hx_local_0 == 5):
                if (_g3 == "Array"):
                    ucount = 0
                    self.buf.b.write("a")
                    v3 = v
                    l = len(v3)
                    _g11 = 0
                    _g4 = l
                    while (_g11 < _g4):
                        i = _g11
                        _g11 = (_g11 + 1)
                        if ((v3[i] if i >= 0 and i < len(v3) else None) is None):
                            ucount = (ucount + 1)
                        else:
                            if (ucount > 0):
                                if (ucount == 1):
                                    self.buf.b.write("n")
                                else:
                                    self.buf.b.write("u")
                                    _this2 = self.buf
                                    s2 = Std.string(ucount)
                                    _this2.b.write(s2)
                                ucount = 0
                            self.serialize((v3[i] if i >= 0 and i < len(v3) else None))
                    if (ucount > 0):
                        if (ucount == 1):
                            self.buf.b.write("n")
                        else:
                            self.buf.b.write("u")
                            _this3 = self.buf
                            s3 = Std.string(ucount)
                            _this3.b.write(s3)
                    self.buf.b.write("h")
                else:
                    if self.useCache:
                        _this16 = self.cache
                        if (len(_this16) != 0):
                            _this16.pop()
                    if hasattr(v,(("_hx_" + "hxSerialize") if (("hxSerialize" in python_Boot.keywords)) else (("_hx_" + "hxSerialize") if (((((len("hxSerialize") > 2) and ((ord("hxSerialize"[0]) == 95))) and ((ord("hxSerialize"[1]) == 95))) and ((ord("hxSerialize"[(len("hxSerialize") - 1)]) != 95)))) else "hxSerialize"))):
                        self.buf.b.write("C")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this17 = self.cache
                            _this17.append(v)
                        Reflect.field(v,"hxSerialize")(self)
                        self.buf.b.write("g")
                    else:
                        self.buf.b.write("c")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this18 = self.cache
                            _this18.append(v)
                        self.serializeFields(v)
            elif (_hx_local_0 == 4):
                if (_g3 == "Date"):
                    d = v
                    self.buf.b.write("v")
                    _this4 = self.buf
                    s4 = Std.string((python_lib_Time.mktime(d.date.timetuple()) * 1000))
                    _this4.b.write(s4)
                elif (_g3 == "List"):
                    self.buf.b.write("l")
                    v4 = v
                    _g_head = v4.h
                    while (_g_head is not None):
                        val = _g_head.item
                        _g_head = _g_head.next
                        i1 = val
                        self.serialize(i1)
                    self.buf.b.write("h")
                else:
                    if self.useCache:
                        _this16 = self.cache
                        if (len(_this16) != 0):
                            _this16.pop()
                    if hasattr(v,(("_hx_" + "hxSerialize") if (("hxSerialize" in python_Boot.keywords)) else (("_hx_" + "hxSerialize") if (((((len("hxSerialize") > 2) and ((ord("hxSerialize"[0]) == 95))) and ((ord("hxSerialize"[1]) == 95))) and ((ord("hxSerialize"[(len("hxSerialize") - 1)]) != 95)))) else "hxSerialize"))):
                        self.buf.b.write("C")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this17 = self.cache
                            _this17.append(v)
                        Reflect.field(v,"hxSerialize")(self)
                        self.buf.b.write("g")
                    else:
                        self.buf.b.write("c")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this18 = self.cache
                            _this18.append(v)
                        self.serializeFields(v)
            elif (_hx_local_0 == 13):
                if (_g3 == "haxe.io.Bytes"):
                    v8 = v
                    self.buf.b.write("s")
                    _this6 = self.buf
                    s6 = Std.string(Math.ceil(((v8.length * 8) / 6)))
                    _this6.b.write(s6)
                    self.buf.b.write(":")
                    i2 = 0
                    _hx_max = (v8.length - 2)
                    b64 = haxe_Serializer.BASE64_CODES
                    if (b64 is None):
                        this1 = [None]*len(haxe_Serializer.BASE64)
                        b64 = this1
                        _g12 = 0
                        _g5 = len(haxe_Serializer.BASE64)
                        while (_g12 < _g5):
                            i3 = _g12
                            _g12 = (_g12 + 1)
                            val1 = HxString.charCodeAt(haxe_Serializer.BASE64,i3)
                            b64[i3] = val1
                        haxe_Serializer.BASE64_CODES = b64
                    while (i2 < _hx_max):
                        pos = i2
                        i2 = (i2 + 1)
                        b1 = v8.b[pos]
                        pos1 = i2
                        i2 = (i2 + 1)
                        b2 = v8.b[pos1]
                        pos2 = i2
                        i2 = (i2 + 1)
                        b3 = v8.b[pos2]
                        _this7 = self.buf
                        c1 = b64[(b1 >> 2)]
                        s7 = "".join(map(chr,[c1]))
                        _this7.b.write(s7)
                        _this8 = self.buf
                        c2 = b64[((((b1 << 4) | ((b2 >> 4)))) & 63)]
                        s8 = "".join(map(chr,[c2]))
                        _this8.b.write(s8)
                        _this9 = self.buf
                        c3 = b64[((((b2 << 2) | ((b3 >> 6)))) & 63)]
                        s9 = "".join(map(chr,[c3]))
                        _this9.b.write(s9)
                        _this10 = self.buf
                        c4 = b64[(b3 & 63)]
                        s10 = "".join(map(chr,[c4]))
                        _this10.b.write(s10)
                    if (i2 == _hx_max):
                        pos3 = i2
                        i2 = (i2 + 1)
                        b11 = v8.b[pos3]
                        pos4 = i2
                        i2 = (i2 + 1)
                        b21 = v8.b[pos4]
                        _this11 = self.buf
                        c5 = b64[(b11 >> 2)]
                        s11 = "".join(map(chr,[c5]))
                        _this11.b.write(s11)
                        _this12 = self.buf
                        c6 = b64[((((b11 << 4) | ((b21 >> 4)))) & 63)]
                        s12 = "".join(map(chr,[c6]))
                        _this12.b.write(s12)
                        _this13 = self.buf
                        c7 = b64[((b21 << 2) & 63)]
                        s13 = "".join(map(chr,[c7]))
                        _this13.b.write(s13)
                    elif (i2 == ((_hx_max + 1))):
                        pos5 = i2
                        i2 = (i2 + 1)
                        b12 = v8.b[pos5]
                        _this14 = self.buf
                        c8 = b64[(b12 >> 2)]
                        s14 = "".join(map(chr,[c8]))
                        _this14.b.write(s14)
                        _this15 = self.buf
                        c9 = b64[((b12 << 4) & 63)]
                        s15 = "".join(map(chr,[c9]))
                        _this15.b.write(s15)
                else:
                    if self.useCache:
                        _this16 = self.cache
                        if (len(_this16) != 0):
                            _this16.pop()
                    if hasattr(v,(("_hx_" + "hxSerialize") if (("hxSerialize" in python_Boot.keywords)) else (("_hx_" + "hxSerialize") if (((((len("hxSerialize") > 2) and ((ord("hxSerialize"[0]) == 95))) and ((ord("hxSerialize"[1]) == 95))) and ((ord("hxSerialize"[(len("hxSerialize") - 1)]) != 95)))) else "hxSerialize"))):
                        self.buf.b.write("C")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this17 = self.cache
                            _this17.append(v)
                        Reflect.field(v,"hxSerialize")(self)
                        self.buf.b.write("g")
                    else:
                        self.buf.b.write("c")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this18 = self.cache
                            _this18.append(v)
                        self.serializeFields(v)
            elif (_hx_local_0 == 14):
                if (_g3 == "haxe.ds.IntMap"):
                    self.buf.b.write("q")
                    v5 = v
                    k = v5.keys()
                    while k.hasNext():
                        k1 = k.next()
                        self.buf.b.write(":")
                        _this5 = self.buf
                        s5 = Std.string(k1)
                        _this5.b.write(s5)
                        self.serialize(v5.h.get(k1,None))
                    self.buf.b.write("h")
                else:
                    if self.useCache:
                        _this16 = self.cache
                        if (len(_this16) != 0):
                            _this16.pop()
                    if hasattr(v,(("_hx_" + "hxSerialize") if (("hxSerialize" in python_Boot.keywords)) else (("_hx_" + "hxSerialize") if (((((len("hxSerialize") > 2) and ((ord("hxSerialize"[0]) == 95))) and ((ord("hxSerialize"[1]) == 95))) and ((ord("hxSerialize"[(len("hxSerialize") - 1)]) != 95)))) else "hxSerialize"))):
                        self.buf.b.write("C")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this17 = self.cache
                            _this17.append(v)
                        Reflect.field(v,"hxSerialize")(self)
                        self.buf.b.write("g")
                    else:
                        self.buf.b.write("c")
                        self.serializeString(Type.getClassName(c))
                        if self.useCache:
                            _this18 = self.cache
                            _this18.append(v)
                        self.serializeFields(v)
            else:
                if self.useCache:
                    _this16 = self.cache
                    if (len(_this16) != 0):
                        _this16.pop()
                if hasattr(v,(("_hx_" + "hxSerialize") if (("hxSerialize" in python_Boot.keywords)) else (("_hx_" + "hxSerialize") if (((((len("hxSerialize") > 2) and ((ord("hxSerialize"[0]) == 95))) and ((ord("hxSerialize"[1]) == 95))) and ((ord("hxSerialize"[(len("hxSerialize") - 1)]) != 95)))) else "hxSerialize"))):
                    self.buf.b.write("C")
                    self.serializeString(Type.getClassName(c))
                    if self.useCache:
                        _this17 = self.cache
                        _this17.append(v)
                    Reflect.field(v,"hxSerialize")(self)
                    self.buf.b.write("g")
                else:
                    self.buf.b.write("c")
                    self.serializeString(Type.getClassName(c))
                    if self.useCache:
                        _this18 = self.cache
                        _this18.append(v)
                    self.serializeFields(v)
        elif (_g1 == 7):
            e = _g.params[0]
            if self.useCache:
                if self.serializeRef(v):
                    return
                _this19 = self.cache
                if (len(_this19) != 0):
                    _this19.pop()
            _this20 = self.buf
            s16 = Std.string(("j" if (self.useEnumIndex) else "w"))
            _this20.b.write(s16)
            self.serializeString(Type.getEnumName(e))
            if self.useEnumIndex:
                self.buf.b.write(":")
                _this21 = self.buf
                s17 = Std.string(v.index)
                _this21.b.write(s17)
            else:
                self.serializeString(v.tag)
            self.buf.b.write(":")
            arr = v.params
            if (arr is not None):
                _this22 = self.buf
                s18 = Std.string(len(arr))
                _this22.b.write(s18)
                _g6 = 0
                while (_g6 < len(arr)):
                    v9 = (arr[_g6] if _g6 >= 0 and _g6 < len(arr) else None)
                    _g6 = (_g6 + 1)
                    self.serialize(v9)
            else:
                self.buf.b.write("0")
            if self.useCache:
                _this23 = self.cache
                _this23.append(v)
        else:
            raise _HxException(("Cannot serialize " + Std.string(v)))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.buf = None
        _hx_o.cache = None
        _hx_o.shash = None
        _hx_o.scount = None
        _hx_o.useCache = None
        _hx_o.useEnumIndex = None
haxe_Serializer._hx_class = haxe_Serializer
_hx_classes["haxe.Serializer"] = haxe_Serializer


class haxe_Timer:
    _hx_class_name = "haxe.Timer"
    _hx_fields = ["event"]
    _hx_methods = ["stop", "run"]

    def __init__(self,time_ms):
        self.event = None
        _gthis = self
        dt = (time_ms / 1000)
        def _hx_local_2():
            _hx_local_0 = _gthis.event
            _hx_local_1 = _hx_local_0.nextRun
            _hx_local_0.nextRun = (_hx_local_1 + dt)
            _hx_local_0.nextRun
            _gthis.run()
        self.event = haxe_MainLoop.add(_hx_local_2)
        self.event.delay(dt)

    def stop(self):
        if (self.event is not None):
            self.event.stop()
            self.event = None

    def run(self):
        pass

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.event = None
haxe_Timer._hx_class = haxe_Timer
_hx_classes["haxe.Timer"] = haxe_Timer


class haxe__Unserializer_DefaultResolver:
    _hx_class_name = "haxe._Unserializer.DefaultResolver"
    __slots__ = ()
    _hx_methods = ["resolveClass", "resolveEnum"]

    def __init__(self):
        pass

    def resolveClass(self,name):
        return Type.resolveClass(name)

    def resolveEnum(self,name):
        return Type.resolveEnum(name)

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe__Unserializer_DefaultResolver._hx_class = haxe__Unserializer_DefaultResolver
_hx_classes["haxe._Unserializer.DefaultResolver"] = haxe__Unserializer_DefaultResolver


class haxe_Unserializer:
    _hx_class_name = "haxe.Unserializer"
    __slots__ = ("buf", "pos", "length", "cache", "scache", "resolver")
    _hx_fields = ["buf", "pos", "length", "cache", "scache", "resolver"]
    _hx_methods = ["readDigits", "readFloat", "unserializeObject", "unserializeEnum", "unserialize"]
    _hx_statics = ["DEFAULT_RESOLVER", "BASE64", "CODES", "initCodes"]

    def __init__(self,buf):
        self.buf = buf
        self.length = len(buf)
        self.pos = 0
        self.scache = list()
        self.cache = list()
        r = haxe_Unserializer.DEFAULT_RESOLVER
        if (r is None):
            r = haxe__Unserializer_DefaultResolver()
            haxe_Unserializer.DEFAULT_RESOLVER = r
        self.resolver = r

    def readDigits(self):
        k = 0
        s = False
        fpos = self.pos
        while True:
            p = self.pos
            s1 = self.buf
            c = (-1 if ((p >= len(s1))) else ord(s1[p]))
            if (c == -1):
                break
            if (c == 45):
                if (self.pos != fpos):
                    break
                s = True
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.pos
                _hx_local_0.pos = (_hx_local_1 + 1)
                _hx_local_1
                continue
            if ((c < 48) or ((c > 57))):
                break
            k = ((k * 10) + ((c - 48)))
            _hx_local_2 = self
            _hx_local_3 = _hx_local_2.pos
            _hx_local_2.pos = (_hx_local_3 + 1)
            _hx_local_3
        if s:
            k = (k * -1)
        return k

    def readFloat(self):
        p1 = self.pos
        while True:
            p = self.pos
            s = self.buf
            c = (-1 if ((p >= len(s))) else ord(s[p]))
            if (c == -1):
                break
            if ((((c >= 43) and ((c < 58))) or ((c == 101))) or ((c == 69))):
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.pos
                _hx_local_0.pos = (_hx_local_1 + 1)
                _hx_local_1
            else:
                break
        return Std.parseFloat(HxString.substr(self.buf,p1,(self.pos - p1)))

    def unserializeObject(self,o):
        while True:
            if (self.pos >= self.length):
                raise _HxException("Invalid object")
            p = self.pos
            s = self.buf
            if (((-1 if ((p >= len(s))) else ord(s[p]))) == 103):
                break
            k = self.unserialize()
            if (not Std._hx_is(k,str)):
                raise _HxException("Invalid object key")
            v = self.unserialize()
            setattr(o,(("_hx_" + k) if ((k in python_Boot.keywords)) else (("_hx_" + k) if (((((len(k) > 2) and ((ord(k[0]) == 95))) and ((ord(k[1]) == 95))) and ((ord(k[(len(k) - 1)]) != 95)))) else k)),v)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.pos
        _hx_local_0.pos = (_hx_local_1 + 1)
        _hx_local_1

    def unserializeEnum(self,edecl,tag):
        p = self.pos
        self.pos = (self.pos + 1)
        s = self.buf
        if (((-1 if ((p >= len(s))) else ord(s[p]))) != 58):
            raise _HxException("Invalid enum format")
        nargs = self.readDigits()
        if (nargs == 0):
            return Type.createEnum(edecl,tag)
        args = list()
        while True:
            tmp = nargs
            nargs = (nargs - 1)
            if (not ((tmp > 0))):
                break
            x = self.unserialize()
            args.append(x)
        return Type.createEnum(edecl,tag,args)

    def unserialize(self):
        p = self.pos
        self.pos = (self.pos + 1)
        s = self.buf
        _g = (-1 if ((p >= len(s))) else ord(s[p]))
        _g1 = _g
        if (_g1 == 65):
            name = self.unserialize()
            cl = self.resolver.resolveClass(name)
            if (cl is None):
                raise _HxException(("Class not found " + ("null" if name is None else name)))
            return cl
        elif (_g1 == 66):
            name1 = self.unserialize()
            e = self.resolver.resolveEnum(name1)
            if (e is None):
                raise _HxException(("Enum not found " + ("null" if name1 is None else name1)))
            return e
        elif (_g1 == 67):
            name2 = self.unserialize()
            cl1 = self.resolver.resolveClass(name2)
            if (cl1 is None):
                raise _HxException(("Class not found " + ("null" if name2 is None else name2)))
            o = Type.createEmptyInstance(cl1)
            _this = self.cache
            _this.append(o)
            Reflect.field(o,"hxUnserialize")(self)
            p1 = self.pos
            self.pos = (self.pos + 1)
            s1 = self.buf
            if (((-1 if ((p1 >= len(s1))) else ord(s1[p1]))) != 103):
                raise _HxException("Invalid custom data")
            return o
        elif (_g1 == 77):
            h = haxe_ds_ObjectMap()
            _this1 = self.cache
            _this1.append(h)
            buf = self.buf
            while True:
                p2 = self.pos
                s2 = self.buf
                if (not ((((-1 if ((p2 >= len(s2))) else ord(s2[p2]))) != 104))):
                    break
                s3 = self.unserialize()
                h.set(s3,self.unserialize())
            _hx_local_0 = self
            _hx_local_1 = _hx_local_0.pos
            _hx_local_0.pos = (_hx_local_1 + 1)
            _hx_local_1
            return h
        elif (_g1 == 82):
            n = self.readDigits()
            if ((n < 0) or ((n >= len(self.scache)))):
                raise _HxException("Invalid string reference")
            return (self.scache[n] if n >= 0 and n < len(self.scache) else None)
        elif (_g1 == 97):
            buf1 = self.buf
            a = list()
            _this2 = self.cache
            _this2.append(a)
            while True:
                p3 = self.pos
                s4 = self.buf
                c = (-1 if ((p3 >= len(s4))) else ord(s4[p3]))
                if (c == 104):
                    _hx_local_2 = self
                    _hx_local_3 = _hx_local_2.pos
                    _hx_local_2.pos = (_hx_local_3 + 1)
                    _hx_local_3
                    break
                if (c == 117):
                    _hx_local_4 = self
                    _hx_local_5 = _hx_local_4.pos
                    _hx_local_4.pos = (_hx_local_5 + 1)
                    _hx_local_5
                    n1 = self.readDigits()
                    python_internal_ArrayImpl._set(a, ((len(a) + n1) - 1), None)
                else:
                    x = self.unserialize()
                    a.append(x)
            return a
        elif (_g1 == 98):
            h1 = haxe_ds_StringMap()
            _this3 = self.cache
            _this3.append(h1)
            buf2 = self.buf
            while True:
                p4 = self.pos
                s5 = self.buf
                if (not ((((-1 if ((p4 >= len(s5))) else ord(s5[p4]))) != 104))):
                    break
                s6 = self.unserialize()
                value = self.unserialize()
                h1.h[s6] = value
            _hx_local_6 = self
            _hx_local_7 = _hx_local_6.pos
            _hx_local_6.pos = (_hx_local_7 + 1)
            _hx_local_7
            return h1
        elif (_g1 == 99):
            name3 = self.unserialize()
            cl2 = self.resolver.resolveClass(name3)
            if (cl2 is None):
                raise _HxException(("Class not found " + ("null" if name3 is None else name3)))
            o1 = Type.createEmptyInstance(cl2)
            _this4 = self.cache
            _this4.append(o1)
            self.unserializeObject(o1)
            return o1
        elif (_g1 == 100):
            return self.readFloat()
        elif (_g1 == 102):
            return False
        elif (_g1 == 105):
            return self.readDigits()
        elif (_g1 == 106):
            name4 = self.unserialize()
            edecl = self.resolver.resolveEnum(name4)
            if (edecl is None):
                raise _HxException(("Enum not found " + ("null" if name4 is None else name4)))
            _hx_local_8 = self
            _hx_local_9 = _hx_local_8.pos
            _hx_local_8.pos = (_hx_local_9 + 1)
            _hx_local_9
            index = self.readDigits()
            tag = python_internal_ArrayImpl._get(Type.getEnumConstructs(edecl), index)
            if (tag is None):
                raise _HxException(((("Unknown enum index " + ("null" if name4 is None else name4)) + "@") + Std.string(index)))
            e1 = self.unserializeEnum(edecl,tag)
            _this5 = self.cache
            _this5.append(e1)
            return e1
        elif (_g1 == 107):
            return Math.NaN
        elif (_g1 == 108):
            l = List()
            _this6 = self.cache
            _this6.append(l)
            buf3 = self.buf
            while True:
                p5 = self.pos
                s7 = self.buf
                if (not ((((-1 if ((p5 >= len(s7))) else ord(s7[p5]))) != 104))):
                    break
                l.add(self.unserialize())
            _hx_local_10 = self
            _hx_local_11 = _hx_local_10.pos
            _hx_local_10.pos = (_hx_local_11 + 1)
            _hx_local_11
            return l
        elif (_g1 == 109):
            return Math.NEGATIVE_INFINITY
        elif (_g1 == 110):
            return None
        elif (_g1 == 111):
            o2 = _hx_AnonObject({})
            _this7 = self.cache
            _this7.append(o2)
            self.unserializeObject(o2)
            return o2
        elif (_g1 == 112):
            return Math.POSITIVE_INFINITY
        elif (_g1 == 113):
            h2 = haxe_ds_IntMap()
            _this8 = self.cache
            _this8.append(h2)
            buf4 = self.buf
            p6 = self.pos
            self.pos = (self.pos + 1)
            s8 = self.buf
            c1 = (-1 if ((p6 >= len(s8))) else ord(s8[p6]))
            while (c1 == 58):
                i = self.readDigits()
                h2.set(i,self.unserialize())
                p7 = self.pos
                self.pos = (self.pos + 1)
                s9 = self.buf
                if (p7 >= len(s9)):
                    c1 = -1
                else:
                    c1 = ord(s9[p7])
            if (c1 != 104):
                raise _HxException("Invalid IntMap format")
            return h2
        elif (_g1 == 114):
            n2 = self.readDigits()
            if ((n2 < 0) or ((n2 >= len(self.cache)))):
                raise _HxException("Invalid reference")
            return (self.cache[n2] if n2 >= 0 and n2 < len(self.cache) else None)
        elif (_g1 == 115):
            _hx_len = self.readDigits()
            buf5 = self.buf
            tmp = None
            p8 = self.pos
            self.pos = (self.pos + 1)
            s10 = self.buf
            if (((-1 if ((p8 >= len(s10))) else ord(s10[p8]))) == 58):
                tmp = ((self.length - self.pos) < _hx_len)
            else:
                tmp = True
            if tmp:
                raise _HxException("Invalid bytes length")
            codes = haxe_Unserializer.CODES
            if (codes is None):
                codes = haxe_Unserializer.initCodes()
                haxe_Unserializer.CODES = codes
            i1 = self.pos
            rest = (_hx_len & 3)
            size = ((((_hx_len >> 2)) * 3) + (((rest - 1) if ((rest >= 2)) else 0)))
            _hx_max = (i1 + ((_hx_len - rest)))
            _hx_bytes = haxe_io_Bytes.alloc(size)
            bpos = 0
            while (i1 < _hx_max):
                index1 = i1
                i1 = (i1 + 1)
                c11 = python_internal_ArrayImpl._get(codes, (-1 if ((index1 >= len(buf5))) else ord(buf5[index1])))
                index2 = i1
                i1 = (i1 + 1)
                c2 = python_internal_ArrayImpl._get(codes, (-1 if ((index2 >= len(buf5))) else ord(buf5[index2])))
                pos = bpos
                bpos = (bpos + 1)
                _hx_bytes.b[pos] = ((((c11 << 2) | ((c2 >> 4)))) & 255)
                index3 = i1
                i1 = (i1 + 1)
                c3 = python_internal_ArrayImpl._get(codes, (-1 if ((index3 >= len(buf5))) else ord(buf5[index3])))
                pos1 = bpos
                bpos = (bpos + 1)
                _hx_bytes.b[pos1] = ((((c2 << 4) | ((c3 >> 2)))) & 255)
                index4 = i1
                i1 = (i1 + 1)
                c4 = python_internal_ArrayImpl._get(codes, (-1 if ((index4 >= len(buf5))) else ord(buf5[index4])))
                pos2 = bpos
                bpos = (bpos + 1)
                _hx_bytes.b[pos2] = ((((c3 << 6) | c4)) & 255)
            if (rest >= 2):
                index5 = i1
                i1 = (i1 + 1)
                c12 = python_internal_ArrayImpl._get(codes, (-1 if ((index5 >= len(buf5))) else ord(buf5[index5])))
                index6 = i1
                i1 = (i1 + 1)
                c21 = python_internal_ArrayImpl._get(codes, (-1 if ((index6 >= len(buf5))) else ord(buf5[index6])))
                pos3 = bpos
                bpos = (bpos + 1)
                _hx_bytes.b[pos3] = ((((c12 << 2) | ((c21 >> 4)))) & 255)
                if (rest == 3):
                    index7 = i1
                    i1 = (i1 + 1)
                    c31 = python_internal_ArrayImpl._get(codes, (-1 if ((index7 >= len(buf5))) else ord(buf5[index7])))
                    pos4 = bpos
                    bpos = (bpos + 1)
                    _hx_bytes.b[pos4] = ((((c21 << 4) | ((c31 >> 2)))) & 255)
            _hx_local_12 = self
            _hx_local_13 = _hx_local_12.pos
            _hx_local_12.pos = (_hx_local_13 + _hx_len)
            _hx_local_12.pos
            _this9 = self.cache
            _this9.append(_hx_bytes)
            return _hx_bytes
        elif (_g1 == 116):
            return True
        elif (_g1 == 118):
            d = None
            tmp1 = None
            tmp2 = None
            tmp3 = None
            tmp4 = None
            tmp5 = None
            tmp6 = None
            tmp7 = None
            tmp8 = None
            p9 = self.pos
            s11 = self.buf
            if (((-1 if ((p9 >= len(s11))) else ord(s11[p9]))) >= 48):
                p10 = self.pos
                s12 = self.buf
                tmp8 = (((-1 if ((p10 >= len(s12))) else ord(s12[p10]))) <= 57)
            else:
                tmp8 = False
            if tmp8:
                p11 = (self.pos + 1)
                s13 = self.buf
                tmp7 = (((-1 if ((p11 >= len(s13))) else ord(s13[p11]))) >= 48)
            else:
                tmp7 = False
            if tmp7:
                p12 = (self.pos + 1)
                s14 = self.buf
                tmp6 = (((-1 if ((p12 >= len(s14))) else ord(s14[p12]))) <= 57)
            else:
                tmp6 = False
            if tmp6:
                p13 = (self.pos + 2)
                s15 = self.buf
                tmp5 = (((-1 if ((p13 >= len(s15))) else ord(s15[p13]))) >= 48)
            else:
                tmp5 = False
            if tmp5:
                p14 = (self.pos + 2)
                s16 = self.buf
                tmp4 = (((-1 if ((p14 >= len(s16))) else ord(s16[p14]))) <= 57)
            else:
                tmp4 = False
            if tmp4:
                p15 = (self.pos + 3)
                s17 = self.buf
                tmp3 = (((-1 if ((p15 >= len(s17))) else ord(s17[p15]))) >= 48)
            else:
                tmp3 = False
            if tmp3:
                p16 = (self.pos + 3)
                s18 = self.buf
                tmp2 = (((-1 if ((p16 >= len(s18))) else ord(s18[p16]))) <= 57)
            else:
                tmp2 = False
            if tmp2:
                p17 = (self.pos + 4)
                s19 = self.buf
                tmp1 = (((-1 if ((p17 >= len(s19))) else ord(s19[p17]))) == 45)
            else:
                tmp1 = False
            if tmp1:
                d = Date.fromString(HxString.substr(self.buf,self.pos,19))
                _hx_local_14 = self
                _hx_local_15 = _hx_local_14.pos
                _hx_local_14.pos = (_hx_local_15 + 19)
                _hx_local_14.pos
            else:
                d = Date.fromTime(self.readFloat())
            _this10 = self.cache
            _this10.append(d)
            return d
        elif (_g1 == 119):
            name5 = self.unserialize()
            edecl1 = self.resolver.resolveEnum(name5)
            if (edecl1 is None):
                raise _HxException(("Enum not found " + ("null" if name5 is None else name5)))
            e2 = self.unserializeEnum(edecl1,self.unserialize())
            _this11 = self.cache
            _this11.append(e2)
            return e2
        elif (_g1 == 120):
            raise _HxException(self.unserialize())
        elif (_g1 == 121):
            len1 = self.readDigits()
            tmp9 = None
            p18 = self.pos
            self.pos = (self.pos + 1)
            s20 = self.buf
            if (((-1 if ((p18 >= len(s20))) else ord(s20[p18]))) == 58):
                tmp9 = ((self.length - self.pos) < len1)
            else:
                tmp9 = True
            if tmp9:
                raise _HxException("Invalid string length")
            s21 = HxString.substr(self.buf,self.pos,len1)
            _hx_local_16 = self
            _hx_local_17 = _hx_local_16.pos
            _hx_local_16.pos = (_hx_local_17 + len1)
            _hx_local_16.pos
            s21 = python_lib_urllib_Parse.unquote(s21)
            _this12 = self.scache
            _this12.append(s21)
            return s21
        elif (_g1 == 122):
            return 0
        else:
            pass
        _hx_local_18 = self
        _hx_local_19 = _hx_local_18.pos
        _hx_local_18.pos = (_hx_local_19 - 1)
        _hx_local_19
        _this13 = self.buf
        index8 = self.pos
        raise _HxException(((("Invalid char " + HxOverrides.stringOrNull((("" if (((index8 < 0) or ((index8 >= len(_this13))))) else _this13[index8])))) + " at position ") + Std.string(self.pos)))

    @staticmethod
    def initCodes():
        codes = list()
        _g1 = 0
        _g = len(haxe_Unserializer.BASE64)
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            s = haxe_Unserializer.BASE64
            python_internal_ArrayImpl._set(codes, (-1 if ((i >= len(s))) else ord(s[i])), i)
        return codes

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.buf = None
        _hx_o.pos = None
        _hx_o.length = None
        _hx_o.cache = None
        _hx_o.scache = None
        _hx_o.resolver = None
haxe_Unserializer._hx_class = haxe_Unserializer
_hx_classes["haxe.Unserializer"] = haxe_Unserializer


class haxe_Utf8:
    _hx_class_name = "haxe.Utf8"
    __slots__ = ()
    _hx_statics = ["compare"]

    @staticmethod
    def compare(a,b):
        if (a > b):
            return 1
        elif (a == b):
            return 0
        else:
            return -1
haxe_Utf8._hx_class = haxe_Utf8
_hx_classes["haxe.Utf8"] = haxe_Utf8


class haxe_crypto_Adler32:
    _hx_class_name = "haxe.crypto.Adler32"
    __slots__ = ("a1", "a2")
    _hx_fields = ["a1", "a2"]
    _hx_methods = ["update", "equals"]
    _hx_statics = ["read"]

    def __init__(self):
        self.a1 = 1
        self.a2 = 0

    def update(self,b,pos,_hx_len):
        a1 = self.a1
        a2 = self.a2
        _g1 = pos
        _g = (pos + _hx_len)
        while (_g1 < _g):
            p = _g1
            _g1 = (_g1 + 1)
            c = b.b[p]
            a1 = HxOverrides.mod(((a1 + c)), 65521)
            a2 = HxOverrides.mod(((a2 + a1)), 65521)
        self.a1 = a1
        self.a2 = a2

    def equals(self,a):
        if (a.a1 == self.a1):
            return (a.a2 == self.a2)
        else:
            return False

    @staticmethod
    def read(i):
        a = haxe_crypto_Adler32()
        a2a = i.readByte()
        a2b = i.readByte()
        a1a = i.readByte()
        a1b = i.readByte()
        a.a1 = ((a1a << 8) | a1b)
        a.a2 = ((a2a << 8) | a2b)
        return a

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.a1 = None
        _hx_o.a2 = None
haxe_crypto_Adler32._hx_class = haxe_crypto_Adler32
_hx_classes["haxe.crypto.Adler32"] = haxe_crypto_Adler32


class haxe_io_Bytes:
    _hx_class_name = "haxe.io.Bytes"
    __slots__ = ("length", "b")
    _hx_fields = ["length", "b"]
    _hx_methods = ["blit", "sub", "getString", "toString"]
    _hx_statics = ["alloc", "ofString", "ofData"]

    def __init__(self,length,b):
        self.length = length
        self.b = b

    def blit(self,pos,src,srcpos,_hx_len):
        if (((((pos < 0) or ((srcpos < 0))) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))) or (((srcpos + _hx_len) > src.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        self.b[pos:pos+_hx_len] = src.b[srcpos:srcpos+_hx_len]

    def sub(self,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        return haxe_io_Bytes(_hx_len,self.b[pos:(pos + _hx_len)])

    def getString(self,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        return self.b[pos:pos+_hx_len].decode('UTF-8','replace')

    def toString(self):
        return self.getString(0,self.length)

    @staticmethod
    def alloc(length):
        return haxe_io_Bytes(length,bytearray(length))

    @staticmethod
    def ofString(s):
        b = bytearray(s,"UTF-8")
        return haxe_io_Bytes(len(b),b)

    @staticmethod
    def ofData(b):
        return haxe_io_Bytes(len(b),b)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.length = None
        _hx_o.b = None
haxe_io_Bytes._hx_class = haxe_io_Bytes
_hx_classes["haxe.io.Bytes"] = haxe_io_Bytes


class haxe_crypto_BaseCode:
    _hx_class_name = "haxe.crypto.BaseCode"
    __slots__ = ("base", "nbits", "tbl")
    _hx_fields = ["base", "nbits", "tbl"]
    _hx_methods = ["initTable", "decodeBytes"]

    def __init__(self,base):
        self.tbl = None
        _hx_len = base.length
        nbits = 1
        while (_hx_len > ((1 << nbits))):
            nbits = (nbits + 1)
        if ((nbits > 8) or ((_hx_len != ((1 << nbits))))):
            raise _HxException("BaseCode : base length must be a power of two.")
        self.base = base
        self.nbits = nbits

    def initTable(self):
        tbl = list()
        _g = 0
        while (_g < 256):
            i = _g
            _g = (_g + 1)
            python_internal_ArrayImpl._set(tbl, i, -1)
        _g1 = 0
        _g2 = self.base.length
        while (_g1 < _g2):
            i1 = _g1
            _g1 = (_g1 + 1)
            python_internal_ArrayImpl._set(tbl, self.base.b[i1], i1)
        self.tbl = tbl

    def decodeBytes(self,b):
        nbits = self.nbits
        base = self.base
        if (self.tbl is None):
            self.initTable()
        tbl = self.tbl
        size = ((b.length * nbits) >> 3)
        out = haxe_io_Bytes.alloc(size)
        buf = 0
        curbits = 0
        pin = 0
        pout = 0
        while (pout < size):
            while (curbits < 8):
                curbits = (curbits + nbits)
                buf = (buf << nbits)
                pos = pin
                pin = (pin + 1)
                i = python_internal_ArrayImpl._get(tbl, b.b[pos])
                if (i == -1):
                    raise _HxException("BaseCode : invalid encoded char")
                buf = (buf | i)
            curbits = (curbits - 8)
            pos1 = pout
            pout = (pout + 1)
            out.b[pos1] = (((buf >> curbits) & 255) & 255)
        return out

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.base = None
        _hx_o.nbits = None
        _hx_o.tbl = None
haxe_crypto_BaseCode._hx_class = haxe_crypto_BaseCode
_hx_classes["haxe.crypto.BaseCode"] = haxe_crypto_BaseCode


class haxe_crypto_Sha1:
    _hx_class_name = "haxe.crypto.Sha1"
    __slots__ = ()
    _hx_methods = ["doEncode", "ft", "kt"]
    _hx_statics = ["make", "bytes2blks"]

    def __init__(self):
        pass

    def doEncode(self,x):
        w = list()
        a = 1732584193
        b = -271733879
        c = -1732584194
        d = 271733878
        e = -1009589776
        i = 0
        while (i < len(x)):
            olda = a
            oldb = b
            oldc = c
            oldd = d
            olde = e
            j = 0
            while (j < 80):
                if (j < 16):
                    python_internal_ArrayImpl._set(w, j, python_internal_ArrayImpl._get(x, (i + j)))
                else:
                    num = (((python_internal_ArrayImpl._get(w, (j - 3)) ^ python_internal_ArrayImpl._get(w, (j - 8))) ^ python_internal_ArrayImpl._get(w, (j - 14))) ^ python_internal_ArrayImpl._get(w, (j - 16)))
                    python_internal_ArrayImpl._set(w, j, ((num << 1) | (HxOverrides.rshift(num, 31))))
                t = (((((((a << 5) | (HxOverrides.rshift(a, 27)))) + self.ft(j,b,c,d)) + e) + (w[j] if j >= 0 and j < len(w) else None)) + self.kt(j))
                e = d
                d = c
                c = ((b << 30) | (HxOverrides.rshift(b, 2)))
                b = a
                a = t
                j = (j + 1)
            a = (a + olda)
            b = (b + oldb)
            c = (c + oldc)
            d = (d + oldd)
            e = (e + olde)
            i = (i + 16)
        return [a, b, c, d, e]

    def ft(self,t,b,c,d):
        if (t < 20):
            return ((b & c) | ((~b & d)))
        if (t < 40):
            return ((b ^ c) ^ d)
        if (t < 60):
            return (((b & c) | ((b & d))) | ((c & d)))
        return ((b ^ c) ^ d)

    def kt(self,t):
        if (t < 20):
            return 1518500249
        if (t < 40):
            return 1859775393
        if (t < 60):
            return -1894007588
        return -899497514

    @staticmethod
    def make(b):
        h = haxe_crypto_Sha1().doEncode(haxe_crypto_Sha1.bytes2blks(b))
        out = haxe_io_Bytes.alloc(20)
        p = 0
        _g = 0
        while (_g < 5):
            i = _g
            _g = (_g + 1)
            pos = p
            p = (p + 1)
            out.b[pos] = (HxOverrides.rshift((h[i] if i >= 0 and i < len(h) else None), 24) & 255)
            pos1 = p
            p = (p + 1)
            out.b[pos1] = ((((h[i] if i >= 0 and i < len(h) else None) >> 16) & 255) & 255)
            pos2 = p
            p = (p + 1)
            out.b[pos2] = ((((h[i] if i >= 0 and i < len(h) else None) >> 8) & 255) & 255)
            pos3 = p
            p = (p + 1)
            out.b[pos3] = (((h[i] if i >= 0 and i < len(h) else None) & 255) & 255)
        return out

    @staticmethod
    def bytes2blks(b):
        nblk = ((((b.length + 8) >> 6)) + 1)
        blks = list()
        _g1 = 0
        _g = (nblk * 16)
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            python_internal_ArrayImpl._set(blks, i, 0)
        _g11 = 0
        _g2 = b.length
        while (_g11 < _g2):
            i1 = _g11
            _g11 = (_g11 + 1)
            p = (i1 >> 2)
            python_internal_ArrayImpl._set(blks, p, ((blks[p] if p >= 0 and p < len(blks) else None) | ((b.b[i1] << ((24 - ((((i1 & 3)) << 3))))))))
        i2 = b.length
        p1 = (i2 >> 2)
        python_internal_ArrayImpl._set(blks, p1, ((blks[p1] if p1 >= 0 and p1 < len(blks) else None) | ((128 << ((24 - ((((i2 & 3)) << 3))))))))
        python_internal_ArrayImpl._set(blks, ((nblk * 16) - 1), (b.length * 8))
        return blks

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_crypto_Sha1._hx_class = haxe_crypto_Sha1
_hx_classes["haxe.crypto.Sha1"] = haxe_crypto_Sha1


class haxe_ds_IntMap:
    _hx_class_name = "haxe.ds.IntMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "keys", "iterator"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def set(self,key,value):
        self.h[key] = value

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    def iterator(self):
        return python_HaxeIterator(iter(self.h.values()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_IntMap._hx_class = haxe_ds_IntMap
_hx_classes["haxe.ds.IntMap"] = haxe_ds_IntMap


class haxe_ds_ObjectMap:
    _hx_class_name = "haxe.ds.ObjectMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def set(self,key,value):
        self.h[key] = value

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_ObjectMap._hx_class = haxe_ds_ObjectMap
_hx_classes["haxe.ds.ObjectMap"] = haxe_ds_ObjectMap


class haxe_format_JsonPrinter:
    _hx_class_name = "haxe.format.JsonPrinter"
    __slots__ = ("buf", "replacer", "indent", "pretty", "nind")
    _hx_fields = ["buf", "replacer", "indent", "pretty", "nind"]
    _hx_methods = ["write", "fieldsString", "quote"]
    _hx_statics = ["print"]

    def __init__(self,replacer,space):
        self.replacer = replacer
        self.indent = space
        self.pretty = (space is not None)
        self.nind = 0
        self.buf = StringBuf()

    def write(self,k,v):
        if (self.replacer is not None):
            v = self.replacer(k,v)
        _g = Type.typeof(v)
        _g1 = _g.index
        if (_g1 == 0):
            self.buf.b.write("null")
        elif (_g1 == 1):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (_g1 == 2):
            v1 = None
            f = v
            if (((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f))):
                v1 = v
            else:
                v1 = "null"
            _this1 = self.buf
            s1 = Std.string(v1)
            _this1.b.write(s1)
        elif (_g1 == 3):
            _this2 = self.buf
            s2 = Std.string(v)
            _this2.b.write(s2)
        elif (_g1 == 4):
            self.fieldsString(v,python_Boot.fields(v))
        elif (_g1 == 5):
            self.buf.b.write("\"<fun>\"")
        elif (_g1 == 6):
            c = _g.params[0]
            if (c == str):
                self.quote(v)
            elif (c == list):
                v2 = v
                _this3 = self.buf
                s3 = "".join(map(chr,[91]))
                _this3.b.write(s3)
                _hx_len = len(v2)
                last = (_hx_len - 1)
                _g11 = 0
                _g2 = _hx_len
                while (_g11 < _g2):
                    i = _g11
                    _g11 = (_g11 + 1)
                    if (i > 0):
                        _this4 = self.buf
                        s4 = "".join(map(chr,[44]))
                        _this4.b.write(s4)
                    else:
                        _hx_local_0 = self
                        _hx_local_1 = _hx_local_0.nind
                        _hx_local_0.nind = (_hx_local_1 + 1)
                        _hx_local_1
                    if self.pretty:
                        _this5 = self.buf
                        s5 = "".join(map(chr,[10]))
                        _this5.b.write(s5)
                    if self.pretty:
                        v3 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                        _this6 = self.buf
                        s6 = Std.string(v3)
                        _this6.b.write(s6)
                    self.write(i,(v2[i] if i >= 0 and i < len(v2) else None))
                    if (i == last):
                        _hx_local_2 = self
                        _hx_local_3 = _hx_local_2.nind
                        _hx_local_2.nind = (_hx_local_3 - 1)
                        _hx_local_3
                        if self.pretty:
                            _this7 = self.buf
                            s7 = "".join(map(chr,[10]))
                            _this7.b.write(s7)
                        if self.pretty:
                            v4 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                            _this8 = self.buf
                            s8 = Std.string(v4)
                            _this8.b.write(s8)
                _this9 = self.buf
                s9 = "".join(map(chr,[93]))
                _this9.b.write(s9)
            elif (c == haxe_ds_StringMap):
                v5 = v
                o = _hx_AnonObject({})
                k1 = v5.keys()
                while k1.hasNext():
                    k2 = k1.next()
                    value = v5.h.get(k2,None)
                    setattr(o,(("_hx_" + k2) if ((k2 in python_Boot.keywords)) else (("_hx_" + k2) if (((((len(k2) > 2) and ((ord(k2[0]) == 95))) and ((ord(k2[1]) == 95))) and ((ord(k2[(len(k2) - 1)]) != 95)))) else k2)),value)
                self.fieldsString(o,python_Boot.fields(o))
            elif (c == Date):
                v6 = v
                self.quote(v6.toString())
            else:
                self.fieldsString(v,python_Boot.fields(v))
        elif (_g1 == 7):
            i1 = v.index
            _this10 = self.buf
            s10 = Std.string(i1)
            _this10.b.write(s10)
        elif (_g1 == 8):
            self.buf.b.write("\"???\"")
        else:
            pass

    def fieldsString(self,v,fields):
        _this = self.buf
        s = "".join(map(chr,[123]))
        _this.b.write(s)
        _hx_len = len(fields)
        last = (_hx_len - 1)
        first = True
        _g1 = 0
        _g = _hx_len
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            f = (fields[i] if i >= 0 and i < len(fields) else None)
            value = Reflect.field(v,f)
            if Reflect.isFunction(value):
                continue
            if first:
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.nind
                _hx_local_0.nind = (_hx_local_1 + 1)
                _hx_local_1
                first = False
            else:
                _this1 = self.buf
                s1 = "".join(map(chr,[44]))
                _this1.b.write(s1)
            if self.pretty:
                _this2 = self.buf
                s2 = "".join(map(chr,[10]))
                _this2.b.write(s2)
            if self.pretty:
                v1 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                _this3 = self.buf
                s3 = Std.string(v1)
                _this3.b.write(s3)
            self.quote(f)
            _this4 = self.buf
            s4 = "".join(map(chr,[58]))
            _this4.b.write(s4)
            if self.pretty:
                _this5 = self.buf
                s5 = "".join(map(chr,[32]))
                _this5.b.write(s5)
            self.write(f,value)
            if (i == last):
                _hx_local_2 = self
                _hx_local_3 = _hx_local_2.nind
                _hx_local_2.nind = (_hx_local_3 - 1)
                _hx_local_3
                if self.pretty:
                    _this6 = self.buf
                    s6 = "".join(map(chr,[10]))
                    _this6.b.write(s6)
                if self.pretty:
                    v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                    _this7 = self.buf
                    s7 = Std.string(v2)
                    _this7.b.write(s7)
        _this8 = self.buf
        s8 = "".join(map(chr,[125]))
        _this8.b.write(s8)

    def quote(self,s):
        _this = self.buf
        s1 = "".join(map(chr,[34]))
        _this.b.write(s1)
        i = 0
        while True:
            index = i
            i = (i + 1)
            c = (-1 if ((index >= len(s))) else ord(s[index]))
            if (c == -1):
                break
            c1 = c
            if (c1 == 8):
                self.buf.b.write("\\b")
            elif (c1 == 9):
                self.buf.b.write("\\t")
            elif (c1 == 10):
                self.buf.b.write("\\n")
            elif (c1 == 12):
                self.buf.b.write("\\f")
            elif (c1 == 13):
                self.buf.b.write("\\r")
            elif (c1 == 34):
                self.buf.b.write("\\\"")
            elif (c1 == 92):
                self.buf.b.write("\\\\")
            else:
                _this1 = self.buf
                s2 = "".join(map(chr,[c]))
                _this1.b.write(s2)
        _this2 = self.buf
        s3 = "".join(map(chr,[34]))
        _this2.b.write(s3)

    @staticmethod
    def print(o,replacer = None,space = None):
        printer = haxe_format_JsonPrinter(replacer,space)
        printer.write("",o)
        return printer.buf.b.getvalue()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.buf = None
        _hx_o.replacer = None
        _hx_o.indent = None
        _hx_o.pretty = None
        _hx_o.nind = None
haxe_format_JsonPrinter._hx_class = haxe_format_JsonPrinter
_hx_classes["haxe.format.JsonPrinter"] = haxe_format_JsonPrinter


class haxe_io_ArrayBufferViewImpl:
    _hx_class_name = "haxe.io.ArrayBufferViewImpl"
    __slots__ = ()
haxe_io_ArrayBufferViewImpl._hx_class = haxe_io_ArrayBufferViewImpl
_hx_classes["haxe.io.ArrayBufferViewImpl"] = haxe_io_ArrayBufferViewImpl


class haxe_io_BytesBuffer:
    _hx_class_name = "haxe.io.BytesBuffer"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["getBytes"]

    def __init__(self):
        self.b = list()

    def getBytes(self):
        buf = bytearray(self.b)
        _hx_bytes = haxe_io_Bytes(len(buf),buf)
        self.b = None
        return _hx_bytes

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
        _hx_o.length = None
haxe_io_BytesBuffer._hx_class = haxe_io_BytesBuffer
_hx_classes["haxe.io.BytesBuffer"] = haxe_io_BytesBuffer


class haxe_io_Input:
    _hx_class_name = "haxe.io.Input"
    __slots__ = ("bigEndian",)
    _hx_fields = ["bigEndian"]
    _hx_methods = ["readByte", "readBytes", "set_bigEndian", "read", "readUntil", "readUInt16"]

    def readByte(self):
        raise _HxException("Not implemented")

    def readBytes(self,s,pos,_hx_len):
        k = _hx_len
        b = s.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        try:
            while (k > 0):
                b[pos] = self.readByte()
                pos = (pos + 1)
                k = (k - 1)
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            if isinstance(_hx_e1, haxe_io_Eof):
                    pass
            else:
                raise _hx_e
        return (_hx_len - k)

    def set_bigEndian(self,b):
        self.bigEndian = b
        return b

    def read(self,nbytes):
        s = haxe_io_Bytes.alloc(nbytes)
        p = 0
        while (nbytes > 0):
            k = self.readBytes(s,p,nbytes)
            if (k == 0):
                raise _HxException(haxe_io_Error.Blocked)
            p = (p + k)
            nbytes = (nbytes - k)
        return s

    def readUntil(self,end):
        buf = haxe_io_BytesBuffer()
        last = None
        while True:
            last = self.readByte()
            if (not ((last != end))):
                break
            _this = buf.b
            _this.append(last)
        return buf.getBytes().toString()

    def readUInt16(self):
        ch1 = self.readByte()
        ch2 = self.readByte()
        if self.bigEndian:
            return (ch2 | ((ch1 << 8)))
        else:
            return (ch1 | ((ch2 << 8)))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.bigEndian = None
haxe_io_Input._hx_class = haxe_io_Input
_hx_classes["haxe.io.Input"] = haxe_io_Input


class haxe_io_Output:
    _hx_class_name = "haxe.io.Output"
    __slots__ = ("bigEndian",)
    _hx_fields = ["bigEndian"]
    _hx_methods = ["writeByte", "writeBytes", "set_bigEndian", "writeFullBytes"]

    def writeByte(self,c):
        raise _HxException("Not implemented")

    def writeBytes(self,s,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        b = s.b
        k = _hx_len
        while (k > 0):
            self.writeByte(b[pos])
            pos = (pos + 1)
            k = (k - 1)
        return _hx_len

    def set_bigEndian(self,b):
        self.bigEndian = b
        return b

    def writeFullBytes(self,s,pos,_hx_len):
        while (_hx_len > 0):
            k = self.writeBytes(s,pos,_hx_len)
            pos = (pos + k)
            _hx_len = (_hx_len - k)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.bigEndian = None
haxe_io_Output._hx_class = haxe_io_Output
_hx_classes["haxe.io.Output"] = haxe_io_Output


class haxe_io_BytesOutput(haxe_io_Output):
    _hx_class_name = "haxe.io.BytesOutput"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["writeByte", "writeBytes", "getBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self):
        self.b = haxe_io_BytesBuffer()
        self.set_bigEndian(False)

    def writeByte(self,c):
        _this = self.b.b
        _this.append(c)

    def writeBytes(self,buf,pos,_hx_len):
        _this = self.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > buf.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        b1 = _this.b
        b2 = buf.b
        _g1 = pos
        _g = (pos + _hx_len)
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            _this1 = _this.b
            _this1.append(b2[i])
        return _hx_len

    def getBytes(self):
        return self.b.getBytes()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
        _hx_o.length = None
haxe_io_BytesOutput._hx_class = haxe_io_BytesOutput
_hx_classes["haxe.io.BytesOutput"] = haxe_io_BytesOutput


class haxe_io_Eof:
    _hx_class_name = "haxe.io.Eof"
    __slots__ = ()
    _hx_methods = ["toString"]

    def __init__(self):
        pass

    def toString(self):
        return "Eof"

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_io_Eof._hx_class = haxe_io_Eof
_hx_classes["haxe.io.Eof"] = haxe_io_Eof

class haxe_io_Error(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Error"
    _hx_constructs = ["Blocked", "Overflow", "OutsideBounds", "Custom"]

    @staticmethod
    def Custom(e):
        return haxe_io_Error("Custom", 3, [e])
haxe_io_Error.Blocked = haxe_io_Error("Blocked", 0, list())
haxe_io_Error.Overflow = haxe_io_Error("Overflow", 1, list())
haxe_io_Error.OutsideBounds = haxe_io_Error("OutsideBounds", 2, list())
haxe_io_Error._hx_class = haxe_io_Error
_hx_classes["haxe.io.Error"] = haxe_io_Error

class haxe_zip_Huffman(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.zip.Huffman"
    _hx_constructs = ["Found", "NeedBit", "NeedBits"]

    @staticmethod
    def Found(i):
        return haxe_zip_Huffman("Found", 0, [i])

    @staticmethod
    def NeedBit(left,right):
        return haxe_zip_Huffman("NeedBit", 1, [left,right])

    @staticmethod
    def NeedBits(n,table):
        return haxe_zip_Huffman("NeedBits", 2, [n,table])
haxe_zip_Huffman._hx_class = haxe_zip_Huffman
_hx_classes["haxe.zip.Huffman"] = haxe_zip_Huffman


class haxe_zip_HuffTools:
    _hx_class_name = "haxe.zip.HuffTools"
    __slots__ = ()
    _hx_methods = ["treeDepth", "treeCompress", "treeWalk", "treeMake", "make"]

    def __init__(self):
        pass

    def treeDepth(self,t):
        t1 = t.index
        if (t1 == 0):
            return 0
        elif (t1 == 1):
            b = t.params[1]
            a = t.params[0]
            da = self.treeDepth(a)
            db = self.treeDepth(b)
            return (1 + ((da if ((da < db)) else db)))
        elif (t1 == 2):
            raise _HxException("assert")
        else:
            pass

    def treeCompress(self,t):
        d = self.treeDepth(t)
        if (d == 0):
            return t
        if (d == 1):
            if (t.index == 1):
                b = t.params[1]
                a = t.params[0]
                return haxe_zip_Huffman.NeedBit(self.treeCompress(a),self.treeCompress(b))
            else:
                raise _HxException("assert")
        size = (1 << d)
        table = list()
        _g1 = 0
        _g = size
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            table.append(haxe_zip_Huffman.Found(-1))
        self.treeWalk(table,0,0,d,t)
        return haxe_zip_Huffman.NeedBits(d,table)

    def treeWalk(self,table,p,cd,d,t):
        if (t.index == 1):
            b = t.params[1]
            a = t.params[0]
            if (d > 0):
                self.treeWalk(table,p,(cd + 1),(d - 1),a)
                self.treeWalk(table,(p | ((1 << cd))),(cd + 1),(d - 1),b)
            else:
                python_internal_ArrayImpl._set(table, p, self.treeCompress(t))
        else:
            python_internal_ArrayImpl._set(table, p, self.treeCompress(t))

    def treeMake(self,bits,maxbits,v,_hx_len):
        if (_hx_len > maxbits):
            raise _HxException("Invalid huffman")
        idx = ((v << 5) | _hx_len)
        if (idx in bits.h):
            return haxe_zip_Huffman.Found(bits.h.get(idx,None))
        v = (v << 1)
        _hx_len = (_hx_len + 1)
        return haxe_zip_Huffman.NeedBit(self.treeMake(bits,maxbits,v,_hx_len),self.treeMake(bits,maxbits,(v | 1),_hx_len))

    def make(self,lengths,pos,nlengths,maxbits):
        counts = list()
        tmp = list()
        if (maxbits > 32):
            raise _HxException("Invalid huffman")
        _g1 = 0
        _g = maxbits
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            counts.append(0)
            tmp.append(0)
        _g11 = 0
        _g2 = nlengths
        while (_g11 < _g2):
            i1 = _g11
            _g11 = (_g11 + 1)
            p = python_internal_ArrayImpl._get(lengths, (i1 + pos))
            if (p >= maxbits):
                raise _HxException("Invalid huffman")
            python_internal_ArrayImpl._set(counts, p, ((counts[p] if p >= 0 and p < len(counts) else None) + 1))
        code = 0
        _g12 = 1
        _g3 = (maxbits - 1)
        while (_g12 < _g3):
            i2 = _g12
            _g12 = (_g12 + 1)
            code = ((code + (counts[i2] if i2 >= 0 and i2 < len(counts) else None)) << 1)
            python_internal_ArrayImpl._set(tmp, i2, code)
        bits = haxe_ds_IntMap()
        _g13 = 0
        _g4 = nlengths
        while (_g13 < _g4):
            i3 = _g13
            _g13 = (_g13 + 1)
            l = python_internal_ArrayImpl._get(lengths, (i3 + pos))
            if (l != 0):
                n = python_internal_ArrayImpl._get(tmp, (l - 1))
                python_internal_ArrayImpl._set(tmp, (l - 1), (n + 1))
                bits.set(((n << 5) | l),i3)
        return self.treeCompress(haxe_zip_Huffman.NeedBit(self.treeMake(bits,maxbits,0,1),self.treeMake(bits,maxbits,1,1)))

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_zip_HuffTools._hx_class = haxe_zip_HuffTools
_hx_classes["haxe.zip.HuffTools"] = haxe_zip_HuffTools


class haxe_zip__InflateImpl_Window:
    _hx_class_name = "haxe.zip._InflateImpl.Window"
    __slots__ = ("buffer", "pos", "crc")
    _hx_fields = ["buffer", "pos", "crc"]
    _hx_methods = ["slide", "addBytes", "addByte", "getLastChar", "available", "checksum"]

    def __init__(self,hasCrc):
        self.crc = None
        self.buffer = haxe_io_Bytes.alloc(65536)
        self.pos = 0
        if hasCrc:
            self.crc = haxe_crypto_Adler32()

    def slide(self):
        if (self.crc is not None):
            self.crc.update(self.buffer,0,32768)
        b = haxe_io_Bytes.alloc(65536)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.pos
        _hx_local_0.pos = (_hx_local_1 - 32768)
        _hx_local_0.pos
        b.blit(0,self.buffer,32768,self.pos)
        self.buffer = b

    def addBytes(self,b,p,_hx_len):
        if ((self.pos + _hx_len) > 65536):
            self.slide()
        self.buffer.blit(self.pos,b,p,_hx_len)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.pos
        _hx_local_0.pos = (_hx_local_1 + _hx_len)
        _hx_local_0.pos

    def addByte(self,c):
        if (self.pos == 65536):
            self.slide()
        self.buffer.b[self.pos] = (c & 255)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.pos
        _hx_local_0.pos = (_hx_local_1 + 1)
        _hx_local_1

    def getLastChar(self):
        return self.buffer.b[(self.pos - 1)]

    def available(self):
        return self.pos

    def checksum(self):
        if (self.crc is not None):
            self.crc.update(self.buffer,0,self.pos)
        return self.crc

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.buffer = None
        _hx_o.pos = None
        _hx_o.crc = None
haxe_zip__InflateImpl_Window._hx_class = haxe_zip__InflateImpl_Window
_hx_classes["haxe.zip._InflateImpl.Window"] = haxe_zip__InflateImpl_Window

class haxe_zip__InflateImpl_State(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.zip._InflateImpl.State"
    _hx_constructs = ["Head", "Block", "CData", "Flat", "Crc", "Dist", "DistOne", "Done"]
haxe_zip__InflateImpl_State.Head = haxe_zip__InflateImpl_State("Head", 0, list())
haxe_zip__InflateImpl_State.Block = haxe_zip__InflateImpl_State("Block", 1, list())
haxe_zip__InflateImpl_State.CData = haxe_zip__InflateImpl_State("CData", 2, list())
haxe_zip__InflateImpl_State.Flat = haxe_zip__InflateImpl_State("Flat", 3, list())
haxe_zip__InflateImpl_State.Crc = haxe_zip__InflateImpl_State("Crc", 4, list())
haxe_zip__InflateImpl_State.Dist = haxe_zip__InflateImpl_State("Dist", 5, list())
haxe_zip__InflateImpl_State.DistOne = haxe_zip__InflateImpl_State("DistOne", 6, list())
haxe_zip__InflateImpl_State.Done = haxe_zip__InflateImpl_State("Done", 7, list())
haxe_zip__InflateImpl_State._hx_class = haxe_zip__InflateImpl_State
_hx_classes["haxe.zip._InflateImpl.State"] = haxe_zip__InflateImpl_State


class haxe_zip_InflateImpl:
    _hx_class_name = "haxe.zip.InflateImpl"
    __slots__ = ("nbits", "bits", "state", "final", "huffman", "huffdist", "htools", "len", "dist", "needed", "output", "outpos", "input", "lengths", "window")
    _hx_fields = ["nbits", "bits", "state", "final", "huffman", "huffdist", "htools", "len", "dist", "needed", "output", "outpos", "input", "lengths", "window"]
    _hx_methods = ["buildFixedHuffman", "readBytes", "getBits", "getBit", "getRevBits", "resetBits", "addBytes", "addByte", "addDistOne", "addDist", "applyHuffman", "inflateLengths", "inflateLoop"]
    _hx_statics = ["LEN_EXTRA_BITS_TBL", "LEN_BASE_VAL_TBL", "DIST_EXTRA_BITS_TBL", "DIST_BASE_VAL_TBL", "CODE_LENGTHS_POS", "FIXED_HUFFMAN"]

    def __init__(self,i,header = True,crc = True):
        if (header is None):
            header = True
        if (crc is None):
            crc = True
        self.window = None
        self.lengths = None
        self.input = None
        self.outpos = None
        self.output = None
        self.needed = None
        self.dist = None
        self.len = None
        self.huffdist = None
        self.huffman = None
        self.state = None
        self.bits = None
        self.nbits = None
        self.final = False
        self.htools = haxe_zip_HuffTools()
        self.huffman = self.buildFixedHuffman()
        self.huffdist = None
        self.len = 0
        self.dist = 0
        self.state = (haxe_zip__InflateImpl_State.Head if header else haxe_zip__InflateImpl_State.Block)
        self.input = i
        self.bits = 0
        self.nbits = 0
        self.needed = 0
        self.output = None
        self.outpos = 0
        self.lengths = list()
        _g = 0
        while (_g < 19):
            i1 = _g
            _g = (_g + 1)
            _this = self.lengths
            _this.append(-1)
        self.window = haxe_zip__InflateImpl_Window(crc)

    def buildFixedHuffman(self):
        if (haxe_zip_InflateImpl.FIXED_HUFFMAN is not None):
            return haxe_zip_InflateImpl.FIXED_HUFFMAN
        a = list()
        _g = 0
        while (_g < 288):
            n = _g
            _g = (_g + 1)
            a.append((8 if ((n <= 143)) else (9 if ((n <= 255)) else (7 if ((n <= 279)) else 8))))
        haxe_zip_InflateImpl.FIXED_HUFFMAN = self.htools.make(a,0,288,10)
        return haxe_zip_InflateImpl.FIXED_HUFFMAN

    def readBytes(self,b,pos,_hx_len):
        self.needed = _hx_len
        self.outpos = pos
        self.output = b
        if (_hx_len > 0):
            while self.inflateLoop():
                pass
        return (_hx_len - self.needed)

    def getBits(self,n):
        while (self.nbits < n):
            _hx_local_0 = self
            _hx_local_1 = _hx_local_0.bits
            _hx_local_0.bits = (_hx_local_1 | ((self.input.readByte() << self.nbits)))
            _hx_local_0.bits
            _hx_local_2 = self
            _hx_local_3 = _hx_local_2.nbits
            _hx_local_2.nbits = (_hx_local_3 + 8)
            _hx_local_2.nbits
        b = (self.bits & ((((1 << n)) - 1)))
        _hx_local_4 = self
        _hx_local_5 = _hx_local_4.nbits
        _hx_local_4.nbits = (_hx_local_5 - n)
        _hx_local_4.nbits
        _hx_local_6 = self
        _hx_local_7 = _hx_local_6.bits
        _hx_local_6.bits = (_hx_local_7 >> n)
        _hx_local_6.bits
        return b

    def getBit(self):
        if (self.nbits == 0):
            self.nbits = 8
            self.bits = self.input.readByte()
        b = (((self.bits & 1)) == 1)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.nbits
        _hx_local_0.nbits = (_hx_local_1 - 1)
        _hx_local_1
        _hx_local_2 = self
        _hx_local_3 = _hx_local_2.bits
        _hx_local_2.bits = (_hx_local_3 >> 1)
        _hx_local_2.bits
        return b

    def getRevBits(self,n):
        if (n == 0):
            return 0
        elif self.getBit():
            return ((1 << ((n - 1))) | self.getRevBits((n - 1)))
        else:
            return self.getRevBits((n - 1))

    def resetBits(self):
        self.bits = 0
        self.nbits = 0

    def addBytes(self,b,p,_hx_len):
        self.window.addBytes(b,p,_hx_len)
        self.output.blit(self.outpos,b,p,_hx_len)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.needed
        _hx_local_0.needed = (_hx_local_1 - _hx_len)
        _hx_local_0.needed
        _hx_local_2 = self
        _hx_local_3 = _hx_local_2.outpos
        _hx_local_2.outpos = (_hx_local_3 + _hx_len)
        _hx_local_2.outpos

    def addByte(self,b):
        self.window.addByte(b)
        self.output.b[self.outpos] = (b & 255)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.needed
        _hx_local_0.needed = (_hx_local_1 - 1)
        _hx_local_1
        _hx_local_2 = self
        _hx_local_3 = _hx_local_2.outpos
        _hx_local_2.outpos = (_hx_local_3 + 1)
        _hx_local_3

    def addDistOne(self,n):
        c = self.window.getLastChar()
        _g1 = 0
        _g = n
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            self.addByte(c)

    def addDist(self,d,_hx_len):
        self.addBytes(self.window.buffer,(self.window.pos - d),_hx_len)

    def applyHuffman(self,h):
        h1 = h.index
        if (h1 == 0):
            n = h.params[0]
            return n
        elif (h1 == 1):
            b = h.params[1]
            a = h.params[0]
            return self.applyHuffman((b if (self.getBit()) else a))
        elif (h1 == 2):
            tbl = h.params[1]
            n1 = h.params[0]
            return self.applyHuffman(python_internal_ArrayImpl._get(tbl, self.getBits(n1)))
        else:
            pass

    def inflateLengths(self,a,_hx_max):
        i = 0
        prev = 0
        while (i < _hx_max):
            n = self.applyHuffman(self.huffman)
            n1 = n
            if ((((((((((((((((n1 == 15) or ((n1 == 14))) or ((n1 == 13))) or ((n1 == 12))) or ((n1 == 11))) or ((n1 == 10))) or ((n1 == 9))) or ((n1 == 8))) or ((n1 == 7))) or ((n1 == 6))) or ((n1 == 5))) or ((n1 == 4))) or ((n1 == 3))) or ((n1 == 2))) or ((n1 == 1))) or ((n1 == 0))):
                prev = n
                python_internal_ArrayImpl._set(a, i, n)
                i = (i + 1)
            elif (n1 == 16):
                end = ((i + 3) + self.getBits(2))
                if (end > _hx_max):
                    raise _HxException("Invalid data")
                while (i < end):
                    python_internal_ArrayImpl._set(a, i, prev)
                    i = (i + 1)
            elif (n1 == 17):
                i = (i + ((3 + self.getBits(3))))
                if (i > _hx_max):
                    raise _HxException("Invalid data")
            elif (n1 == 18):
                i = (i + ((11 + self.getBits(7))))
                if (i > _hx_max):
                    raise _HxException("Invalid data")
            else:
                raise _HxException("Invalid data")

    def inflateLoop(self):
        _g = self.state
        _g1 = _g.index
        if (_g1 == 0):
            cmf = self.input.readByte()
            cm = (cmf & 15)
            cinfo = (cmf >> 4)
            if (cm != 8):
                raise _HxException("Invalid data")
            flg = self.input.readByte()
            fdict = (((flg & 32)) != 0)
            if (HxOverrides.mod(((((cmf << 8)) + flg)), 31) != 0):
                raise _HxException("Invalid data")
            if fdict:
                raise _HxException("Unsupported dictionary")
            self.state = haxe_zip__InflateImpl_State.Block
            return True
        elif (_g1 == 1):
            self.final = self.getBit()
            _g2 = self.getBits(2)
            _g3 = _g2
            if (_g3 == 0):
                self.len = self.input.readUInt16()
                nlen = self.input.readUInt16()
                if (nlen != ((65535 - self.len))):
                    raise _HxException("Invalid data")
                self.state = haxe_zip__InflateImpl_State.Flat
                r = self.inflateLoop()
                self.resetBits()
                return r
            elif (_g3 == 1):
                self.huffman = self.buildFixedHuffman()
                self.huffdist = None
                self.state = haxe_zip__InflateImpl_State.CData
                return True
            elif (_g3 == 2):
                hlit = (self.getBits(5) + 257)
                hdist = (self.getBits(5) + 1)
                hclen = (self.getBits(4) + 4)
                _g11 = 0
                _g4 = hclen
                while (_g11 < _g4):
                    i = _g11
                    _g11 = (_g11 + 1)
                    python_internal_ArrayImpl._set(self.lengths, python_internal_ArrayImpl._get(haxe_zip_InflateImpl.CODE_LENGTHS_POS, i), self.getBits(3))
                _g5 = hclen
                while (_g5 < 19):
                    i1 = _g5
                    _g5 = (_g5 + 1)
                    python_internal_ArrayImpl._set(self.lengths, python_internal_ArrayImpl._get(haxe_zip_InflateImpl.CODE_LENGTHS_POS, i1), 0)
                self.huffman = self.htools.make(self.lengths,0,19,8)
                lengths = list()
                _g12 = 0
                _g6 = (hlit + hdist)
                while (_g12 < _g6):
                    i2 = _g12
                    _g12 = (_g12 + 1)
                    lengths.append(0)
                self.inflateLengths(lengths,(hlit + hdist))
                self.huffdist = self.htools.make(lengths,hlit,hdist,16)
                self.huffman = self.htools.make(lengths,0,hlit,16)
                self.state = haxe_zip__InflateImpl_State.CData
                return True
            else:
                raise _HxException("Invalid data")
        elif (_g1 == 2):
            n = self.applyHuffman(self.huffman)
            if (n < 256):
                self.addByte(n)
                return (self.needed > 0)
            elif (n == 256):
                self.state = (haxe_zip__InflateImpl_State.Crc if (self.final) else haxe_zip__InflateImpl_State.Block)
                return True
            else:
                n = (n - 257)
                extra_bits = python_internal_ArrayImpl._get(haxe_zip_InflateImpl.LEN_EXTRA_BITS_TBL, n)
                if (extra_bits == -1):
                    raise _HxException("Invalid data")
                self.len = (python_internal_ArrayImpl._get(haxe_zip_InflateImpl.LEN_BASE_VAL_TBL, n) + self.getBits(extra_bits))
                dist_code = (self.getRevBits(5) if ((self.huffdist is None)) else self.applyHuffman(self.huffdist))
                extra_bits = python_internal_ArrayImpl._get(haxe_zip_InflateImpl.DIST_EXTRA_BITS_TBL, dist_code)
                if (extra_bits == -1):
                    raise _HxException("Invalid data")
                self.dist = (python_internal_ArrayImpl._get(haxe_zip_InflateImpl.DIST_BASE_VAL_TBL, dist_code) + self.getBits(extra_bits))
                if (self.dist > self.window.available()):
                    raise _HxException("Invalid data")
                self.state = (haxe_zip__InflateImpl_State.DistOne if ((self.dist == 1)) else haxe_zip__InflateImpl_State.Dist)
                return True
        elif (_g1 == 3):
            rlen = (self.len if ((self.len < self.needed)) else self.needed)
            _hx_bytes = self.input.read(rlen)
            _hx_local_1 = self
            _hx_local_2 = _hx_local_1.len
            _hx_local_1.len = (_hx_local_2 - rlen)
            _hx_local_1.len
            self.addBytes(_hx_bytes,0,rlen)
            if (self.len == 0):
                self.state = (haxe_zip__InflateImpl_State.Crc if (self.final) else haxe_zip__InflateImpl_State.Block)
            return (self.needed > 0)
        elif (_g1 == 4):
            calc = self.window.checksum()
            if (calc is None):
                self.state = haxe_zip__InflateImpl_State.Done
                return True
            crc = haxe_crypto_Adler32.read(self.input)
            if (not calc.equals(crc)):
                raise _HxException("Invalid CRC")
            self.state = haxe_zip__InflateImpl_State.Done
            return True
        elif (_g1 == 5):
            while ((self.len > 0) and ((self.needed > 0))):
                rdist = (self.len if ((self.len < self.dist)) else self.dist)
                rlen1 = (self.needed if ((self.needed < rdist)) else rdist)
                self.addDist(self.dist,rlen1)
                _hx_local_3 = self
                _hx_local_4 = _hx_local_3.len
                _hx_local_3.len = (_hx_local_4 - rlen1)
                _hx_local_3.len
            if (self.len == 0):
                self.state = haxe_zip__InflateImpl_State.CData
            return (self.needed > 0)
        elif (_g1 == 6):
            rlen2 = (self.len if ((self.len < self.needed)) else self.needed)
            self.addDistOne(rlen2)
            _hx_local_5 = self
            _hx_local_6 = _hx_local_5.len
            _hx_local_5.len = (_hx_local_6 - rlen2)
            _hx_local_5.len
            if (self.len == 0):
                self.state = haxe_zip__InflateImpl_State.CData
            return (self.needed > 0)
        elif (_g1 == 7):
            return False
        else:
            pass

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.nbits = None
        _hx_o.bits = None
        _hx_o.state = None
        _hx_o.final = None
        _hx_o.huffman = None
        _hx_o.huffdist = None
        _hx_o.htools = None
        _hx_o.len = None
        _hx_o.dist = None
        _hx_o.needed = None
        _hx_o.output = None
        _hx_o.outpos = None
        _hx_o.input = None
        _hx_o.lengths = None
        _hx_o.window = None
haxe_zip_InflateImpl._hx_class = haxe_zip_InflateImpl
_hx_classes["haxe.zip.InflateImpl"] = haxe_zip_InflateImpl


class hx_strings_CharPos:
    _hx_class_name = "hx.strings.CharPos"
    __slots__ = ()
hx_strings_CharPos._hx_class = hx_strings_CharPos
_hx_classes["hx.strings.CharPos"] = hx_strings_CharPos


class hx_strings_Pattern:
    _hx_class_name = "hx.strings.Pattern"
    __slots__ = ("pattern", "options", "ereg")
    _hx_fields = ["pattern", "options", "ereg"]
    _hx_statics = ["__meta__", "compile"]

    def __init__(self,pattern,options):
        self.pattern = pattern
        self.options = options
        self.ereg = EReg(pattern,options)
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.options
        _hx_local_0.options = (("null" if _hx_local_1 is None else _hx_local_1) + "u")
        _hx_local_0.options

    @staticmethod
    def compile(pattern,options = None):
        if (options is None):
            return hx_strings_Pattern(pattern,"")
        _g = options
        tmp = None
        _g1 = _g.index
        if (_g1 == 0):
            _hx_str = _g.params[0]
            str1 = hx_strings_Strings.toLowerCase8(_hx_str)
            if ((str1 is None) or ((len(str1) == 0))):
                tmp = str1
            else:
                def _hx_local_0(ch):
                    return "".join(map(chr,[ch]))
                def _hx_local_1(ch1):
                    _this1 = None
                    strLen = len("i")
                    if (not ((ch1 == ((-1 if (((strLen == 0) or ((0 >= strLen)))) else HxString.charCodeAt("i",0)))))):
                        strLen1 = len("m")
                        _this1 = (ch1 == ((-1 if (((strLen1 == 0) or ((0 >= strLen1)))) else HxString.charCodeAt("m",0))))
                    else:
                        _this1 = True
                    if (not _this1):
                        strLen2 = len("g")
                        return (ch1 == ((-1 if (((strLen2 == 0) or ((0 >= strLen2)))) else HxString.charCodeAt("g",0))))
                    else:
                        return True
                _this = list(map(_hx_local_0,list(filter(_hx_local_1,hx_strings_Strings.toChars(str1)))))
                tmp = "".join([python_Boot.toString1(x1,'') for x1 in _this])
        elif (_g1 == 1):
            opt = _g.params[0]
            str2 = Std.string(opt)
            if (str2 is None):
                tmp = "null"
            else:
                tmp = str2
        elif (_g1 == 2):
            arr = _g.params[0]
            def _hx_local_2(m):
                return (m is not None)
            _this2 = list(filter(_hx_local_2,arr))
            tmp = "".join([python_Boot.toString1(x1,'') for x1 in _this2])
        else:
            pass
        return hx_strings_Pattern(pattern,tmp)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.pattern = None
        _hx_o.options = None
        _hx_o.ereg = None
hx_strings_Pattern._hx_class = hx_strings_Pattern
_hx_classes["hx.strings.Pattern"] = hx_strings_Pattern


class hx_strings_Matcher:
    _hx_class_name = "hx.strings.Matcher"
    __slots__ = ()
    _hx_methods = ["matched", "matches"]
    _hx_statics = ["__meta__"]
hx_strings_Matcher._hx_class = hx_strings_Matcher
_hx_classes["hx.strings.Matcher"] = hx_strings_Matcher


class hx_strings__Pattern_MatcherImpl:
    _hx_class_name = "hx.strings._Pattern.MatcherImpl"
    __slots__ = ("isMatch", "ereg", "str")
    _hx_fields = ["isMatch", "ereg", "str"]
    _hx_methods = ["matched", "matches", "_cloneEReg"]
    _hx_interfaces = [hx_strings_Matcher]

    def __init__(self,ereg,pattern,options,_hx_str):
        self.str = None
        self.ereg = None
        self.isMatch = None
        self.ereg = self._cloneEReg(ereg,pattern,options)
        self.str = _hx_str
        self.isMatch = None

    def matched(self,n = 0):
        if (n is None):
            n = 0
        if (self.isMatch is None):
            _this = self.ereg
            _this.matchObj = python_lib_Re.search(_this.pattern,self.str)
            self.isMatch = (_this.matchObj is not None)
        if (not self.isMatch):
            raise _HxException("No string matched")
        result = self.ereg.matchObj.group(n)
        return result

    def matches(self):
        _this = self.ereg
        _this.matchObj = python_lib_Re.search(_this.pattern,self.str)
        def _hx_local_1():
            def _hx_local_0():
                self.isMatch = (_this.matchObj is not None)
                return self.isMatch
            return _hx_local_0()
        return _hx_local_1()

    def _cloneEReg(self,_hx_from,pattern,options):
        clone = Type.createEmptyInstance(EReg)
        value = Reflect.field(_hx_from,"pattern")
        setattr(clone,(("_hx_" + "pattern") if (("pattern" in python_Boot.keywords)) else (("_hx_" + "pattern") if (((((len("pattern") > 2) and ((ord("pattern"[0]) == 95))) and ((ord("pattern"[1]) == 95))) and ((ord("pattern"[(len("pattern") - 1)]) != 95)))) else "pattern")),value)
        value1 = Reflect.field(_hx_from,"global")
        setattr(clone,(("_hx_" + "global") if (("global" in python_Boot.keywords)) else (("_hx_" + "global") if (((((len("global") > 2) and ((ord("global"[0]) == 95))) and ((ord("global"[1]) == 95))) and ((ord("global"[(len("global") - 1)]) != 95)))) else "global")),value1)
        return clone

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.isMatch = None
        _hx_o.ereg = None
        _hx_o.str = None
hx_strings__Pattern_MatcherImpl._hx_class = hx_strings__Pattern_MatcherImpl
_hx_classes["hx.strings._Pattern.MatcherImpl"] = hx_strings__Pattern_MatcherImpl


class HxString:
    _hx_class_name = "HxString"
    __slots__ = ()
    _hx_statics = ["split", "charCodeAt", "charAt", "lastIndexOf", "toUpperCase", "toLowerCase", "indexOf", "toString", "substring", "substr"]

    @staticmethod
    def split(s,d):
        if (d == ""):
            return list(s)
        else:
            return s.split(d)

    @staticmethod
    def charCodeAt(s,index):
        if ((((s is None) or ((len(s) == 0))) or ((index < 0))) or ((index >= len(s)))):
            return None
        else:
            return ord(s[index])

    @staticmethod
    def charAt(s,index):
        if ((index < 0) or ((index >= len(s)))):
            return ""
        else:
            return s[index]

    @staticmethod
    def lastIndexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.rfind(_hx_str, 0, len(s))
        else:
            i = s.rfind(_hx_str, 0, (startIndex + 1))
            startLeft = (max(0,((startIndex + 1) - len(_hx_str))) if ((i == -1)) else (i + 1))
            check = s.find(_hx_str, startLeft, len(s))
            if ((check > i) and ((check <= startIndex))):
                return check
            else:
                return i

    @staticmethod
    def toUpperCase(s):
        return s.upper()

    @staticmethod
    def toLowerCase(s):
        return s.lower()

    @staticmethod
    def indexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.find(_hx_str)
        else:
            return s.find(_hx_str, startIndex)

    @staticmethod
    def toString(s):
        return s

    @staticmethod
    def substring(s,startIndex,endIndex = None):
        if (startIndex < 0):
            startIndex = 0
        if (endIndex is None):
            return s[startIndex:]
        else:
            if (endIndex < 0):
                endIndex = 0
            if (endIndex < startIndex):
                return s[endIndex:startIndex]
            else:
                return s[startIndex:endIndex]

    @staticmethod
    def substr(s,startIndex,_hx_len = None):
        if (_hx_len is None):
            return s[startIndex:]
        else:
            if (_hx_len == 0):
                return ""
            return s[startIndex:(startIndex + _hx_len)]
HxString._hx_class = HxString
_hx_classes["HxString"] = HxString


class python_Boot:
    _hx_class_name = "python.Boot"
    __slots__ = ()
    _hx_statics = ["keywords", "toString1", "fields", "simpleField", "field", "getInstanceFields", "getSuperClass", "getClassFields", "prefixLength", "unhandleKeywords"]

    @staticmethod
    def toString1(o,s):
        if (o is None):
            return "null"
        if isinstance(o,str):
            return o
        if (s is None):
            s = ""
        if (len(s) >= 5):
            return "<...>"
        if isinstance(o,bool):
            if o:
                return "true"
            else:
                return "false"
        if isinstance(o,int):
            return str(o)
        if isinstance(o,float):
            try:
                if (o == int(o)):
                    return str(Math.floor((o + 0.5)))
                else:
                    return str(o)
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                e = _hx_e1
                return str(o)
        if isinstance(o,list):
            o1 = o
            l = len(o1)
            st = "["
            s = (("null" if s is None else s) + "\t")
            _g1 = 0
            _g = l
            while (_g1 < _g):
                i = _g1
                _g1 = (_g1 + 1)
                prefix = ""
                if (i > 0):
                    prefix = ","
                st = (("null" if st is None else st) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1((o1[i] if i >= 0 and i < len(o1) else None),s))))))
            st = (("null" if st is None else st) + "]")
            return st
        try:
            if hasattr(o,"toString"):
                return o.toString()
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            pass
        if (python_lib_Inspect.isfunction(o) or python_lib_Inspect.ismethod(o)):
            return "<function>"
        if hasattr(o,"__class__"):
            if isinstance(o,_hx_AnonObject):
                toStr = None
                try:
                    fields = python_Boot.fields(o)
                    _g2 = []
                    _g11 = 0
                    while (_g11 < len(fields)):
                        f = (fields[_g11] if _g11 >= 0 and _g11 < len(fields) else None)
                        _g11 = (_g11 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g2.append(x)
                    fieldsStr = _g2
                    toStr = (("{ " + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " }")
                except Exception as _hx_e:
                    _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                    e2 = _hx_e1
                    return "{ ... }"
                if (toStr is None):
                    return "{ ... }"
                else:
                    return toStr
            if isinstance(o,Enum):
                o2 = o
                l1 = len(o2.params)
                hasParams = (l1 > 0)
                if hasParams:
                    paramsStr = ""
                    _g12 = 0
                    _g3 = l1
                    while (_g12 < _g3):
                        i1 = _g12
                        _g12 = (_g12 + 1)
                        prefix1 = ""
                        if (i1 > 0):
                            prefix1 = ","
                        paramsStr = (("null" if paramsStr is None else paramsStr) + HxOverrides.stringOrNull(((("null" if prefix1 is None else prefix1) + HxOverrides.stringOrNull(python_Boot.toString1((o2.params[i1] if i1 >= 0 and i1 < len(o2.params) else None),s))))))
                    return (((HxOverrides.stringOrNull(o2.tag) + "(") + ("null" if paramsStr is None else paramsStr)) + ")")
                else:
                    return o2.tag
            if hasattr(o,"_hx_class_name"):
                if (o.__class__.__name__ != "type"):
                    fields1 = python_Boot.getInstanceFields(o)
                    _g4 = []
                    _g13 = 0
                    while (_g13 < len(fields1)):
                        f1 = (fields1[_g13] if _g13 >= 0 and _g13 < len(fields1) else None)
                        _g13 = (_g13 + 1)
                        x1 = ((("" + ("null" if f1 is None else f1)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f1),(("null" if s is None else s) + "\t"))))
                        _g4.append(x1)
                    fieldsStr1 = _g4
                    toStr1 = (((HxOverrides.stringOrNull(o._hx_class_name) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr1]))) + " )")
                    return toStr1
                else:
                    fields2 = python_Boot.getClassFields(o)
                    _g5 = []
                    _g14 = 0
                    while (_g14 < len(fields2)):
                        f2 = (fields2[_g14] if _g14 >= 0 and _g14 < len(fields2) else None)
                        _g14 = (_g14 + 1)
                        x2 = ((("" + ("null" if f2 is None else f2)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f2),(("null" if s is None else s) + "\t"))))
                        _g5.append(x2)
                    fieldsStr2 = _g5
                    toStr2 = (((("#" + HxOverrides.stringOrNull(o._hx_class_name)) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr2]))) + " )")
                    return toStr2
            if (o == str):
                return "#String"
            if (o == list):
                return "#Array"
            if callable(o):
                return "function"
            try:
                if hasattr(o,"__repr__"):
                    return o.__repr__()
            except Exception as _hx_e:
                _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
                pass
            if hasattr(o,"__str__"):
                return o.__str__([])
            if hasattr(o,"__name__"):
                return o.__name__
            return "???"
        else:
            return str(o)

    @staticmethod
    def fields(o):
        a = []
        if (o is not None):
            if hasattr(o,"_hx_fields"):
                fields = o._hx_fields
                return list(fields)
            if isinstance(o,_hx_AnonObject):
                d = o.__dict__
                keys = d.keys()
                handler = python_Boot.unhandleKeywords
                for k in keys:
                    a.append(handler(k))
            elif hasattr(o,"__dict__"):
                d1 = o.__dict__
                keys1 = d1.keys()
                for k in keys1:
                    a.append(k)
        return a

    @staticmethod
    def simpleField(o,field):
        if (field is None):
            return None
        field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
        if hasattr(o,field1):
            return getattr(o,field1)
        else:
            return None

    @staticmethod
    def field(o,field):
        if (field is None):
            return None
        field1 = field
        _hx_local_0 = len(field1)
        if (_hx_local_0 == 10):
            if (field1 == "charCodeAt"):
                if isinstance(o,str):
                    s1 = o
                    def _hx_local_1(a11):
                        return HxString.charCodeAt(s1,a11)
                    return _hx_local_1
        elif (_hx_local_0 == 11):
            if (field1 == "lastIndexOf"):
                if isinstance(o,str):
                    s3 = o
                    def _hx_local_2(a15):
                        return HxString.lastIndexOf(s3,a15)
                    return _hx_local_2
                elif isinstance(o,list):
                    a4 = o
                    def _hx_local_3(x4):
                        return python_internal_ArrayImpl.lastIndexOf(a4,x4)
                    return _hx_local_3
            elif (field1 == "toLowerCase"):
                if isinstance(o,str):
                    s7 = o
                    def _hx_local_4():
                        return HxString.toLowerCase(s7)
                    return _hx_local_4
            elif (field1 == "toUpperCase"):
                if isinstance(o,str):
                    s9 = o
                    def _hx_local_5():
                        return HxString.toUpperCase(s9)
                    return _hx_local_5
        elif (_hx_local_0 == 9):
            if (field1 == "substring"):
                if isinstance(o,str):
                    s6 = o
                    def _hx_local_6(a19):
                        return HxString.substring(s6,a19)
                    return _hx_local_6
        elif (_hx_local_0 == 4):
            if (field1 == "copy"):
                if isinstance(o,list):
                    def _hx_local_7():
                        return list(o)
                    return _hx_local_7
            elif (field1 == "join"):
                if isinstance(o,list):
                    def _hx_local_8(sep):
                        return sep.join([python_Boot.toString1(x1,'') for x1 in o])
                    return _hx_local_8
            elif (field1 == "push"):
                if isinstance(o,list):
                    x7 = o
                    def _hx_local_9(e):
                        return python_internal_ArrayImpl.push(x7,e)
                    return _hx_local_9
            elif (field1 == "sort"):
                if isinstance(o,list):
                    x11 = o
                    def _hx_local_10(f2):
                        python_internal_ArrayImpl.sort(x11,f2)
                    return _hx_local_10
        elif (_hx_local_0 == 5):
            if (field1 == "shift"):
                if isinstance(o,list):
                    x9 = o
                    def _hx_local_11():
                        return python_internal_ArrayImpl.shift(x9)
                    return _hx_local_11
            elif (field1 == "slice"):
                if isinstance(o,list):
                    x10 = o
                    def _hx_local_12(a16):
                        return python_internal_ArrayImpl.slice(x10,a16)
                    return _hx_local_12
            elif (field1 == "split"):
                if isinstance(o,str):
                    s4 = o
                    def _hx_local_13(d):
                        return HxString.split(s4,d)
                    return _hx_local_13
        elif (_hx_local_0 == 7):
            if (field1 == "indexOf"):
                if isinstance(o,str):
                    s2 = o
                    def _hx_local_14(a13):
                        return HxString.indexOf(s2,a13)
                    return _hx_local_14
                elif isinstance(o,list):
                    a = o
                    def _hx_local_15(x1):
                        return python_internal_ArrayImpl.indexOf(a,x1)
                    return _hx_local_15
            elif (field1 == "reverse"):
                if isinstance(o,list):
                    a5 = o
                    def _hx_local_16():
                        python_internal_ArrayImpl.reverse(a5)
                    return _hx_local_16
            elif (field1 == "unshift"):
                if isinstance(o,list):
                    x14 = o
                    def _hx_local_17(e2):
                        python_internal_ArrayImpl.unshift(x14,e2)
                    return _hx_local_17
        elif (_hx_local_0 == 3):
            if (field1 == "map"):
                if isinstance(o,list):
                    x5 = o
                    def _hx_local_18(f1):
                        return python_internal_ArrayImpl.map(x5,f1)
                    return _hx_local_18
            elif (field1 == "pop"):
                if isinstance(o,list):
                    x6 = o
                    def _hx_local_19():
                        return python_internal_ArrayImpl.pop(x6)
                    return _hx_local_19
        elif (_hx_local_0 == 8):
            if (field1 == "iterator"):
                if isinstance(o,list):
                    x3 = o
                    def _hx_local_20():
                        return python_internal_ArrayImpl.iterator(x3)
                    return _hx_local_20
            elif (field1 == "toString"):
                if isinstance(o,str):
                    s8 = o
                    def _hx_local_21():
                        return HxString.toString(s8)
                    return _hx_local_21
                elif isinstance(o,list):
                    x13 = o
                    def _hx_local_22():
                        return python_internal_ArrayImpl.toString(x13)
                    return _hx_local_22
        elif (_hx_local_0 == 6):
            if (field1 == "charAt"):
                if isinstance(o,str):
                    s = o
                    def _hx_local_23(a1):
                        return HxString.charAt(s,a1)
                    return _hx_local_23
            elif (field1 == "concat"):
                if isinstance(o,list):
                    a12 = o
                    def _hx_local_24(a2):
                        return python_internal_ArrayImpl.concat(a12,a2)
                    return _hx_local_24
            elif (field1 == "filter"):
                if isinstance(o,list):
                    x = o
                    def _hx_local_25(f):
                        return python_internal_ArrayImpl.filter(x,f)
                    return _hx_local_25
            elif (field1 == "insert"):
                if isinstance(o,list):
                    a3 = o
                    def _hx_local_26(a14,x2):
                        python_internal_ArrayImpl.insert(a3,a14,x2)
                    return _hx_local_26
            elif (field1 == "length"):
                if isinstance(o,str):
                    return len(o)
                elif isinstance(o,list):
                    return len(o)
            elif (field1 == "remove"):
                if isinstance(o,list):
                    x8 = o
                    def _hx_local_27(e1):
                        return python_internal_ArrayImpl.remove(x8,e1)
                    return _hx_local_27
            elif (field1 == "splice"):
                if isinstance(o,list):
                    x12 = o
                    def _hx_local_28(a17,a21):
                        return python_internal_ArrayImpl.splice(x12,a17,a21)
                    return _hx_local_28
            elif (field1 == "substr"):
                if isinstance(o,str):
                    s5 = o
                    def _hx_local_29(a18):
                        return HxString.substr(s5,a18)
                    return _hx_local_29
        else:
            pass
        field2 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
        if hasattr(o,field2):
            return getattr(o,field2)
        else:
            return None

    @staticmethod
    def getInstanceFields(c):
        f = (c._hx_fields if (hasattr(c,"_hx_fields")) else [])
        if hasattr(c,"_hx_methods"):
            f = (f + c._hx_methods)
        sc = python_Boot.getSuperClass(c)
        if (sc is None):
            return f
        else:
            scArr = python_Boot.getInstanceFields(sc)
            scMap = set(scArr)
            _g = 0
            while (_g < len(f)):
                f1 = (f[_g] if _g >= 0 and _g < len(f) else None)
                _g = (_g + 1)
                if (not (f1 in scMap)):
                    scArr.append(f1)
            return scArr

    @staticmethod
    def getSuperClass(c):
        if (c is None):
            return None
        try:
            if hasattr(c,"_hx_super"):
                return c._hx_super
            return None
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            pass
        return None

    @staticmethod
    def getClassFields(c):
        if hasattr(c,"_hx_statics"):
            x = c._hx_statics
            return list(x)
        else:
            return []

    @staticmethod
    def unhandleKeywords(name):
        if (HxString.substr(name,0,python_Boot.prefixLength) == "_hx_"):
            real = HxString.substr(name,python_Boot.prefixLength,None)
            if (real in python_Boot.keywords):
                return real
        return name
python_Boot._hx_class = python_Boot
_hx_classes["python.Boot"] = python_Boot

class hx_strings_internal__Either3__Either3(Enum):
    __slots__ = ()
    _hx_class_name = "hx.strings.internal._Either3._Either3"
    _hx_constructs = ["a", "b", "c"]

    @staticmethod
    def a(v):
        return hx_strings_internal__Either3__Either3("a", 0, [v])

    @staticmethod
    def b(v):
        return hx_strings_internal__Either3__Either3("b", 1, [v])

    @staticmethod
    def c(v):
        return hx_strings_internal__Either3__Either3("c", 2, [v])
hx_strings_internal__Either3__Either3._hx_class = hx_strings_internal__Either3__Either3
_hx_classes["hx.strings.internal._Either3._Either3"] = hx_strings_internal__Either3__Either3


class hx_strings_Strings:
    _hx_class_name = "hx.strings.Strings"
    __slots__ = ()
    _hx_statics = ["charAt8", "compare", "isDigits", "replaceAll", "substring8", "toChars", "toLowerCase8", "trim", "trimRight", "trimLeft"]

    @staticmethod
    def charAt8(_hx_str,pos,resultIfOutOfBound = ""):
        if (resultIfOutOfBound is None):
            resultIfOutOfBound = ""
        if ((((_hx_str is None) or ((len(_hx_str) == 0))) or ((pos < 0))) or ((pos >= ((0 if ((_hx_str is None)) else len(_hx_str)))))):
            return resultIfOutOfBound
        if ((pos < 0) or ((pos >= len(_hx_str)))):
            return ""
        else:
            return _hx_str[pos]

    @staticmethod
    def compare(_hx_str,other):
        if (_hx_str is None):
            if (other is None):
                return 0
            else:
                return -1
        if (other is None):
            if (_hx_str is None):
                return 0
            else:
                return 1
        return haxe_Utf8.compare(_hx_str,other)

    @staticmethod
    def isDigits(_hx_str):
        if ((_hx_str is None) or ((len(_hx_str) == 0))):
            return False
        _g1 = 0
        _g = (0 if ((_hx_str is None)) else len(_hx_str))
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            this1 = HxString.charCodeAt(_hx_str,i)
            if (not (((this1 > 47) and ((this1 < 58))))):
                return False
        return True

    @staticmethod
    def replaceAll(searchIn,searchFor,replaceWith):
        if (((searchIn is None) or (((searchIn is None) or ((len(searchIn) == 0))))) or ((searchFor is None))):
            return searchIn
        if (replaceWith is None):
            replaceWith = "null"
        return StringTools.replace(searchIn,searchFor,replaceWith)

    @staticmethod
    def substring8(_hx_str,startAt,endAt = None):
        if ((_hx_str is None) or ((len(_hx_str) == 0))):
            return _hx_str
        if (endAt is None):
            if (_hx_str is None):
                endAt = 0
            else:
                endAt = len(_hx_str)
        return HxString.substring(_hx_str,startAt,endAt)

    @staticmethod
    def toChars(_hx_str):
        if (_hx_str is None):
            return None
        strLen = (0 if ((_hx_str is None)) else len(_hx_str))
        if (strLen == 0):
            return []
        _g = []
        _g2 = 0
        _g1 = strLen
        while (_g2 < _g1):
            i = _g2
            _g2 = (_g2 + 1)
            x = HxString.charCodeAt(_hx_str,i)
            _g.append(x)
        return _g

    @staticmethod
    def toLowerCase8(_hx_str):
        if ((_hx_str is None) or ((len(_hx_str) == 0))):
            return _hx_str
        return _hx_str.lower()

    @staticmethod
    def trim(_hx_str,charsToRemove = None):
        if ((_hx_str is None) or ((len(_hx_str) == 0))):
            return _hx_str
        if (charsToRemove is None):
            return StringTools.trim(_hx_str)
        removableChars = None
        _g = charsToRemove
        _g1 = _g.index
        if (_g1 == 0):
            str1 = _g.params[0]
            removableChars = hx_strings_Strings.toChars(str1)
        elif (_g1 == 1):
            chars = _g.params[0]
            removableChars = chars
        else:
            pass
        this1 = hx_strings_internal__Either2__Either2.b(removableChars)
        this2 = hx_strings_internal__Either2__Either2.b(removableChars)
        return hx_strings_Strings.trimLeft(hx_strings_Strings.trimRight(_hx_str,this1),this2)

    @staticmethod
    def trimRight(_hx_str,charsToRemove = None):
        if ((_hx_str is None) or ((len(_hx_str) == 0))):
            return _hx_str
        if (charsToRemove is None):
            return StringTools.rtrim(_hx_str)
        removableChars = None
        _g = charsToRemove
        _g1 = _g.index
        if (_g1 == 0):
            str1 = _g.params[0]
            removableChars = hx_strings_Strings.toChars(str1)
        elif (_g1 == 1):
            chars = _g.params[0]
            removableChars = chars
        else:
            pass
        if (len(removableChars) == 0):
            return _hx_str
        _hx_len = (0 if ((_hx_str is None)) else len(_hx_str))
        i = (_hx_len - 1)
        while True:
            tmp = None
            if (i > -1):
                x = None
                str2 = hx_strings_Strings.charAt8(_hx_str,i)
                strLen = (0 if ((str2 is None)) else len(str2))
                if ((strLen == 0) or ((0 >= strLen))):
                    x = -1
                else:
                    x = HxString.charCodeAt(str2,0)
                tmp = (python_internal_ArrayImpl.indexOf(removableChars,x,None) > -1)
            else:
                tmp = False
            if (not tmp):
                break
            i = (i - 1)
        if (i < ((_hx_len - 1))):
            return hx_strings_Strings.substring8(_hx_str,0,(i + 1))
        return _hx_str

    @staticmethod
    def trimLeft(_hx_str,charsToRemove = None):
        if (_hx_str is None):
            return _hx_str
        if (charsToRemove is None):
            return StringTools.ltrim(_hx_str)
        removableChars = None
        _g = charsToRemove
        _g1 = _g.index
        if (_g1 == 0):
            str1 = _g.params[0]
            removableChars = hx_strings_Strings.toChars(str1)
        elif (_g1 == 1):
            chars = _g.params[0]
            removableChars = chars
        else:
            pass
        if (len(removableChars) == 0):
            return _hx_str
        _hx_len = (0 if ((_hx_str is None)) else len(_hx_str))
        i = 0
        while True:
            tmp = None
            if (i < _hx_len):
                x = None
                str2 = hx_strings_Strings.charAt8(_hx_str,i)
                strLen = (0 if ((str2 is None)) else len(str2))
                if ((strLen == 0) or ((0 >= strLen))):
                    x = -1
                else:
                    x = HxString.charCodeAt(str2,0)
                tmp = (python_internal_ArrayImpl.indexOf(removableChars,x,None) > -1)
            else:
                tmp = False
            if (not tmp):
                break
            i = (i + 1)
        if (i > 0):
            return hx_strings_Strings.substring8(_hx_str,i,_hx_len)
        return _hx_str
hx_strings_Strings._hx_class = hx_strings_Strings
_hx_classes["hx.strings.Strings"] = hx_strings_Strings


class hx_strings__Version_Version_Impl_:
    _hx_class_name = "hx.strings._Version.Version_Impl_"
    __slots__ = ()
    _hx_statics = ["PATTERN_VERSION", "VALIDATOR_METADATA", "VALIDATOR_PRERELEASE", "VALIDATOR_VERSION", "of", "_new", "compareTo"]
    major = None
    minor = None
    patch = None
    preRelease = None
    isPreRelease = None
    buildMetadata = None
    hasBuildMetadata = None

    @staticmethod
    def of(_hx_str):
        if (_hx_str is None):
            return None
        _this = hx_strings__Version_Version_Impl_.VALIDATOR_VERSION
        str1 = hx_strings_Strings.trim(_hx_str)
        m = hx_strings__Pattern_MatcherImpl(_this.ereg,_this.pattern,_this.options,str1)
        if (not m.matches()):
            raise _HxException((((("[" + ("null" if _hx_str is None else _hx_str)) + "] is not a valid ") + "SemVer 2.0.0") + " version string!"))
        preRelease = m.matched(4)
        buildMetadata = m.matched(5)
        result = Std.parseInt(m.matched(1))
        result1 = Std.parseInt(m.matched(2))
        result2 = Std.parseInt(m.matched(3))
        return hx_strings__Version_Version_Impl_._new((None if ((result is None)) else result),(None if ((result1 is None)) else result1),(None if ((result2 is None)) else result2),preRelease,buildMetadata)

    @staticmethod
    def _new(major = 0,minor = 0,patch = 0,preRelease = None,buildMetadata = None):
        if (major is None):
            major = 0
        if (minor is None):
            minor = 0
        if (patch is None):
            patch = 0
        this1 = None
        if (major < 0):
            raise _HxException((((("[" + Std.string(major)) + "] is an invalid ") + "SemVer 2.0.0") + " major level."))
        if (minor < 0):
            raise _HxException((((("[" + Std.string(minor)) + "] is an invalid ") + "SemVer 2.0.0") + " minor level."))
        if (patch < 0):
            raise _HxException((((("[" + Std.string(patch)) + "] is an invalid ") + "SemVer 2.0.0") + " patch level."))
        tmp = None
        if ((preRelease is None) or ((len(preRelease) == 0))):
            tmp = True
        else:
            _this = hx_strings__Version_Version_Impl_.VALIDATOR_PRERELEASE
            tmp = hx_strings__Pattern_MatcherImpl(_this.ereg,_this.pattern,_this.options,preRelease).matches()
        if (not tmp):
            raise _HxException((((("[" + ("null" if preRelease is None else preRelease)) + "] is an invalid ") + "SemVer 2.0.0") + " pre-release string."))
        tmp1 = None
        if ((buildMetadata is None) or ((len(buildMetadata) == 0))):
            tmp1 = True
        else:
            _this1 = hx_strings__Version_Version_Impl_.VALIDATOR_METADATA
            tmp1 = hx_strings__Pattern_MatcherImpl(_this1.ereg,_this1.pattern,_this1.options,buildMetadata).matches()
        if (not tmp1):
            raise _HxException((((("[" + ("null" if buildMetadata is None else buildMetadata)) + "] is an invalid ") + "SemVer 2.0.0") + " metadata string."))
        this1 = hx_strings_VersionData.VersionEnum(major,minor,patch,(None if (((preRelease is None) or ((len(preRelease) == 0)))) else preRelease),(None if (((buildMetadata is None) or ((len(buildMetadata) == 0)))) else buildMetadata))
        return this1

    @staticmethod
    def compareTo(this1,other,ignoreBuildMetadata = True):
        if (ignoreBuildMetadata is None):
            ignoreBuildMetadata = True
        if (other == this1):
            return 0
        if (other is None):
            return 1
        build = this1.params[4]
        pre = this1.params[3]
        pat = this1.params[2]
        _hx_min = this1.params[1]
        maj = this1.params[0]
        build1 = other.params[4]
        pre1 = other.params[3]
        pat1 = other.params[2]
        min1 = other.params[1]
        maj1 = other.params[0]
        if (maj > maj1):
            return 1000
        build2 = this1.params[4]
        pre2 = this1.params[3]
        pat2 = this1.params[2]
        min2 = this1.params[1]
        maj2 = this1.params[0]
        build3 = other.params[4]
        pre3 = other.params[3]
        pat3 = other.params[2]
        min3 = other.params[1]
        maj3 = other.params[0]
        if (maj2 < maj3):
            return -1000
        build4 = this1.params[4]
        pre4 = this1.params[3]
        pat4 = this1.params[2]
        min4 = this1.params[1]
        maj4 = this1.params[0]
        build5 = other.params[4]
        pre5 = other.params[3]
        pat5 = other.params[2]
        min5 = other.params[1]
        maj5 = other.params[0]
        if (min4 > min5):
            return 100
        build6 = this1.params[4]
        pre6 = this1.params[3]
        pat6 = this1.params[2]
        min6 = this1.params[1]
        maj6 = this1.params[0]
        build7 = other.params[4]
        pre7 = other.params[3]
        pat7 = other.params[2]
        min7 = other.params[1]
        maj7 = other.params[0]
        if (min6 < min7):
            return -100
        build8 = this1.params[4]
        pre8 = this1.params[3]
        pat8 = this1.params[2]
        min8 = this1.params[1]
        maj8 = this1.params[0]
        build9 = other.params[4]
        pre9 = other.params[3]
        pat9 = other.params[2]
        min9 = other.params[1]
        maj9 = other.params[0]
        if (pat8 > pat9):
            return 10
        build10 = this1.params[4]
        pre10 = this1.params[3]
        pat10 = this1.params[2]
        min10 = this1.params[1]
        maj10 = this1.params[0]
        build11 = other.params[4]
        pre11 = other.params[3]
        pat11 = other.params[2]
        min11 = other.params[1]
        maj11 = other.params[0]
        if (pat10 < pat11):
            return -10
        build12 = this1.params[4]
        pre12 = this1.params[3]
        pat12 = this1.params[2]
        min12 = this1.params[1]
        maj12 = this1.params[0]
        if (pre12 is not None):
            build13 = other.params[4]
            pre13 = other.params[3]
            pat13 = other.params[2]
            min13 = other.params[1]
            maj13 = other.params[0]
            if (pre13 is None):
                return -1
            build14 = this1.params[4]
            pre14 = this1.params[3]
            pat14 = this1.params[2]
            min14 = this1.params[1]
            maj14 = this1.params[0]
            build15 = other.params[4]
            pre15 = other.params[3]
            pat15 = other.params[2]
            min15 = other.params[1]
            maj15 = other.params[0]
            if (pre14 != pre15):
                build16 = this1.params[4]
                pre16 = this1.params[3]
                pat16 = this1.params[2]
                min16 = this1.params[1]
                maj16 = this1.params[0]
                _this = pre16
                left = _this.split(".")
                build17 = other.params[4]
                pre17 = other.params[3]
                pat17 = other.params[2]
                min17 = other.params[1]
                maj17 = other.params[0]
                _this1 = pre17
                right = _this1.split(".")
                count = (len(left) if ((len(left) < len(right))) else len(right))
                _g1 = 0
                _g = count
                while (_g1 < _g):
                    i = _g1
                    _g1 = (_g1 + 1)
                    leftId = (left[i] if i >= 0 and i < len(left) else None)
                    rightId = (right[i] if i >= 0 and i < len(right) else None)
                    if (leftId == rightId):
                        continue
                    if (hx_strings_Strings.isDigits(leftId) and hx_strings_Strings.isDigits(rightId)):
                        result = Std.parseInt(leftId)
                        result1 = Std.parseInt(rightId)
                        if (((None if ((result is None)) else result)) < ((None if ((result1 is None)) else result1))):
                            return -1
                        else:
                            return 1
                    return hx_strings_Strings.compare(leftId,rightId)
                if (len(left) > count):
                    return 1
                if (len(right) > count):
                    return -1
        else:
            build18 = other.params[4]
            pre18 = other.params[3]
            pat18 = other.params[2]
            min18 = other.params[1]
            maj18 = other.params[0]
            if (pre18 is not None):
                return 1
        if (not ignoreBuildMetadata):
            build19 = this1.params[4]
            pre19 = this1.params[3]
            pat19 = this1.params[2]
            min19 = this1.params[1]
            maj19 = this1.params[0]
            build20 = other.params[4]
            pre20 = other.params[3]
            pat20 = other.params[2]
            min20 = other.params[1]
            maj20 = other.params[0]
            return hx_strings_Strings.compare(build19,build20)
        return 0
hx_strings__Version_Version_Impl_._hx_class = hx_strings__Version_Version_Impl_
_hx_classes["hx.strings._Version.Version_Impl_"] = hx_strings__Version_Version_Impl_

class hx_strings_VersionData(Enum):
    __slots__ = ()
    _hx_class_name = "hx.strings.VersionData"
    _hx_constructs = ["VersionEnum"]

    @staticmethod
    def VersionEnum(major,minor,patch,preRelease,buildMetadata):
        return hx_strings_VersionData("VersionEnum", 0, [major,minor,patch,preRelease,buildMetadata])
hx_strings_VersionData._hx_class = hx_strings_VersionData
_hx_classes["hx.strings.VersionData"] = hx_strings_VersionData

class hx_strings_internal__Either2__Either2(Enum):
    __slots__ = ()
    _hx_class_name = "hx.strings.internal._Either2._Either2"
    _hx_constructs = ["a", "b"]

    @staticmethod
    def a(v):
        return hx_strings_internal__Either2__Either2("a", 0, [v])

    @staticmethod
    def b(v):
        return hx_strings_internal__Either2__Either2("b", 1, [v])
hx_strings_internal__Either2__Either2._hx_class = hx_strings_internal__Either2__Either2
_hx_classes["hx.strings.internal._Either2._Either2"] = hx_strings_internal__Either2__Either2


class python__KwArgs_KwArgs_Impl_:
    _hx_class_name = "python._KwArgs.KwArgs_Impl_"
    __slots__ = ()
    _hx_statics = ["fromT"]

    @staticmethod
    def fromT(d):
        this1 = python_Lib.anonAsDict(d)
        return this1
python__KwArgs_KwArgs_Impl_._hx_class = python__KwArgs_KwArgs_Impl_
_hx_classes["python._KwArgs.KwArgs_Impl_"] = python__KwArgs_KwArgs_Impl_


class python_Lib:
    _hx_class_name = "python.Lib"
    __slots__ = ()
    _hx_statics = ["dictToAnon", "anonToDict", "anonAsDict", "dictAsAnon"]

    @staticmethod
    def dictToAnon(v):
        return _hx_AnonObject(v.copy())

    @staticmethod
    def anonToDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__.copy()
        else:
            return None

    @staticmethod
    def anonAsDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__
        else:
            return None

    @staticmethod
    def dictAsAnon(d):
        return _hx_AnonObject(d)
python_Lib._hx_class = python_Lib
_hx_classes["python.Lib"] = python_Lib


class python_internal_ArrayImpl:
    _hx_class_name = "python.internal.ArrayImpl"
    __slots__ = ()
    _hx_statics = ["concat", "iterator", "indexOf", "lastIndexOf", "toString", "pop", "push", "unshift", "remove", "shift", "slice", "sort", "splice", "map", "filter", "insert", "reverse", "_get", "_set"]

    @staticmethod
    def concat(a1,a2):
        return (a1 + a2)

    @staticmethod
    def iterator(x):
        return python_HaxeIterator(x.__iter__())

    @staticmethod
    def indexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (0 if ((fromIndex is None)) else ((_hx_len + fromIndex) if ((fromIndex < 0)) else fromIndex))
        if (l < 0):
            l = 0
        _g1 = l
        _g = _hx_len
        while (_g1 < _g):
            i = _g1
            _g1 = (_g1 + 1)
            if (a[i] == x):
                return i
        return -1

    @staticmethod
    def lastIndexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (_hx_len if ((fromIndex is None)) else (((_hx_len + fromIndex) + 1) if ((fromIndex < 0)) else (fromIndex + 1)))
        if (l > _hx_len):
            l = _hx_len
        while True:
            l = (l - 1)
            tmp = l
            if (not ((tmp > -1))):
                break
            if (a[l] == x):
                return l
        return -1

    @staticmethod
    def toString(x):
        return (("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in x]))) + "]")

    @staticmethod
    def pop(x):
        if (len(x) == 0):
            return None
        else:
            return x.pop()

    @staticmethod
    def push(x,e):
        x.append(e)
        return len(x)

    @staticmethod
    def unshift(x,e):
        x.insert(0, e)

    @staticmethod
    def remove(x,e):
        try:
            x.remove(e)
            return True
        except Exception as _hx_e:
            _hx_e1 = _hx_e.val if isinstance(_hx_e, _HxException) else _hx_e
            e1 = _hx_e1
            return False

    @staticmethod
    def shift(x):
        if (len(x) == 0):
            return None
        return x.pop(0)

    @staticmethod
    def slice(x,pos,end = None):
        return x[pos:end]

    @staticmethod
    def sort(x,f):
        x.sort(key= python_lib_Functools.cmp_to_key(f))

    @staticmethod
    def splice(x,pos,_hx_len):
        if (pos < 0):
            pos = (len(x) + pos)
        if (pos < 0):
            pos = 0
        res = x[pos:(pos + _hx_len)]
        del x[pos:(pos + _hx_len)]
        return res

    @staticmethod
    def map(x,f):
        return list(map(f,x))

    @staticmethod
    def filter(x,f):
        return list(filter(f,x))

    @staticmethod
    def insert(a,pos,x):
        a.insert(pos, x)

    @staticmethod
    def reverse(a):
        a.reverse()

    @staticmethod
    def _get(x,idx):
        if ((idx > -1) and ((idx < len(x)))):
            return x[idx]
        else:
            return None

    @staticmethod
    def _set(x,idx,v):
        l = len(x)
        while (l < idx):
            x.append(None)
            l = (l + 1)
        if (l == idx):
            x.append(v)
        else:
            x[idx] = v
        return v
python_internal_ArrayImpl._hx_class = python_internal_ArrayImpl
_hx_classes["python.internal.ArrayImpl"] = python_internal_ArrayImpl


class _HxException(Exception):
    _hx_class_name = "_HxException"
    __slots__ = ("val",)
    _hx_fields = ["val"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = Exception


    def __init__(self,val):
        self.val = None
        message = str(val)
        super().__init__(message)
        self.val = val

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.val = None
_HxException._hx_class = _HxException
_hx_classes["_HxException"] = _HxException


class HxOverrides:
    _hx_class_name = "HxOverrides"
    __slots__ = ()
    _hx_statics = ["iterator", "eq", "stringOrNull", "rshift", "modf", "mod", "mapKwArgs"]

    @staticmethod
    def iterator(x):
        if isinstance(x,list):
            return python_HaxeIterator(x.__iter__())
        return x.iterator()

    @staticmethod
    def eq(a,b):
        if (isinstance(a,list) or isinstance(b,list)):
            return a is b
        return (a == b)

    @staticmethod
    def stringOrNull(s):
        if (s is None):
            return "null"
        else:
            return s

    @staticmethod
    def rshift(val,n):
        return ((val % 0x100000000) >> n)

    @staticmethod
    def modf(a,b):
        return float('nan') if (b == 0.0) else a % b if a >= 0 else -(-a % b)

    @staticmethod
    def mod(a,b):
        return a % b if a >= 0 else -(-a % b)

    @staticmethod
    def mapKwArgs(a,v):
        a1 = python_Lib.dictAsAnon(python_Lib.anonToDict(a))
        k = python_HaxeIterator(iter(v.keys()))
        while k.hasNext():
            k1 = k.next()
            val = v.get(k1)
            if hasattr(a1,k1):
                x = getattr(a1,k1)
                setattr(a1,val,x)
                delattr(a1,k1)
        return a1
HxOverrides._hx_class = HxOverrides
_hx_classes["HxOverrides"] = HxOverrides


class python_io_NativeInput(haxe_io_Input):
    _hx_class_name = "python.io.NativeInput"
    __slots__ = ("stream", "wasEof")
    _hx_fields = ["stream", "wasEof"]
    _hx_methods = ["throwEof", "readinto", "readBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Input


    def __init__(self,s):
        self.wasEof = None
        self.stream = s
        self.set_bigEndian(False)
        self.wasEof = False
        if (not self.stream.readable()):
            raise _HxException("Write-only stream")

    def throwEof(self):
        self.wasEof = True
        raise _HxException(haxe_io_Eof())

    def readinto(self,b):
        raise _HxException("abstract method, should be overriden")

    def readBytes(self,s,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise _HxException(haxe_io_Error.OutsideBounds)
        ba = bytearray(_hx_len)
        ret = self.readinto(ba)
        if (ret == 0):
            self.throwEof()
        s.blit(pos,haxe_io_Bytes.ofData(ba),0,_hx_len)
        return ret

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.stream = None
        _hx_o.wasEof = None
        _hx_o.canSeek = None
python_io_NativeInput._hx_class = python_io_NativeInput
_hx_classes["python.io.NativeInput"] = python_io_NativeInput


class python_io_IInput:
    _hx_class_name = "python.io.IInput"
    __slots__ = ()
    _hx_methods = ["set_bigEndian", "readByte", "readBytes", "read", "readUntil", "readUInt16"]
python_io_IInput._hx_class = python_io_IInput
_hx_classes["python.io.IInput"] = python_io_IInput


class python_io_NativeBytesInput(python_io_NativeInput):
    _hx_class_name = "python.io.NativeBytesInput"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["readByte", "readinto"]
    _hx_statics = []
    _hx_interfaces = [python_io_IInput]
    _hx_super = python_io_NativeInput


    def __init__(self,stream):
        super().__init__(stream)

    def readByte(self):
        ret = self.stream.read(1)
        if (len(ret) == 0):
            self.throwEof()
        return ret[0]

    def readinto(self,b):
        return self.stream.readinto(b)

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
python_io_NativeBytesInput._hx_class = python_io_NativeBytesInput
_hx_classes["python.io.NativeBytesInput"] = python_io_NativeBytesInput


class python_io_IFileInput:
    _hx_class_name = "python.io.IFileInput"
    __slots__ = ()
    _hx_interfaces = [python_io_IInput]
python_io_IFileInput._hx_class = python_io_IFileInput
_hx_classes["python.io.IFileInput"] = python_io_IFileInput


class python_io_FileBytesInput(python_io_NativeBytesInput):
    _hx_class_name = "python.io.FileBytesInput"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = [python_io_IFileInput]
    _hx_super = python_io_NativeBytesInput


    def __init__(self,stream):
        super().__init__(stream)
python_io_FileBytesInput._hx_class = python_io_FileBytesInput
_hx_classes["python.io.FileBytesInput"] = python_io_FileBytesInput


class python_io_NativeTextInput(python_io_NativeInput):
    _hx_class_name = "python.io.NativeTextInput"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["readByte", "readinto"]
    _hx_statics = []
    _hx_interfaces = [python_io_IInput]
    _hx_super = python_io_NativeInput


    def __init__(self,stream):
        super().__init__(stream)

    def readByte(self):
        ret = self.stream.read(1)
        if (len(ret) == 0):
            self.throwEof()
        return HxString.charCodeAt(ret,0)

    def readinto(self,b):
        return self.stream.buffer.readinto(b)

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
python_io_NativeTextInput._hx_class = python_io_NativeTextInput
_hx_classes["python.io.NativeTextInput"] = python_io_NativeTextInput


class python_io_FileTextInput(python_io_NativeTextInput):
    _hx_class_name = "python.io.FileTextInput"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = [python_io_IFileInput]
    _hx_super = python_io_NativeTextInput


    def __init__(self,stream):
        super().__init__(stream)
python_io_FileTextInput._hx_class = python_io_FileTextInput
_hx_classes["python.io.FileTextInput"] = python_io_FileTextInput


class python_io_IoTools:
    _hx_class_name = "python.io.IoTools"
    __slots__ = ()
    _hx_statics = ["createFileInputFromText", "createFileInputFromBytes"]

    @staticmethod
    def createFileInputFromText(t):
        return sys_io_FileInput(python_io_FileTextInput(t))

    @staticmethod
    def createFileInputFromBytes(t):
        return sys_io_FileInput(python_io_FileBytesInput(t))
python_io_IoTools._hx_class = python_io_IoTools
_hx_classes["python.io.IoTools"] = python_io_IoTools


class sys_io_File:
    _hx_class_name = "sys.io.File"
    __slots__ = ()
    _hx_statics = ["getContent", "saveContent", "saveBytes", "read"]

    @staticmethod
    def getContent(path):
        f = python_lib_Builtins.open(path,"r",-1,"utf-8",None,"")
        content = f.read(-1)
        f.close()
        return content

    @staticmethod
    def saveContent(path,content):
        f = python_lib_Builtins.open(path,"w",-1,"utf-8",None,"")
        f.write(content)
        f.close()

    @staticmethod
    def saveBytes(path,_hx_bytes):
        f = python_lib_Builtins.open(path,"wb",-1)
        f.write(_hx_bytes.b)
        f.close()

    @staticmethod
    def read(path,binary = True):
        if (binary is None):
            binary = True
        mode = ("rb" if binary else "r")
        f = python_lib_Builtins.open(path,mode,-1,None,None,(None if binary else ""))
        if binary:
            return python_io_IoTools.createFileInputFromBytes(f)
        else:
            return python_io_IoTools.createFileInputFromText(f)
sys_io_File._hx_class = sys_io_File
_hx_classes["sys.io.File"] = sys_io_File


class sys_io_FileInput(haxe_io_Input):
    _hx_class_name = "sys.io.FileInput"
    __slots__ = ("impl",)
    _hx_fields = ["impl"]
    _hx_methods = ["set_bigEndian", "readByte", "readBytes", "read", "readUntil", "readUInt16"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Input


    def __init__(self,impl):
        self.impl = impl

    def set_bigEndian(self,b):
        return self.impl.set_bigEndian(b)

    def readByte(self):
        return self.impl.readByte()

    def readBytes(self,s,pos,_hx_len):
        return self.impl.readBytes(s,pos,_hx_len)

    def read(self,nbytes):
        return self.impl.read(nbytes)

    def readUntil(self,end):
        return self.impl.readUntil(end)

    def readUInt16(self):
        return self.impl.readUInt16()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.impl = None
sys_io_FileInput._hx_class = sys_io_FileInput
_hx_classes["sys.io.FileInput"] = sys_io_FileInput


class sys_net_Socket:
    _hx_class_name = "sys.net.Socket"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["fileno"]

    def __init__(self):
        self._hx___s = None

    def fileno(self):
        return self._hx___s.fileno()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
sys_net_Socket._hx_class = sys_net_Socket
_hx_classes["sys.net.Socket"] = sys_net_Socket

Math.NEGATIVE_INFINITY = float("-inf")
Math.POSITIVE_INFINITY = float("inf")
Math.NaN = float("nan")
Math.PI = python_lib_Math.pi

Apptimize.kABTEventSourceApptimize = "a"
Apptimize.kABTValueEventKey = "value"
Apptimize._isInitialized = False
Date.EPOCH_UTC = python_lib_datetime_Datetime.fromtimestamp(0,python_lib_datetime_Timezone.utc)
apptimize_ABTDataStore._lastCheckTime = -10000.0
apptimize_ABTDataStore._lastSubmitCheckTime = -10000.0
apptimize_ABTLogger.LOG_LEVEL_VERBOSE = 0
apptimize_ABTLogger.LOG_LEVEL_DEBUG = 1
apptimize_ABTLogger.LOG_LEVEL_INFO = 2
apptimize_ABTLogger.LOG_LEVEL_WARN = 3
apptimize_ABTLogger.LOG_LEVEL_ERROR = 4
apptimize_ABTLogger.LOG_LEVEL_NONE = 5
apptimize_ABTLogger.logLevel = apptimize_ABTLogger.LOG_LEVEL_VERBOSE
apptimize_api_ABTApiResultsPost._posting = False
apptimize_api_ABTApiResultsPost.RESULTS_LOCK_KEY = "results_post_key"
apptimize_filter_ABTFilter.kABTFilterKeyValue = "value"
apptimize_filter_ABTFilter.kABTFilterKeyType = "type"
apptimize_filter_ABTFilter.kABTFilterKeyProperty = "property"
apptimize_filter_ABTFilter.kABTFilterKeyOperator = "operator"
apptimize_filter_ABTFilter.kABTFilterKeyPropertySource = "propertySource"
apptimize_filter_ABTFilter.kABTFilterKeyCallServerInputs = "callServerInputs"
apptimize_filter_ABTFilter.kABTFilterKeyCallURLKey = "callServerUrlKey"
apptimize_filter_ABTFilter.kABTFilterKeyUserAttribute = "userAttribute"
apptimize_filter_ABTFilter.kABTFilterKeyPrefixedAttribute = "prefixedAttribute"
apptimize_filter_ABTFilter.kABTFilterKeyNamedFilter = "namedFilter"
apptimize_filter_ABTFilterUtils.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'ABTEvaluateString': _hx_AnonObject({'static': None}), 'ABTEvaluateBool': _hx_AnonObject({'static': None}), 'ABTEvaluateNumber': _hx_AnonObject({'static': None})})})
def _hx_init_apptimize_models_results_ABTResultEntry__sequenceNumber():
    def _hx_local_0():
        this1 = haxe__Int64____Int64(0,0)
        return this1
    return _hx_local_0()
apptimize_models_results_ABTResultEntry._sequenceNumber = _hx_init_apptimize_models_results_ABTResultEntry__sequenceNumber()
def _hx_init_apptimize_models_results_ABTResultEntry__lastTimestamp():
    def _hx_local_0():
        this1 = haxe__Int64____Int64(0,0)
        return this1
    return _hx_local_0()
apptimize_models_results_ABTResultEntry._lastTimestamp = _hx_init_apptimize_models_results_ABTResultEntry__lastTimestamp()
apptimize_support_persistence_ABTPersistence.kMetadataKey = "METADATA_KEY"
apptimize_support_persistence_ABTPersistence.kAnonymousGuidKey = "ANONYMOUS_GUID_KEY"
apptimize_support_persistence_ABTPersistence.kInternalPropertiesKey = "INTERNAL_PROPERTIES_KEY"
apptimize_support_persistence_ABTPersistence.kResultLogsKey = "RESULT_LOGS_KEY"
apptimize_support_persistence_ABTPersistence.kResultPostsKey = "RESULT_POSTS_KEY"
apptimize_support_persistence_ABTPersistence.kApptimizeVersionKey = "APPTIMIZE_VERSION_KEY"
apptimize_support_persistence_ABTPersistence.kPostManagementKey = "POST_MANAGEMENT_KEY"
apptimize_support_properties_ABTApplicationProperties._sigilForApplicationNamespace = "$"
apptimize_support_properties_ABTConfigProperties.META_DATA_URL_KEY = "meta_data_url"
apptimize_support_properties_ABTConfigProperties.META_DATA_URL_LL_KEY = "meta_data_ll_url"
apptimize_support_properties_ABTConfigProperties.META_DATA_URL_HL_KEY = "meta_data_hl_url"
apptimize_support_properties_ABTConfigProperties.LOG_LEVEL = "log_level"
apptimize_support_properties_ABTConfigProperties.FOREGROUND_PERIOD_MS_KEY = "foreground_period_ms"
apptimize_support_properties_ABTConfigProperties.RESULT_POST_DELAY_MS_KEY = "post_delay_ms"
apptimize_support_properties_ABTConfigProperties.THREADING_ENABLED_KEY = "threading_enabled"
apptimize_support_properties_ABTConfigProperties.ALTERATION_CACHE_SIZE = "alteration_cache_size"
apptimize_support_properties_ABTConfigProperties.RESULTS_CACHE_SIZE = "results_cache_size"
apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_ENTRIES_KEY = "maximum_result_entries"
apptimize_support_properties_ABTConfigProperties.MAXIMUM_PENDING_RESULTS_KEY = "maximum_pending_results"
apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_INTERVAL_MS = "metadata_polling_interval_ms"
apptimize_support_properties_ABTConfigProperties.METADATA_POLLING_BACKGROUND_INTERVAL_MS = "metadata_polling_background_interval_ms"
apptimize_support_properties_ABTConfigProperties.EXCEPTIONS_ENABLED_KEY = "exceptions_enabled"
apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_POST_FAILURE_KEY = "maximum_result_failures"
apptimize_support_properties_ABTConfigProperties.MAXIMUM_RESULT_POST_SENDER_TIMEOUT_MS_KEY = "maximum_result_post_sender_timeout_ms"
apptimize_util_ABTDataLock.SYSTEM_DATA_LOCK_KEY = "system_data_lock"
apptimize_util_ABTDataLock.METADATA_LOCK_KEY = "meta_data_lock"
apptimize_util_ABTDataLock.CHECK_TIME_LOCK_KEY = "last_check_time_lock"
apptimize_util_ABTDataLock._lockMap = haxe_ds_StringMap()
haxe_EntryPoint.sleepLock = haxe__EntryPoint_Lock()
haxe_EntryPoint.mutex = haxe__EntryPoint_Mutex()
haxe_EntryPoint.pending = list()
haxe_EntryPoint.threadCount = 0
haxe_MainLoop.pending = None
haxe_Serializer.USE_CACHE = False
haxe_Serializer.USE_ENUM_INDEX = False
haxe_Serializer.BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%:"
haxe_Serializer.BASE64_CODES = None
haxe_Unserializer.DEFAULT_RESOLVER = haxe__Unserializer_DefaultResolver()
haxe_Unserializer.BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%:"
haxe_Unserializer.CODES = None
haxe_zip_InflateImpl.LEN_EXTRA_BITS_TBL = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, -1, -1]
haxe_zip_InflateImpl.LEN_BASE_VAL_TBL = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258]
haxe_zip_InflateImpl.DIST_EXTRA_BITS_TBL = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, -1, -1]
haxe_zip_InflateImpl.DIST_BASE_VAL_TBL = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577]
haxe_zip_InflateImpl.CODE_LENGTHS_POS = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
haxe_zip_InflateImpl.FIXED_HUFFMAN = None
hx_strings_Pattern.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'immutable': None, 'threadSafe': None})})
hx_strings_Matcher.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'notThreadSafe': None})})
python_Boot.keywords = set(["and", "del", "from", "not", "with", "as", "elif", "global", "or", "yield", "assert", "else", "if", "pass", "None", "break", "except", "import", "raise", "True", "class", "exec", "in", "return", "False", "continue", "finally", "is", "try", "def", "for", "lambda", "while"])
python_Boot.prefixLength = len("_hx_")
hx_strings__Version_Version_Impl_.PATTERN_VERSION = ((((((((("" + ((("(0|[1-9]\\d*)" + "\\") + "."))) + ((("(0|[1-9]\\d*)" + "\\") + "."))) + "(0|[1-9]\\d*)") + ((("(?:\\" + "-") + "("))) + HxOverrides.stringOrNull(hx_strings_Strings.replaceAll((("" + ((("(" + "(0|[1-9]\\d*)") + "|[1-9a-zA-Z-][0-9a-zA-Z-]*)"))) + ((((("(\\" + ".") + "(") + "(0|[1-9]\\d*)") + "|[1-9a-zA-Z-][0-9a-zA-Z-]*))*"))),"(","(?:"))) + "))?") + ((("(?:\\" + "+") + "("))) + HxOverrides.stringOrNull(hx_strings_Strings.replaceAll((("[0-9A-Za-z-]+(\\" + ".") + "[0-9A-Za-z-]+)*"),"(","(?:"))) + "))?")
hx_strings__Version_Version_Impl_.VALIDATOR_METADATA = hx_strings_Pattern.compile((("^" + ((("[0-9A-Za-z-]+(\\" + ".") + "[0-9A-Za-z-]+)*"))) + "$"))
hx_strings__Version_Version_Impl_.VALIDATOR_PRERELEASE = hx_strings_Pattern.compile((("^" + ((("" + ((("(" + "(0|[1-9]\\d*)") + "|[1-9a-zA-Z-][0-9a-zA-Z-]*)"))) + ((((("(\\" + ".") + "(") + "(0|[1-9]\\d*)") + "|[1-9a-zA-Z-][0-9a-zA-Z-]*))*"))))) + "$"))
hx_strings__Version_Version_Impl_.VALIDATOR_VERSION = hx_strings_Pattern.compile((("^" + HxOverrides.stringOrNull(hx_strings__Version_Version_Impl_.PATTERN_VERSION)) + "$"))